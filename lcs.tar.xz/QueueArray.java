package com.data;

public class QueueArray {

	private final Object[] data;
	private int front;
	private int rear;
	private int count;

	public QueueArray(int size) {
		this.data = new Object[size];
		this.front = 0;
		this.rear = -1;
		this.count = 0;
	}

	public void enqueue(Object elem) {
		if (rear == data.length - 1) 
			Error.fatal("Queue overflow");
		data[++rear] = elem;
		count++;
	}

	public Object dequeue() {
		if (empty()) Error.fatal("Queue empty");
		return data[front++];
	}
	
	public Object front() {
		if (empty()) Error.fatal("Queue empty");
		return data[front];
	}

	public int size() {
		return count;
	}
	
	public boolean empty() {
		return front > rear;
	}
}
