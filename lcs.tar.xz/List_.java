package com.data;



public class List {
	
	private Node head;
	private Node tail;
	
	public void addHead(Object data) {
		if (empty()) {
			head = tail = new Node(data);
		} else {
			head = new Node(data, head);
		}
	}
	
	public void addTail(Object data) {
		if (empty()) {
			head = tail = new Node(data);
		} else {
			Node node = new Node(data);
			tail.next = node;
			tail = node;
		}
	}
	
	public void deleteHead() {
		if (empty()) {
			Error.fatal("List is empty.");
		}
		head = head.next;
		if (head == null) {
			tail = null;
		}
	}
	
	public void deleteTail() {
		if (empty()) {
			Error.fatal("List is empty.");
		}
		Node curr = head;
		if (curr.next == null) {
			head = tail = null;
		} else {
			while (curr.next.next != null) {
				curr = curr.next;
			}
			curr.next = null;
			tail = curr;
		}
	}
	
	public void reverse() {
		Node prev = null, curr = head, next = null;
		while (curr != null) {
			next = curr.next;
			curr.next = prev;
			prev = curr;
			curr = next;
		}
		tail = head;
		head = prev;
	}
	
	public void reverseR() {
		Node listR = reverseR(head);
		tail = head;
		head = listR;
	}
	
	public Node reverseR(Node node) {
		if (node.next == null) {
			return node;
		}
		Node partial = reverseR(node.next);
		partial.next = node;
		node.next = null;
		return node;
	}
	
	public void dumpR() {
		dumpR(head);
	}
	
	public void dumpR(Node node) {
		if (node == null) {
			System.out.print("null");
		} else {
			System.out.printf("%s->", node.data);
			dumpR(node.next);
		}
	}
	
	public void dump() {
		if (notEmpty()) {
			for (var curr = head; curr != null; curr = curr.next) {
				System.out.printf("%s->", curr.data);
			}
			System.out.println("null");
		}
		System.out.println(head);
		System.out.println(tail);
	}
	
	public boolean empty() {
		return head == null && tail == null;
	}
	
	public boolean notEmpty() {
		return !empty();
	}
	
	public int size() {
		int nodeCount = 0;
		for (Node curr = head; curr != null; curr = curr.next) {
			nodeCount++;
		}
		return nodeCount;
	}
	
	public int sizeR() {
		return sizeR(head);
	}
	
	public int sizeR(Node node) {
		return node == null ? 0 : sizeR(node.next) + 1;
	}
	
	public String toString() {
		var data = new StringBuilder();
		for (var curr = head; curr != null; curr = curr.next) {
			data.append(String.format("%s->", curr.data));
		}
		data.append("null");
		return data.toString();
	}
}
