package com.data;

public class Stack {
	
	public class Node {
		public Object data;
		public Node next;
		
		public Node(Object data) {
			this.data = data;
		}
	}

	private Node head = null;
	private int nodeCount = 0;

	public void push(Object elem) {
		Node node = new Node(elem);
		node.next = head;
		head = node;
		nodeCount++;
	}

	public Object pop() {
		if (empty()) Error.fatal("stack underflow");
		Object retval = head.data;
		head = head.next;
		nodeCount--;
		return retval;
	}

	public Object top() {
		if (empty()) Error.fatal("stack underflow");
		return head.data;
	}
	
	public int size() {
		return nodeCount;
	}
	
	public boolean empty() {
		return size() == 0;
	}
}