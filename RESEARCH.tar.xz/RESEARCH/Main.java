public class Main {
	public static void main(String[] args) {
		int x = 10;
		double y = 10.0;
		if (x == y) {
			System.out.println("true");
		}
	}
}
