struct Point {
    x: i32,
    y: i32
}

struct Number {
    odd: bool,
    val: i32
}

fn main() {
    let a = String::from("hello.world");
    println!("{}", a);
    println!("{}", a);
}