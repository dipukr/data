#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#include <stdint.h>

#define SARAL_LITERAL_TYPE_NULL   1
#define SARAL_LITERAL_TYPE_BOOL   2
#define SARAL_LITERAL_TYPE_CHAR   3
#define SARAL_LITERAL_TYPE_I32    4
#define SARAL_LITERAL_TYPE_I64    5
#define SARAL_LITERAL_TYPE_F64    6
#define SARAL_LITERAL_TYPE_STRING 7


struct saral_class
{

};

struct saral_function
{

};

struct saral_literal
{
	uint16_t type;
	union {
	bool    bin;
	char*   str;
	double  f64;
	int32_t i32;
	int64_t i64;
	int64_t all;
	} value;
};

struct saral_virtual_machine
{
	uint32_t sp;
	uint32_t ip;

	uint32_t stack_size;
	uint64_t *stack_top;
	uint64_t *stack_bottom;
	
	uint32_t code_count;
	uint8_t *code_stream;

	struct saral_class *class;
	struct saral_function *function;
	
	uint32_t literal_count;
	struct saral_literal *literal_stream;

	struct saral_literal null_literal;
	struct saral_literal true_literal;
	struct saral_literal false_literal;
	struct saral_literal zero_i32_literal;
	struct saral_literal zero_i64_literal;
	struct saral_literal zero_f64_literal;
};

void saral_literal_init(struct saral_literal *self, uint16_t type);
void saral_literal_init_bool(struct saral_literal *self, uint16_t type, bool val);
void saral_literal_init_i32(struct saral_literal *self, uint16_t type, int32_t val);
void saral_literal_init_i64(struct saral_literal *self, uint16_t type, int64_t val);
void saral_literal_init_f64(struct saral_literal *self, uint16_t type, double val);
void saral_literal_init_string(struct saral_literal *self, uint16_t type, const char* val);
char* saral_literal_to_string(struct saral_literal *self);

void saral_virtual_machine_init(struct saral_virtual_machine *self);
void saral_virtual_machine_run(struct saral_virtual_machine *self);
void saral_virtual_machine_dump_literal_stream(struct saral_virtual_machine *self, FILE *stream);
void saral_virtual_machine_dump_code_stream(struct saral_virtual_machine *self);

char* saral_string_utils_copy_of(const char* str);
uint32_t saral_math_utils_digit_count(uint32_t n);

void saral_fatal(const char* msg);
void saral_assert(bool flag, const char* msg);

size_t saral_mem_total_allocation = 0;

void* saral_mem_alloc(size_t len)
{
	saral_mem_total_allocation += len;
	void *mem = malloc(len);
	if (mem == NULL) saral_fatal("Fatal error: out of memory.");
	return mem;
}

void saral_fatal(const char* msg)
{
	printf("%s\n", msg);
	exit(EXIT_FAILURE);
}

void saral_assert(bool flag, const char* msg)
{
	if (flag == false) {
		printf("Assetion failed: %s.", msg);
		exit(EXIT_FAILURE);
	}
}

char* saral_string_utils_copy_of(const char* str)
{
	if (str == NULL) return NULL;
	char* new_str = (char*) saral_mem_alloc(strlen(str) + 1);
	strcpy(new_str, str);
	return new_str;
}

char* saral_literal_to_string(struct saral_literal *val)
{
	char data[500];
	switch (val->type) {
	case SARAL_LITERAL_TYPE_NULL:
		sprintf(data, "[type=null, value=null]");
		break;
	case SARAL_LITERAL_TYPE_BOOL:
		sprintf(data, "[type=bool, value=%s]", val->value.bin ? "true" : "false");
		break;
	case SARAL_LITERAL_TYPE_I32:
		sprintf(data, "[type=int32, value=%d]", val->value.i32);
		break;
	case SARAL_LITERAL_TYPE_I64:
		sprintf(data, "[type=int64, value=%ld]", val->value.i64);
		break;
	case SARAL_LITERAL_TYPE_F64:
		sprintf(data, "[type=decimal, value=%f]", val->value.f64);
		break;
	case SARAL_LITERAL_TYPE_STRING:
		saral_assert(strlen(val->value.str) < 500, "String value too large.");
		sprintf(data, "[type=string, value=%s]", val->value.str);
		break;
	default:
		sprintf(data, "[type=undefined, value=undefined]");
	}
	return saral_string_utils_copy_of(data);
}

uint32_t saral_math_utils_digit_count(uint32_t num)
{
	uint32_t count = 0;
	while (num){
		count++;
		num = num / 10;
	}
	return count;
}

void saral_literal_init(struct saral_literal *self, uint16_t type)
{
	memset(self, 0, sizeof(struct saral_literal));
	self->type = type;
}

void saral_literal_init_bool(struct saral_literal *self, uint16_t type, bool val)
{
	saral_literal_init(self, type);
	self->value.bin = val;
}

void saral_literal_init_i32(struct saral_literal *self, uint16_t type, int32_t val)
{
	saral_literal_init(self, type);
	self->value.i32 = val;
}

void saral_literal_init_i64(struct saral_literal *self, uint16_t type, int64_t val)
{
	saral_literal_init(self, type);
	self->value.i64 = val;
}

void saral_literal_init_f64(struct saral_literal *self, uint16_t type, double val)
{
	saral_literal_init(self, type);
	self->value.f64 = val;
}

void saral_literal_init_string(struct saral_literal *self, uint16_t type, const char* val)
{
	saral_literal_init(self, type);
	self->value.str = saral_string_utils_copy_of(val);
}

void saral_virtual_machine_init(struct saral_virtual_machine *self)
{
	memset(self, 0, sizeof(struct saral_virtual_machine));
	saral_literal_init(&self->null_literal, SARAL_LITERAL_TYPE_NULL);
	saral_literal_init_bool(&self->true_literal, SARAL_LITERAL_TYPE_BOOL, true);
	saral_literal_init_bool(&self->false_literal, SARAL_LITERAL_TYPE_BOOL, false);
	saral_literal_init_i32(&self->zero_i32_literal, SARAL_LITERAL_TYPE_I32, 0);
	saral_literal_init_i64(&self->zero_i64_literal, SARAL_LITERAL_TYPE_I64, 0);
	saral_literal_init_f64(&self->zero_f64_literal, SARAL_LITERAL_TYPE_F64, 0.0);
}

void saral_virtual_machine_run(struct saral_virtual_machine *vm)
{
	uint64_t a = 0;
	uint64_t b = 0;
	while (true) {
		uint8_t op = vm->code[vm->ip];
		switch (op) {
		case SARAL_OPCODE_NOP:
		case SARAL_OPCODE_POP:
		case SARAL_OPCODE_POPN:
		case SARAL_OPCODE_NEG_I32:
			a = vm->stack_bottom[vm->sp];

		case SARAL_OPCODE_NEG_I64:
		case SARAL_OPCODE_NEG_F64:
		case SARAL_OPCODE_ADD_I32:
			a = *((int32_t*) (vm->sp - 1));
			b = *((int32_t*) vm->sp);

		case SARAL_OPCODE_ADD_I64:
		case SARAL_OPCODE_ADD_F64:
		case SARAL_OPCODE_SUB_I32:
		case SARAL_OPCODE_SUB_I64:
		case SARAL_OPCODE_SUB_F64:
		case SARAL_OPCODE_MUL_I32:
		case SARAL_OPCODE_MUL_I64:
		case SARAL_OPCODE_MUL_F64:
		case SARAL_OPCODE_DIV_I32:
		case SARAL_OPCODE_DIV_I64:
		case SARAL_OPCODE_DIV_F64:
		case SARAL_OPCODE_MOD_I32:
		case SARAL_OPCODE_MOD_I64:
		case SARAL_OPCODE_MOD_F64:
		case SARAL_OPCODE_SHL_I32:
		case SARAL_OPCODE_SHL_I64:
		case SARAL_OPCODE_SHR_I32:
		case SARAL_OPCODE_SHR_I64:
		case SARAL_OPCODE_BOR_I32:
		case SARAL_OPCODE_BOR_I64:
		case SARAL_OPCODE_BXOR_I32:
		case SARAL_OPCODE_BXOR_I64:
		case SARAL_OPCODE_BAND_I32:
		case SARAL_OPCODE_BAND_I64:
		case SARAL_OPCODE_BNOT_I32:
		case SARAL_OPCODE_BNOT_I64:
		}
	}
}

void saral_virtual_machine_dump_literal_stream(struct saral_virtual_machine *self, FILE *stream)
{
	fprintf(stream, "%s\n", saral_literal_to_string(&self->null_literal));
	fprintf(stream, "%s\n", saral_literal_to_string(&self->true_literal));
	fprintf(stream, "%s\n", saral_literal_to_string(&self->false_literal));
	fprintf(stream, "%s\n", saral_literal_to_string(&self->zero_i32_literal));
	fprintf(stream, "%s\n", saral_literal_to_string(&self->zero_f64_literal));
}

void saral_virtual_machine_dump_code_stream(struct saral_virtual_machine *vm)
{

}



int main(int argc, const char** argv)
{
	struct saral_virtual_machine vm;
	saral_virtual_machine_init(&vm);
	saral_virtual_machine_dump_literal_stream(&vm, stdout);
	return EXIT_SUCCESS;
}