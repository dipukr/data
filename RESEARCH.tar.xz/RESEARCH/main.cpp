#include <iostream>

void fn(size_t a)
{
	if (a < 0) {
		std::cout << a << ":minus" << std::endl;
	} else {
		std::cout << a << ":plus" << std::endl;
	}
}

int main()
{
	fn(1005474867868687678678);
	return EXIT_SUCCESS;
}