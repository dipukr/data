#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

struct things {
	int x;
	int y;
};

int main() {
	struct things t = {100, 200};
	uint64_t u = (uint64_t) &t;
	printf("%lu\n", u);
	printf("%d\n", ((struct things *) u)->x);
}