public class Coll {
	public static int maxSumSubarray(int[] data) {
		int[] opt = new int[data.length];
		opt[0] = data[0];
		for (int i = 1; i < data.length; i++)
			opt[i] = opt[i - 1] + data[i];
		int low = 0;
		int high = data.length - 1;
		int max = Integer.MIN_VALUE;
		while (low < high) {
			int r = opt[high] - (low == 0 ? 0 : opt[low - 1]);
			int l = r - data[low];
			int h = r - data[high];
			if (l > h) {
				low++;
				max = Math.max(max, l);
			} else {
				high--;
				max = Math.max(max, h);
			}
		}
		return max;
	}
	public static int longestCommonSubstring(String a, String b) {
		if (a.length() == 0 || b.length() == 0)
			return 0;
		int res = longestCommonSubstring(a.substring(0, a.length() - 1), b.substring(0, b.length() - 1));
		if (a.charAt(a.length()-1) == b.charAt(b.length()-1))
			return 1 + res;
		else return 0;
	}
	public static void main(String[] args) throws Exception {
		int[] data = {-2,3,-5,2,2,-1,4,-3};
		System.out.println(maxSumSubarray(data));
	}
}

void main(String[] args)
{
	Console.printf("Saral programming language");
	foreach (String arg: args)
		Console.println(arg);
	int x = 43098;
	num x = 100.5489;
	var x = 10000;
	val x = 100;
	real x = 9999;
	
}

void getter = function(int a, num b)
{
	byte x = 1000;
}

void getter(int a, decimal b)
{
	val circle = Circle.of(10, 20);
	circle.draw();
	foreach (var elem: 0..circles.length)
		Console.println("hello.world");
	
}

void getter(int a, decimal b)
{
	val circle = Circle.of(10, 20);
	circle.draw();
}

void getter(int a, real b)
{
	val circle = Circle.new(10, 20);
	var x = 1999;
	integer x = 10000390;
	decimal x = 3490.4390;

	int x = 1000;
	decimal xy;
	num x = 490;

	circle.draw();
	real x = 439090.48878;
	decimal x = 439009;
	integer x = 10000;
	num x = 3499;
	number x = 99090495490;
	real x = 10000.3878432;
	long x = 10000;
	
	val circle = 

	int
	long x = 1000;
	decimal x = 1003993;

	int x = 34290;
	long y = 4394343959490904;
	num x = 2390093;
	real y = 34904009;

	int32 g;
	int64 g;

	real32 r;
	real64 g;
	
	Real real = Real.of(10000);
	
}

class Circle {
	
	decimal x;
	decimal y;

	Circle(decimal x, decimal y) {
		self.x = x;
		self.y = y;
	}
}

class Circle {
	real x;
	real y;

	Circle(real x, real y) {
		self.x = x;
		self.y = y;
	}
}

class Point {

	final real x;
	final real y;
	
	Point(final real radius, final real circumFerence) {
		this.x = x;
		this.y = y;
	}
}

class Point {

	final num x;
	final num y;
	final num total;
	final num summary;
	final val x = Point.of(10, 20);
	
	
	Point(final num x, final num y) {
		this.x = x;
		this.y = y;
	}
}

class Point {

	Decimal x;
	decimal y;
	
	Point(final decimal netTotal, final decimal total) {
		this.x = x;
		this.y = y;
	}
}

class Point {

	number x;
	number y;
	
	Point(final number x, final number y) {
		this.x = x;
		this.y = y;
	}
}

class Point {

	final float x;
	final float y;
	
	Point(final float x, final float y) {
		this.x = x;
		this.y = y;
	}
}








