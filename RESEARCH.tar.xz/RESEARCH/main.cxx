#include <iostream>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>

int main(const int argc, const char **argv)
{
	std::cout << "Welcome to C++ Programming" << std::endl;
	return EXIT_SUCCESS;
}