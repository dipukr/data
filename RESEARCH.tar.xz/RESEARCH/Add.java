import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.stream.Collectors;

public class Add {
	
	private static DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
	private static String fileName = "/tmp/vikas.db";
	
	private static Map<String, Integer> readAll() throws ParseException, IOException {
		Map<String, Integer> dateWiseRs = new TreeMap<>();
		List<String> lines = Files.lines(Paths.get(fileName)).collect(Collectors.toList());
		for (String line: lines) {
			String[] attrs = line.split(":");
			String date = attrs[0];
			int rs = Integer.valueOf(attrs[1]);
			dateWiseRs.put(date, rs);
		}
		return dateWiseRs;
	}
	
	private static void writeAll(Map<String, Integer> dateWiseRs) throws IOException {
		FileOutputStream fos = new FileOutputStream(fileName);
		for (Entry<String, Integer> entry: dateWiseRs.entrySet()) {
			String date = entry.getKey();
			Integer rs = entry.getValue();
			String line = String.format("%s:%d\n", date, rs);
			fos.write(line.getBytes());
		}
		fos.close();
	}
	
	public static void main(String[] args) throws Exception {
		if (args.length == 0) {
			Map<String, Integer> dateWiseRs = readAll();
			for (Entry<String, Integer> entry: dateWiseRs.entrySet()) {
				String date = entry.getKey();
				Integer rs = entry.getValue();
				String line = String.format("%s: %d", date, rs);
				System.out.println(line);
			}
			System.out.printf("Total: %d\n", dateWiseRs.values().stream().mapToInt(elem -> elem).sum());
		} else if (args.length == 1) {
			int addRs = Integer.valueOf(args[0]);
			Map<String, Integer> dateWiseRs = readAll();
			String today = df.format(new Date());
			if (dateWiseRs.containsKey(today)) {
				int rs = dateWiseRs.get(today) + addRs;
				dateWiseRs.put(today, rs);
			} else {
				dateWiseRs.put(today, addRs);
			}
			writeAll(dateWiseRs);
		}
	}
}
