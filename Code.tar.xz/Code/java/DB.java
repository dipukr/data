import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class DB {
	
	private static final Map<String, String> jobs = new LinkedHashMap<>();
	private static final String filePath = "/home/dipu/BATCH-JOBS.csv";
	
	public static void parse(String line) {
		String[] words = line.split(",");
		int offset = words[0].length() + words[1].length() + 2;
		line = line.substring(offset);
		String cron = null;
		if (line.charAt(0) == ',') {
			cron = "";
		} else if (line.startsWith("NULL")) {
			
		} else if (line.charAt(0) == '"') {
			int i = 1;
			StringBuilder a = new StringBuilder();
			while (i < line.length() && line.charAt(i) != '"')
				a.append(line.charAt(i++));
			cron = a.toString();
		} else return;
		jobs.put(words[1], cron);
	}
	
	public static void save() throws Exception {
		String url = "jdbc:mysql://164.52.216.173:3306/epm__";
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection(url, "vijay", "Vijay@1212");
		for (Entry<String, String> entry: jobs.entrySet()) {
			String jobName = entry.getKey();
			String cronString = entry.getValue();
			Statement statement = con.createStatement();
			String sql = null;
			if (cronString == null)
				sql = String.format("UPDATE batch_runnable_jobs SET cron_string = null WHERE job_name = '%s'", jobName);
			else 
				sql = String.format("UPDATE batch_runnable_jobs SET cron_string = '%s' WHERE job_name = '%s'", cronString, jobName);
			statement.execute(sql);
		}
	}
	
	public static void main(String[] args) throws Exception {
		List<String> lines = 
			Files.lines(Path.of(filePath))
				.collect(Collectors.toList());
		for (String line: lines)
			parse(line);
		save();
		System.out.println("Completed.");
	}
}