public class Main {
	public static void main(String[] args) throws Exception {
		System.out.printf("%c\n", 128544);
	}
}