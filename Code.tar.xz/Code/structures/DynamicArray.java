public class DynamicArray<T> implements Iterable<T> {
	
	private T[] data;
	private int len = 0;
	private int capacity;

	public DynamicArray() {
		this(8);
	}

	public DynamicArray(int size) {
		this.len = 0;
		this.capacity = size;
		this.data = new 
	}

	public void clear() {
		for (int i = 0; i < capacity; i++)
			data[i] = null;
	}

	public int size() {
		return len;
	}

	public boolean empty() {
		return size() == 0;
	}

	
}