import java.util.Map;
import java.util.HashMap;

public class Search {

	public static void DFS(Node node) {
		visit(node);
		for (Node adjacentNode: node.adjacentNodes())
			if (adjacentNode.notMarked())
				DFS(adjacentNode);
	}

	public static void DFS(Node startNode) {
		var stack = new Stack<Node>();
		visitNode(startNode);
		while (stack.notEmpty()) {
			
		}
	}

	public static void BFS(Node startNode) {
		var queue = new Queue<Node>();
		queue.enqueue(startNode);
		visitNode(startNode);
		while (queue.notEmpty()) {
			Node currNode = queue.dequeue();
			for (Node adjacentNode: currNode.adjacentNodes()) {
				if (adjacentNode.notMarked()) {
					visitNode(node);
					queue.enqueue(node);
				}
			}	
		}
	}

	public static void visitNode(Node node) {
		node.mark();
		System.out.printf("%s ", node);
	}
}