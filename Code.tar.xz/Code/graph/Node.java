import java.util.List;
import java.util.ArrayList;

public class Node {
	
	private String data;
	private boolean marked = false;
	private List<Node> adjacents = new ArrayList<Node>();

	public Node(String data) {
		this.data = data;
	}

	public List<Node> adjacentNodes() {
		return adjacents;
	}

	public void mark() {
		marked = true;
	}
	
	public boolean marked() {
		return marked;
	}

	public boolean notMarked() {
		return !marked;
	}
	
	public String toString() {
		return data;
	}
}