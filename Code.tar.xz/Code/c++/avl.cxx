#include <iostream>

struct avl_tree
{
	struct node
	{
		int key;
		int height = 0;
		int	factor = 0;
		node *left = nullptr;
		node *right = nullptr;
		node(int key) : key(key) {}
	};
	
	node *root = nullptr;
	int node_count = 0;
	
	bool contains(int key) {return contains(root, key);}
	
	bool contains(avlnode *node, int key)
	{
		if (node == nullptr)
			return false;
		if (key < node->key)
			return contains(node->left, key);
		else if (key > node->key)
			return contains(node->right, key);
		return true;
	}
	
	void insert(int key)
	{
		if (!contains(key)) {
			root = insert(root, key);
			count++;
		}
	}
	
	avlnode* insert(avlnode *node, int key)
	{
		if (node == nullptr)
			return new avlnode(key);
		if (key > node->key)
			node->right = insert(node->right, key);
		else node->left = insert(node->left, key);
		update(node);
		return balance(node);
	}
	
	void update(avlnode *node)
	{
		int lh = (node->left == nullptr) ? -1 : node->left->height;
		int rh = (node->right == nullptr) ? -1 : node->right->height;
		node->height = max(lh, rh) + 1;
		node->factor = rh - lh;
	}
	
	avlnode* balance(avlnode *node)
	{
		if (node->factor == -2) {
			if (node->left->factor <= 0)
        		return leftleftcase(node);
        	return leftrightcase(node);
		} else if (node->factor == +2) {
			if (node->right->factor >= 0)
				return rightrightcase(node);
			return rightleftcase(node);	
		}
		return node;
	}

	avlnode* leftleftcase(avlnode *node)
	{
		return rightrotation(node);
	}
	
	avlnode* right_right_case(avlnode *node)
	{
		return left_rotation(node);
	}

	avlnode* left_right_case(avlnode *node)
	{
		node->left = left_rotation(node->left);
		return left_left_case(node);
	}

	avlnode* right_left_case(avlnode *node)
	{
		node->right = right_rotation(node->right);
		return right_right_case(node);
	}

	avlnode* left_rotation(avlnode *node)
	{
		avlnode *parent = node->right;
		node->right = parent->left;
		parent->left = node;
		update(node);
		update(parent);
		return parent;
	}

	avlnode* right_rotation(avlnode *node)
	{
		avlnode *parent = node->left;
		node->left = parent->right;
		parent->right = node;
		update(node);
		update(parent);
		return parent;
	}
	
	int max(int a, int b) {return (a > b) ? a : b;}
	int size() const {return count;}
	int height() const {return (root == nullptr) ? -1 : root->height;}
	bool empty() const {return count == 0;}
};

void inorder(avl::avlnode *node)
{
	if (node == nullptr) return;
	inorder(node->left);
	std::cout << node->key << char(9);
	inorder(node->right);
}

int main()
{
	avl_tree avl;
	for (int i = 0; i < 1024; i++) avl.insert(i);
	std::cout << avl.size() << std::endl;
	std::cout << avl.height() << std::endl;
	std::cout << avl.contains(434) << std::endl;
	std::cout << avl.contains(4341) << std::endl;
}
