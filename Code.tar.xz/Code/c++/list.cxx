#include <stack>
#include <vector>
#include <iostream>
using namespace std;

struct node {
	double data;
	node *next;
	node(int d): data(d), next(nullptr){}
};

bool empty(node *head)
{
	return head == nullptr;
}

size_t size(node *head)
{
	size_t count(0);
	for (auto i = head; i; i = i->next)
		count++;
	return count;
}

void println(node *head)
{
	for (auto i = head; i; i = i->next)
		cout << i->data << "->";
	cout << "null" << endl;
}

void insert_at_head(node* &head, double data)
{
	node *new_node = new node(data);
	new_node->next = head;
	head = new_node;
}

void insert_at_tail(node* &head, double data)
{
	if (head == nullptr) {
		head = new node(data);
		return;
	}
	node *curr = head;
	while (curr->next != nullptr)
		curr = curr->next;
	curr->next = new node(data);
}

void insert_after(node *after, double val)
{
	if (after->next == nullptr) {
		after->next = new node(val);
		return;
	}
	node *new_node = new node(val);
	new_node->next = after->next;
	after->next = new_node;
}

void delete_head(node* &head)
{
	if (head == nullptr) return; 
	node *temp = head;
	head = head->next;
	delete temp;
}

void delete_tail(node* &head)
{
	if (head == nullptr) return;
	if (head->next == nullptr) {
		delete head;
		head = nullptr;
		return;
	}
	node* iter = head;
	while (iter->next->next != nullptr)
		iter = iter->next;
	node* tail = iter->next;
	iter->next = nullptr;
	delete tail;
}

void delete_this(node* head, node* _this)
{
	if (head == nullptr) return;
	node* curr = head;
	while (curr->next != _this)
		curr = curr->next;
	curr->next = _this->next;
	delete _this;
}

void delete_after(node* after)
{
	if (after->next != nullptr) {
		node *temp = after->next;
		after->next = after->next->next;
		delete temp;
	}
}

void delete_by_value(node* head, double value)
{
	if (head == nullptr) return;
	if (head->next == nullptr) {

	}
	node *curr = head;
	while (curr->next && curr->next->data != val)
		curr = curr->next;
	node *temp = curr->next;
	curr->next = curr->next->next;
	delete temp;
}

bool search(node *head, double key)
{
	while (head != nullptr) {
		if (head->data == key) return true;
		head = head->next;
	}
	return false;
}

void reverse(node* &head)
{
	node* curr = head;
	node* prev = nullptr;
	node* next = nullptr;
	while (curr != nullptr) {
		next = curr->next;
		curr->next = prev;
		prev = curr;
		curr = next;
	}
	head = prev;
}

void reversek(node* &head, int k)
{
	node *prev = nullptr;
	node *next = nullptr;
	node *curr = head;
	int count = 1;
	while (curr != nullptr and count <= k) {
		next = curr->next;
		curr->next = prev;
		prev = curr;
		curr = next;
		count++;
	}
	head->next = curr;
	head = prev;
}

void append_last_k_node(node* &head, int k)
{
	int n = size(head)-k-1;
	node *curr = head;
	while (curr != nullptr && n--)
		curr = curr->next;
	node *newhead = curr->next;
	curr->next = nullptr;
	curr = newhead;
	while (curr->next)
		curr = curr->next;
	curr->next = head;
	head = newhead;
}

void append_last_k_node_alt(node* &head, int k)
{
	node *tail = head;
	node *new_head, *new_tail;
	int len = size(head);
	int count = 1;
	while (tail->next != nullptr) {
		if (count == len - k)
			new_tail = tail;
		if (count == len - k + 1)
			new_head = tail;
		tail = tail->next;
		count++;
	}
	newtail->next = nullptr;
	tail->next = head;
	head = newhead;
}

node* merge_two_linked_list(node *first, node *second)
{
	node *result(nullptr);
	while (first != nullptr && second != nullptr) {
		if (first->data < second->data) {
			insert_at_tail(result, first->data);
			first = first->next;
		} else {
			insert_at_tail(result, second->data);
			second = second->next;
		}
	}
	while (first != nullptr) {
		insert_at_tail(result, first->data);
		first = first->next;
	}
	while (second != nullptr) {
		insert_at_tail(result, second->data);
		second = second->next;
	}
	return result;
}

node* merge_two_linked_list_alt(node *first, node* second)
{
	node *result = new node(0);
	node *curr = result;
	while (first != nullptr && second != nullptr) {
		if (first->data < second->data) {
			curr->next = first;
			first = first->next;
		} else {
			curr->next = second;
			second = second->next;
		}
		curr = curr->next;
	}	
	while (first != nullptr) {
		curr->next = first;
		curr = curr->next;
		first = first->next;
	}
	while (second != nullptr) {
		curr->next = first;
		curr = curr->next;
		second = second->next,
	}
	return result->next;
}

node* even_after_odd(node* &head)
{
	node *odd = head;
	node *even = head->next;
	node *evenstart = even;
	while (odd->next != nullptr and even->next != nullptr) {
		odd->next = even->next;
		odd = odd->next;
		even->next = odd->next;
		even = even->next;
	}
	odd->next = evenstart;
	if (odd->next != nullptr)
		even->next = nullptr;
}


void intersect(node *head1, node *head2, int pos)
{
	node *p1 = head1;
	node *p2 = head2;
	while (--pos) p1 = p1->next;
	while (p2->next not_eq nullptr) p2 = p2->next;
	p2->next = p1;
}

int intersection_point(node *head1, node *head2)
{
	int l1 = size(head1);
	int l2 = size(head2);
	int diff = abs(l1-l2);
	node *p1, *p2;
	(l1 > l2) ? p1 = head1, p2 = head2 : p1 = head2, p2 = head1;
	while (diff--) p1 = p1->next;
	while (p1 not_eq nullptr and p2 not_eq nullptr) {
		if (p1 == p2) return p1->data;
		p1 = p1->next;
		p2 = p2->next;
	}
}

void make_cycle(node* head, int pos)
{
	int count = 1;
	node *start, *curr = head;
	while (curr->next not_eq nullptr) {
		if (count == pos) start = curr;
		curr = curr->next;
		count++;
	}
	curr->next = start;
}

bool detect_cycle(node *head)
{
	if (head == nullptr) return true;
	node *curr = head->next;
	while (curr != nullptr && curr != head)
		curr = curr->next;
	return curr == head;
}

bool detect_cycle(node *head)
{
	node *slow = head;
	node *fast = head;
	while (fast != nullptr and fast->next != nullptr) {
		slow = slow->next;
		fast = fast->next->next;
		if (slow == fast) return true;
	}
	return false;
}

void remove_cycle(node* head)
{
	if (!detect_cycle(head)) return;
	node *slow = head;
	node *fast = head;
	do {
		slow = slow->next;
		fast = fast->next->next;
	} while (slow != fast);
	fast = head;
	while (slow->next != fast->next) {
		slow = slow->next;
		fast = fast->next;
	}
	slow->next = nullptr;
}

int main()
{
	node* head(nullptr);
	insert_at_head(head, 100);
	insert_at_head(head, 200);
	insert_at_head(head, 300);
	println(head);
}