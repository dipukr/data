void printSubarray(int a[], int n)
{
	for (int i = 0; i < n; i++)
		for (int j = i; j < n; j++)
			printArray(a+i, j-i+1);
}

int sumSubarray(int a[], int n)
{
	int result = 0;
	for (int i = 0; i < n; i++)
		for (int j = i; j < n; j++)
			result += sumArray(a+i, j-i+1);
	return result;
}

int maxSubarraySum(int a[], int n)
{
	int maxsum = INT_MIN;
	for (int i = 0; i < n; i++) {
		for (int j = i; j < n; j++) {
			int sum = 0;
			for (int k = i; k <= j; k++)
				sum += a[k];
			maxsum = max(maxsum, sum);
		}
	}
	return maxsum;
}

int maxSumSubarrayDP(int a[], int n)
{
	int opt[n];
	opt[0] = a[0];
	int maxSum = INT_MIN;
	for (int i = 1; i < n; i++)
		opt[i] = opt[i-1] + a[i];
	for (int i = 0; i < n; i++)
		for (int j = i; j < n; j++) {
			int sum = opt[j] - opt[i-1];
			maxSum = max(maxSum, sum);
		}
	return maxSum;
}

bool pairSum(int a[], int n, int k)
{
	for (int i = 0; i < n-1; i++)
		for (int j = i + 1; j < n; j++)
			if (a[i] + a[j] == k)
				return true;
	return false;
}

bool pairSum2(int a[], int n, int k)
{
	sort(a, a+n);
	int low = 0, high = n-1;
	while (low < high) {
		if (a[low] + a[high] == k)
			return true;
		if (a[low] + a[high] > k)
			high--;
		else low++;
	}
	return false;
}

bool duplicates(const int a[], int n) // array must be sorted
{
	for (int i = 0; i < n; i++)
		for (int j = i + 1; j < n; j++)
			if (a[i] == a[j])
				return true;
	return false;
}

void reverse(int a[], int n)
{
	for (int i = 0, j = n - 1; i < j; i++, j--)
		swap(a[i], a[j]);
}

void reverse(int a[], int n)
{
    int b[n];
    for (int i = 0; i < n; i++)
        b[n - i] = a[i];
    a = b;
}

void reduce(int a[], int n)
{
	vector<pair<int,int>> v;
	for (int i = 0; i < n; i++)
		v.push_back(make_pair(a[i], i));
	sort(begin(v), end(v),
		[](pair<int,int> a, pair<int,int> b){return a.first<b.first;});
	for (int i = 0; i < v.size(); i++)
		a[v[i].second] = i;
}

void printMaxSequence(int a[], int n)
{
	int mx = INT_MIN;
	for (int i = 0; i < n; i++)
		cout << max(a[i], mx) << char(9);
}

int largestArithmeticArray(int a[], int n)
{
	int pd = a[1] - a[0];
	int curr = 2;
	int ans = 2;
	int i = 2;
	while (i < n) {
		int cd = a[i] - a[i-1];
		if (cd == pd) curr++;
		else pd = cd, curr = 2;
		i++;
	}
	return ans;
}

int largestRectangleArea(int a[], int n)
{
	int ans = 0;
	for (int i = 0; i < n; i++) {
		int minh = INT_MIN;
		for (int j = i; j < n; j++) {
			minh = min(a[j], minh);
			int len = j - i + 1;
			ans = max(ans, len * minh);
		}
	}
	return ans;
}

int minIndexRepeatingElem(int a[], int n)
{
	int idx[n];
	fill(a, a+n, -1);
	int minidx = numeric_limits<int>::max();
	for (int i = 0; i < n; i++) {
		if (idx[a[i]] != -1)
			minidx = max(idx[a[i]], minidx);
		else idx[a[i]] = i;
	}
	return (minidx < n) ? minidx : -1;
}

void findSubarrayThatSumS(int a[], int n, int s)
{
	int i = 0, j = 0;
	int start = -1, end = -1;
	int sum = 0;
	while (j < n and sum + a[j] <= s) {
		sum += a[j];
		j++;
	}
}

int smallestNumberMissing(int a[], int n)
{
	const int n = 1e6+2;
	bool check[n];
	fill(check, check+n, false);
	for (int i = 0; i < n; i++)
		if (a[i] >= 0)
			check[a[i]] = true;
	int smallest = -1;
	for (int i = 0; i < n; i++)
		if (check[i] == false)
			return i;
	return smallest;
}