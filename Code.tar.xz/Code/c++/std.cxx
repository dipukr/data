void merge(queue<double> &a, queue<double> &b, queue<double> &r)
{
	while (!a.empty() && !b.empty()) {
		if (a.peek() < b.peek())
			r.push(a.pop());
		else r.push(b.pop());
	}
	while (!a.empty()) r.push(a.pop());
	while (!b.empty()) r.push(b.pop());
}

void merge(list<int> &a, list<int> &b, list<int> &result)
{
	auto fst = begin(a);
	auto snd = begin(b);
	while (fst != end(a) && snd != end(b))
		if (*fst < *snd)
			result.push_back(*fst), fst++;
		else
			result.push_back(*snd), snd++;
	while (fst != end(a))
		result.push_back(*fst), fst++;
	while (snd != end(b))
		result.push_back(*snd), snd++;
}

void merge(list<int> &a, list<int> &b, list<int> &r)
{
	while (!a.empty() && !b.empty()) {
		if (a.front() < b.front())
			r.push_back(a.front()), a.pop_front();
		else
			r.push_back(b.front()), b.pop_front();
		while (!a.empty())
			r.push_back(a.front()), a.pop_front();
		while (!b.empty())
			r.push_back(b.front()), b.pop_front();
	}
}

vector<string> read_words(istream &in)
{
	vector<string> words;
	string line;
	while (in >> line)
		words.push_back(line);
	return words;
}

void copy_from_file_to_coll()
{
	vector<string> v;
	ifstream in("data.txt");
	in.seekg(10);
	copy(istream_iterator<string>(in), istream_iterator<string>(), back_inserter(v));
}

void copy_from_file_to_coll_alt()
{
	ifstream filedata("out.dat");
	istream_iterator<string> begin(filedata);
	istream_iterator<string> end;
	vector<string> data(begin, end);
}

void tokenize_using_whitespace(const string &s, vector<string> &result)
{
	stringstream ss(s);
	string word;
	while (ss >> word)
		result.push_back(word);
}

void tokenize(const string &s, const string &del, vector<string> &result)
{
	int start = 0;
	int end = s.find(del);
	while (end != -1) {
		result.push_back(s.substr(start, end - start));
		start = end + del.size();
		end = s.find(del, start);
	}
	result.push_back(s.substr(start, end - start));
}

void print_frequencies(const string &s)
{
	unordered_map<string, int> wordFreq;
	stringstream ss(s);
	string word;
	while (ss >> word)
		wordFreq[word]++;
	for (auto &elem: wordFreq)
		cout << "[" << elem.first << ": " << elem.second << "]" << endl;
}

void spell_check(istream &dictionary, istream &words)
{
	set<string,less<string>> dict;
	set<string,less<string>> misspellings;
	string word;
	istream_iterator<string> dstream(dictionary),eof;
	copy(dstream, eof, inserter(dict, dict.begin()));
	while (words >> word)
		if (!dict.count(word))
			misspellings.insert(word);
	cout << "Misspelled:" << endl;
	print(misspellings);
}

void ostream_stringstring()
{
	stringstream ss;
	ostream out(ss.rdbuf());
	out << 100 << endl;
	out << 37.33 << endl;
	out << "deepu";
	cout << ss.rdbuf() << endl;
}

vector<string> read_all_words(const string &filename)
{
	ifstream input(filename);
	vector<string> result;
	result.insert(result.begin(), istream_iterator<string>(input), istream_iterator<string>());
	return result;
}

vector<string> read_all_lines(const string &filename)
{
	vector<string> lines;
	ifstream in(filename);
	string s;
	while (getline(in, s))
		lines.push_back(s);
	return lines;
}

void load_all_data(vector<string> &d1, vector<string> &d2)
{
	auto r1 = async(read_all_lines, "data1.txt");
	auto r2 = async(read_all_lines, "data2.txt");
	d1 = r1.get();
	d2 = r2.get();
}

list<int> add_one(list<int> a)
{
	list<int> r;
	a.reverse();
	int carry = 0;
	auto i = a.begin();
	while (i != a.end()) {
		int sum = (i == a.begin()) ? *i + 1: *i + carry;
		carry = sum / 10;
		r.push_back(sum % 10);
		i++;
	}
	if (carry)
		r.push_back(1);
	r.reverse();
	return r;
}

int binary_to_decimal(list<int> a)
{
	a.reverse();
	auto iter = a.begin();
	int f = 1;
	int r = 0;
	while (iter != a.end()) {
		int d = *iter;
		r += d * f;
		f = f * 2;
		iter++;
	}
	return r;
}

list<int> add(list<int> &a, list<int> &b)
{
	list<int> result;
	a.reverse();
	b.reverse();
	auto p = a.begin();
	auto q = b.begin();
	int sum = 0, carry = 0;
	while (p != a.end() || q != b.end()) {
		sum = (p != a.end() ? *p : 0) + (q != b.end() ? *q : 0) + carry;
		carry = sum >= 10 ? 1 : 0;
		sum = sum % 10;
		result.push_back(sum);
		if (p != a.end()) p++;
		if (q != b.end()) q++;
	}
	if (carry > 0)
		result.push_back(carry);
	result.reverse();
	return result;
}

list<int> multiply(list<int> &a, list<int> &b)
{
    list<int> r;
    a.reverse();
	b.reverse();
    int len = a.size() + b.size() + 1;
    while (len--)
        r.push_back(0);
    auto q = S.begin();
	auto r = R.begin();
    while (q != S.end()) {
        auto s = r;
		auto carry = 0;
		auto p = F.begin();
        while (p != F.end()) {
            int mul = (*p) * (*q) + carry;
            *s += mul % 10;
            carry = mul / 10 + *s / 10;
            p++;
			s++;
        }
        if (carry > 0)
            *s += carry;
        r++;
		q++;
    }
    result.reverse();
    return result;
}