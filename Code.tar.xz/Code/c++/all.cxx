int factorial(int n)
{
	int result(1);
	for (int i = n; i > 0; i--)
		result *= i;
	return result;
}

int fibonacci(int n)
{
	int f1 = 0, f2 = 1, fn;
	for (int i = 2; i <= n; i++) {
		fn = f1 + f2;
		f1 = f2;
		f2 = fn;
	}
	return fn;
}

int fibonacci(int n)
{
	int f1 = 0, f2 = 1, fn = 0;
	while (fn < n) {
		fn = f1 + f2;
		f1 = f2;
		f2 = fn;
	}
	return fn;
}

int gcd(int a, int b)
{
	while (b != 0) {
		int rem = a % b;
		a = b;
		b = rem;
	}
	return a;
}

bool prime(int n)
{
	for (int i = 2; i < n; i++)
		if (n % i == 0)
			return false;
	return true;
}

int reverse(int n)
{
	int result = 0;
	while (n) {
		result = result * 10 + n % 10;
		n = n / 10;
	}
	return result;
}

int digitsum(int n)
{
	int result(0);
	while (n) {
		result += n % 10;
		n = n / 10;
	}
	return result;
}

int digital(int n) 
{
	while (n > 9)
		n = digitsum(n);
	return n;
}

int eratosthenes(int n)
{
	vector<bool> prime(n + 1, true);
	prime[0] = prime[1] = false;
	for (int i = 2; i * i <= n; i++)
		if (prime[i])
			for (int j = i + i; j <= n; j += i)
				prime[j] = false;
	int count = 0;
	for (int j = 0; j <= n; j++)
		if (prime[j])
			++count;
	return count;
}

int divisibleCount(int n, int a, int b)
{
	int ac = 0, bc = 0, both = 0;
	for (int i = 2; i < n; i++) {
		if (i % a == 0) ac++;
		if (i % b == 0) bc++;
		if (i % a == 0 && i % b == 0) both++;
	}
	return ac + bc - both;
}

int divisibleCount(int n, int a, int b)
{
	int c1 = n / a;
	int c2 = n / b;
	int c3 = n / (a*b);
	return c1 + c2 - c3;
}

void tolower(string &s)
{
	int offset = 'a' - 'A';
	for (char &ch: s)
		if (ch >= 'A' and ch <= 'Z')
			ch += offset;
}

void toupper(string &s)
{
	int offset = 'a' - 'A';
	for (char &ch: s)
		if (ch >= 'a' and ch <= 'z')
			ch -= offset;
}

bool palindrome(char arr[])
{
	int n = strlen(arr);
	for (int i = 0; i < n / 2; i++)
		if (arr[i] != arr[n-1-i])
			return false;
	return true;
}

void decimalToBinary(int n)
{
	while (n) {
		int d = n % 2;
		cout << d;
		n = n / 2;
	}
}

void decimalToOctal(int n)
{
	while (n) {
		int d = n % 8;
		cout << d;
		n = n / 8;
	}
}

void decimalToHexadecimal(int n)
{
	static string digits = "0123456789ABCDEF";
	while (n) {
		int d = n % 16;
		cout << digits[d];
		n = n / 16;
	}
}

int binaryToDecimal(int n)
{
	int result = 0, f = 1;
	while (n) {
		int d = n % 2;
		result += f * d;
		f = f * 2;
		n = n / 10;
	}
	return result;
}

char randch()
{
	static string alphabet = "abcdefghijklmnopqrstuvwxyz";
	return alphabet[rand() % alphabet.size()];
}

string randstr(int min, int max)
{
	string s;
	for (int i = 0; i < rand() % max + min; i++)
		s += randch();
	return s;
}

int largestWordLength(const string &sentance)
{
	int maxlen = 0;
	int currlen = 0;
	for (int i = 0; i < sentance.size(); i++) {
		if (sentance[i] == ' ') {
			maxlen = max(maxlen, currlen);
			currlen = 0;
		} else currlen++;
	}
	return max(maxlen, currlen);
}

void reverseWords(string &sentance)
{
	stack<string> st;
	for (int i = 0; i < sentance.size(); i++) {
		string word = "";
		while (i < sentance.size() and sentance[i] != ' ')
			word += sentance[i++];
		st.push(word);
	}
}

void countFrequency(int a[], int n)
{
	map<int, int> m;
	for (int i = 0; i < n; i++)
		m[a[i]]++;
	for (auto e: m)
		cout << e.first << ":" << e.second << endl;
}

void spiralTraversal(int m[][], int row, int col)
{
	int rstart = 0, rend = row - 1;
	int cstart = 0, cend = col - 1;
	while (rstart <= rend && cstart <= cend) {
		for (int col = cstart; col <= cend; col++)
			cout << m[rstart][col] << " ";
		rstart++;
		for (int row = rstart; row <= rend; row++)
			cout << m[row][cend] << " ";
		cend--;
	}

}

bool matSearch(int m[][], int row, int col, int key)
{
	for (int i = 0; i < row; i++)
		for (int j = 0; j < col; j++)
			if (m[i][j] == key)
				return true;
	return false;
}

bool matSearch2(int m[][], int row, int col, int key)
{
	int r = 0, c = 0;
	while (r < row and c < col) {
		if (m[r][c] == key)
			return true;
		if (m[r][c] > key) c--;
		else r++;
	}
	return false;
}

int fib(int n)
{
	static vector<int> cache(n + 1, 0);
	if (cache[n])
		return cache[n];
	int val = (n == 1 || n == 2) ? 1 : fib(n - 1) + fib(n - 2);
	cache[n] = val;
	return val;
}

int maxSumSubarray(int a[], int n)
{
	int opt[n];
	opt[0] = a[0];
	int maxSum = INT_MIN;
	for (int i = 1; i < n; i++)
		opt[i] = opt[i-1] + a[i];
	for (int i = 0; i < n; i++)
		for (int j = i; j < n; j++) {
			int sum = opt[j] - opt[i-1];
			maxSum = max(maxSum, sum);
		}
	return maxSum;
}

int lis(int a[], int n)
{
	int lis[n];
	lis[0] = 1;
	for (int i = 1; i < n; i++) {
		lis[i] = 1;
		for (int j = 0; j < i; j++)
			if (a[i] > a[j] && lis[i] <= lis[j])
				lis[i] = lis[j] + 1;
	}
	return *max_element(lis, lis+n);
}

string lcs(const string &x, const string &y)
{
	int m = x.length();
	int n = y.length();

	int opt[m+1][n+1] = {0};

	for (int i = m-1; i >= 0; i--)
		for (int j = n-1; j >= 0; j--)
			if (x[i] == y[j])
				opt[i][j] = opt[i+1][j+1] + 1;
			else
				opt[i][j] = max(opt[i+1][j], opt[i][j+1]);

	string result;
	int i = 0;
	int j = 0;
	
	while (i < m && j < n) {
		if (x[i] == y[j]) {
			result += x[i];
			i++;
			j++;
		}
		else if (opt[i+1][j] >= opt[i][j+1]) i++;
		else j++;
	}

	return result;
}

int prefixEvaluation(string s)
{
	stack<int> st;
	for (int i = s.length()-1; i >= 0; i--) {
		if (s[i] >= '0' && s[i] <= '9')
			st.push(s[i]-'0');
		else {
			int a = st.top();
			st.pop();
			int b = st.top();
			st.pop();
			switch (s[i]) {
			case '+': st.push(a+b); break;
			case '-': st.push(a-b); break;
			case '*': st.push(a*b); break;
			case '/': st.push(a/b); break;
			case '^': st.push(pow(a,b)); break;
			}
		}
	}
	return st.top();
}

int postfixEvaluation(string s)
{
	stack<int> st;
	for (int i = 0; i < s.length(); i++) {
		if (s[i] >= '0' && s[i] <= '9')
			st.push(s[i]-'0');
		else {
			int a = st.top();
			st.pop();
			int b = st.top();
			st.pop();
			switch (s[i]) {
			case '+': st.push(a+b); break;
			case '-': st.push(a-b); break;
			case '*': st.push(a*b); break;
			case '/': st.push(a/b); break;
			case '^': st.push(pow(a,b)); break;
			}
		}
	}
	return st.top();
}

int precedence(char ch)
{
	if (ch == '^') return 3;
	else if (ch == '*' || ch == '/') return 2;
	else if (ch == '+' || ch == '-') return 1;
	else return -1;
}

string infixToPostfix(string s)
{
	stack<char> st;
	string result;
	for (int i = 0; i < s.length(); i++) {
		char c = s[i];
		if (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z')
			result += c;
		else if (c == '(')
			st.push(c);
		else if (c == ')') {
			while (!st.empty() && st.top() != '(') {
				result += st.top();
				st.pop();
			}
			if (!st.empty()) st.pop();
		} else { // op
			while (!st.empty() && precedence(st.top()) < precedence(c)) {
				result += st.top();
				st.pop();
			}
			st.push(c);
		}
	}
	while (!st.empty()) {
		result += st.top();
		st.pop();
	}
	return result;
}

string infixToPrefix(string s)
{
	reverse(s.begin(), s.end());
	for(int i = 0; i < s.length(); i++)
		if (s[i] == '(') s[i] = ')';
		else if (s[i] == ')') s[i] = '(';
	string result = infixToPostfix(s);
	reverse(result.begin(), result.end());
	return result;
}

bool redundantParenthesis(string s)
{
	stack<char> st;
	bool answer = false;
	for (char ch: s) {
		if (ch == '(') st.push(ch);
		else if (ch == '+' or ch == '-' or ch == '*' or ch == '/') st.push(ch);
		else if (ch == ')') {
			if (st.top() == '(') answer = true;
			while (st.top() == '+' or st.top() == '-' or st.top() == '*' or st.top() == '/')
				st.pop();
			st.pop();
		}
	}
	return answer;
}

bool threesum(int a[], int n, int target)
{
	for (int i = 0; i < n; i++)
		for (int j = i + 1; j < n; j++)
			for (int k = j + 1; k < n; k++)
				if (a[i] + a[j] + a[k] == target)
					return true;
	return false;
}

bool threesum2(int a[], int n, int target)
{
	sort(a, a+n);
	for (int i = 0; i < n; i++) {
		int low = i + 1;
		int high = n - 1;
		while (low < high) {
			int curr = a[i] + a[low] + a[high];
			if (curr == target) return true;
			if (curr < target) low++;
			else high--;
		}
	}
	return false;
}

int strstr(const string &haystack, const string &needle)
{
	if (needle.size() == 0) return 0;
	if (needle.size() > haystack.size()) return -1;
	for (int i = 0; i <= haystack.size()-needle.size(); i++) {
		bool found = true;
		for (int j = 0; j < needle.size(); j++) {
			if (haystack[i + j] != needle[j]) {
				found = false;
				break;
			}
		}
		if (found) return i;
	}
	return -1;
}

void heapify(vector<double> &A, int N, int index)
{
	int max = index;
	int lhs = 2 * index + 1;
	int rhs = 2 * index + 2;
	if (lhs < N && A[lhs] > A[max]) max = lhs;
	if (rhs < N && A[rhs] > A[max]) max = rhs;
	if (max != index) {
		swap(A[i], A[max]);
		heapify(A, N, max);
	}
}

void heapsort(vector<double> &A, int N)
{
	for (int i = n / 2 - 1; i >= 0; i--)
		heapify(A, N, i);
	for (int i = N - 1; i >= 0; i--) {
		swap(A[0], A[i]);
		heapify(A, i, 0);
	}
}

string removeDup(string s)
{
	if (s.length() == 0) return "";
	char ch = s[0];
	string ros = removeDup(s.substr(1));
	if (ch == ros[0]) return ros;
	return ch+ros;
}

void timer(uint32_t interval)
{
	uint32_t intervalMS = interval * 1000000;
	clock_t start = clock();
	while (true) {
		clock_t end = clock();
		clock_t elapsed_time = end - start;
		if (elapsed_time >= intervalMS) {
			std::cout << "firing...." << std::endl;
			start = end;
		}
	}
}

size_t strlen(const char *str)
{
	char *p = str;
	while (*p++) {}
	return p - str - 1;
}

int strlen(const char *str)
{
	int len = 0;
	while (str[len++]) {}
	return len;
}

char* strcpy(char *dest, const char *src)
{
	for (auto i(0); dest[i] = src[i]; ++i) {}
	return dest;
}

char* strcpy(char *dest, const char *src)
{
    while (*dest++ = *src++) {}
    return dest;
}

int strcmp(const char *a, const char *b)
{
	int i;
	for (i = 0; a[i] == b[i]; i++) {}
	if (a[i] == 0) return 0;
	return a[i] - b[i];
}

int strcmp(const char *a, const char *b)
{
	while (*a++ == *b++) {}
	if (*(p - 1) == 0) return 0;
	return *(p - 1) - *(q - 1);
}

char* strcat(char *dest, const char *src)
{
	strcpy(dest + strlen(dest), src);
	return dest;
}

char* strdup(const char *str)
{
	int len = strlen(str);
	char *data = new char[len + 1];
	strcpy(data, str);
	return data;
}