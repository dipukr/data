node* reverse2(node* &head)
{
	if (head == nullptr || head->next == nullptr)
		return head;
	node *newhead = reverse2(head->next);
	head->next->next = head;
	head->next = nullptr;
	return newhead;
}

node* reversek2(node *head, int k)
{
	node *prev = nullptr;
	node *next = nullptr;
	node *curr = head;
	int count = 1;
	while (curr not_eq nullptr and count <= k) {
		next = curr->next;
		curr->next = prev;
		prev = curr;
		curr = next;
		count++;
	}
	if (next not_eq nullptr)
		head->next = reversek2(next, k);
	return prev;
}