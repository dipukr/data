#include <map>
#include <vector>
#include <memory>
#include <csetjmp>
#include <iostream>
#include <algorithm>

template<class... T>
void print(const T &... t)
{
	std::initializer_list<int>{(std::cout << t << "", 0)...};
	std::cout << std::endl;
}

template<typename T>
void print_vector(const std::vector<T> &input)
{
	print("\n{");
	for (int i = 0; i < input.size(); i++)
		print("  ", input.at(i), ", ");
	print("}\n");
}

template<typename T>
void print_vector_alt(const std::vector<T> &v)
{
	std::for_each(std::begin(v), std::end(v), [](int a){std::cout<<a<<"\t";});
	std::cout << std::endl;
}

struct node;
struct header;
struct traceable;

std::map<traceable*, header*> trace_info;

intptr_t *__rbp; // Frame pointer
intptr_t *__rsp; // Stack pointer
intptr_t *__stack_begin; // Main frame stack begin

#define __READ_RBP() __asm__ volatile("movq %%rbp, %0" : "=r"(__rbp))
#define __READ_RSP() __asm__ volatile("movq %%rsp, %0" : "=r"(__rsp))

struct header
{
	bool marked;
	size_t size;
};

// Traceable struct is used as base class for any object which should be managed by GC
struct traceable
{
	header* get_header()
	{
		return trace_info.at(this);
	}

	static void* operator new(size_t size)
	{
		void *ptr = ::operator new(size);
		header *hdr = new header{.marked=false, .size=size};
		trace_info.insert(std::make_pair((traceable*)ptr, hdr));
		return ptr;
	}
};

struct node : traceable
{
	char name;
	node *left;
	node *right;
};

void dump(const char *label)
{
	print(label, ":");
	for (const auto &elem: trace_info) {
		auto node = reinterpret_cast<Node*>(elem.first);
		print("  [", node->name, "] ", elem.first,
			": {.marked=", elem.second->marked,
	      	", .size=", elem.second->size, "}");
	}
}

void gc_init()
{
	__READ_RBP();
	__stack_begin = (intptr_t*)*__rbp;
}

// Traverses the stacks to obtain the roots.
std::vector<traceable*> get_roots()
{
	std::vector<traceable*> result;

	// Some local variables (roots) can be stored in registers
	// Use setjmp to push them all onto the stack
	jmp_buf jb;
	setjmp(jb);

	__READ_RSP();
	auto rsp = (uint8_t*)__rsp;
	auto top = (uint8_t*)__stack_begin;
	while (rsp < top) {
		auto address = (traceable*)*(uintptr_t*)rsp;
		if (trace_info.count(address) != 0)
			result.emplace_back(address);
		rsp++;
	}
	return result;
}

std::vector<traceable*> get_pointers(traceable *object) {
	auto p = (uint8_t*) object;
	auto end = (p + object->get_header()->size);
	std::vector<traceable*> result;
	while (p < end) {
		auto address = (traceable*) *(uintptr_t*)p;
		if (trace_info.count(address) != 0)
			result.emplace_back(address);
		p++;
	}
	return result;
}

void mark()
{
	auto worklist = get_roots();
	while (!worklist.empty()) {
		auto o = worklist.back();
		worklist.pop_back();
		auto header = o->get_header();
		if (!header->marked) {
			header->marked = true;
			for (const auto &p: get_pointers(o))
				worklist.push_back(p);
		}
	}
}

void sweep()
{
	auto it = trace_info.cbegin();
	while (it != trace_info.cend()) {
		if (it->second->marked) {
			it->second->marked = false;
			++it;
		} else {
			it = trace_info.erase(it);
			delete it->first;
		}
	}
}

void gc()
{
	mark();
	dump("After mark");
	sweep();
	dump("After sweep");
}

node* create_graph()
{
	auto H = new node{.name = 'H'};
	auto G = new node{.name = 'G', .right = H};
	auto F = new node{.name = 'F'};
	auto E = new node{.name = 'E', .left = F, .right = G};
	auto D = new node{.name = 'D'};
	auto C = new node{.name = 'C', .left = D, .right = E};
	auto B = new node{.name = 'B'};
	auto A = new node{.name = 'A', .left = B, .right = C}; 
	return A;  // Root
}

int main()
{
	gc_init();
	auto A = create_graph();
	dump("Autocated graph");
	A->right = nullptr;
	gc();
}
