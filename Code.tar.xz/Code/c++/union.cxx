#include <vector>
#include <iostream>

struct union_find
{
	std::vector<int> parent;

	union_find(int n)
	{
		parent = std::vector<int>(n);
		for (int i = 0; i < n; i++)
			parent[i] = i;
	}

	int find(int u)
	{
		if (u == parent[u])
			return u;
		else return parent[u] = find(parent[u]);
	}

	bool connected(int u, int v)
	{
		return find(u) == find(v);
	}

	void unite(int u, int v)
	{
		parent[find(u)] = find(v);
	}
};

int main()
{
	union_find uf(5);
	uf.unite(0, 2);
	std::cout << uf.connected(0, 2);
}
