#include <iostream>
#include <vector>
#include <collib>

struct Node
{
	int data;
	Node *left;
	Node *right;
	Node(int data, Node *left=nullptr, Node *right=nullptr)
		: data{data}, left{left}, right{right} {}
};

int find(int inorder[], int curr, int start, int end)
{
	for (int i = start; i <= end; i++)
		if (inorder[i] == curr)
			return i;
	return -1;
}

Node* buildTree(int preorder[], int inorder[], int start, int end)
{
	static int i = 0;
	if (start > end) return nullptr;
	int curr = preorder[i++];
	Node *node = new Node(curr);
	if (start == end) return node;
	int pos = find(inorder, curr, start, end);
	node->left = buildTree(preorder, inorder, start, pos-1);
	node->right = buildTree(preorder, inorder, pos+1, end);
}

int size(Node *node)
{
	if (node == nullptr) return 0;
	return 1 + size(node->left) + size(node->right);
}

int size2(Node *root)
{
	int count(0);
	Queue<Node*> queue;
	queue.enqueue(root);
	while (!queue.empty()) {
		count++;
		Node *node = queue.dequeue();
		if (node->left) queue.enqueue(node->left);
		if (node->right) queue.enqueue(node->right);
	}
	return count;
}

int height(Node *node)
{
	if (node == nullptr) return 0;
	return 1 + max(height(node->left), height(node->right));
}

int diameter(Node *node)
{
	if (node == nullptr) return 0;
	int leftHeight = height(node->left);
	int rightHeight = height(node->right);
	int currDiameter = leftHeight + rightHeight + 1;
	int leftDiameter = diameter(node->left);
	int rightDiameter = diameter(node->right);
	return max(currDiameter, max(leftDiameter, rightDiameter));
}

int sumNodes(Node *node)
{
	if (node == nullptr) return 0;
	return node->data + sumNodes(node->left) + sumNodes(node->right);	
}

int sumReplace(Node *node)
{
	if (node == nullptr) return 0;
	sumReplace(node->left);
	sumReplace(node->right);
	if (node->left) node->data += node->left->data;
	if (node->right) node->data += node->right->data;
}

void preorder(Node *root)
{
	if (root == nullptr) return;
	cout << root->data << " ";
	preorder(root->left);
	preorder(root->right);
}

void inorder(Node *root)
{
	if (root == nullptr) return;
	inorder(root->left);
	cout << root->data << " ";
	inorder(root->right);
}

void postorder(Node *root)
{
	if (root == nullptr) return;
	postorder(root->left);
	postorder(root->right);
	cout << root->data << " ";
}

void levelOrder(Node *root)
{
	Queue<Node*> queue;
	queue.enqueue(root);
	while (!queue.empty()) {
		Node *node = queue.dequeue();
		if (node->left) queue.enqueue(node->left);
		if (node->right) queue.enqueue(node->right);
		cout << node->data << " ";
	}
}

void levelOrder2(Node *root)
{
	int level(0);
	Queue<Node*> queue;
	queue.enqueue(root);
	queue.enqueue(nullptr);
	while (!queue.empty()) {
		Node *node = queue.dequeue();
		if (node != nullptr) {
			if (node->left)
				queue.enqueue(node->left);
			if (node->right)
				queue.enqueue(node->right);
			cout << node->data << " ";
		} else if (!queue.empty()) {
			level++;
			cout << endl;
			queue.enqueue(nullptr);
		}
	}
}

int sumAtKthLevel(Node *root, int k)
{
	int sum(0);
	int level(0);
	Queue<Node*> queue;
	queue.enqueue(root);
	queue.enqueue(nullptr);
	while (!queue.empty()) {
		Node *node = queue.dequeue();
		if (node != nullptr) {
			if (node->left)
				queue.enqueue(node->left);
			if (node->right)
				queue.enqueue(node->right);
			if (level == k)
				sum += node->data;
		} else if (!queue.empty()) {
			level++;
			queue.enqueue(nullptr);
		}
	}
	return sum;
}

void leftView(Node *root)
{
	Queue<Node*> queue;
	queue.offer(root);
	while (not queue.empty()) {
		int n = queue.size();
		for (int i = 1; i <= n; i++) {
			Node *curr = queue.poll();
			if (i == 1)
				cout << curr->data << " ";
			if (curr->left not_eq nullptr)
				queue.offer(curr->left);
			if (curr->right not_eq nullptr)
				queue.offer(curr->right);
		}
	}
}

void rightView(Node *root)
{
	Queue<Node*> queue;
	queue.offer(root);
	while (not queue.empty()) {
		int n = queue.size();
		for (int i = 1; i <= n; i++) {
			Node *curr = queue.poll();
			if (i == n)
				cout << curr->data << " ";
			if (curr->left not_eq nullptr)
				queue.offer(curr->left);
			if (curr->right not_eq nullptr)
				queue.offer(curr->right);
		}
	}
}

bool balanced(Node *node)
{
	if (node == nullptr) return true;
	if (!balanced(node->left)) return false;
	if (!balanced(node->right)) return false;
	return abs(height(node->left)-height(node->right)) <= 1;
}

bool balanced2(Node *node)
{
	if (node == nullptr) return true;
	return abs(height(node->left)-height(node->right)) <= 1 and balanced(node->left) and balanced(node->right);
}

bool balanced(Node *node, int *height)
{
	if (node == nullptr) return true;
	int lh = 0, rh = 0;
	if (!balanced(node->left, &lh)) return false;
	if (!balanced(node->right, &rh)) return false;
	*height = max(lh, rh) + 1;
	return abs(lh - rh) <= 1; 
}

bool getPath(Node *node, int key, vector<int> &path)
{
	if (node == nullptr) return false;
	path.push_back(node->data);
	if (node->data == key) return true;
	if (getPath(node->left, key, path) or getPath(node->right, key, path)) return true;
	path.pop_back();
	return false;
}

int lowestCommonAncestor(Node *node, int n1, int n2)
{
	vector<int> path1, path2;
	if (!getPath(node, n1, path1) || !getPath(node, n2, path2)) return -1;
	int pc = 0;
	for (; pc < path1.size() and path2.size(); pc++)
		if (path1[pc] not_eq path2[pc])
			break;	
	return path1[pc - 1];
}

Node* lowestCommonAncestor2(Node *node, int n1, int n2)
{
	if (node == nullptr) return nullptr;
	if (node->data == n1 or node->data == n2) return node;
	Node *leftLca = lowestCommonAncestor2(node->left, n1, n2);
	Node *rightLca = lowestCommonAncestor2(node->right, n1, n2);
	if (leftLca and rightLca) return node;
	if (leftLca == nullptr) return rightLca;
	return leftLca;
}

bool find(Node *node, int key)
{
	if (node == nullptr) return false;
	cout << node->data << " ";
	if (node->data == key) return true;
	return find(node->left, key) or find(node->right, key);
}

void flatten(Node *node)
{
	if (node == nullptr or (node->left == nullptr and node->right == nullptr))
		return;
	if (node->left != nullptr) {
		flatten(node->left);
		Node *save = node->right;
		node->right = node->left;
		node->left = nullptr;
		Node *tail = node->right;
		while (tail->right != nullptr)
			tail = tail->right;
		tail->right = save;
	}
	flatten(node->right);
}

int shortestDistBetweenNodes(Node *node, int n1, int n2)
{
	
}

int main()
{
	Node *root = new Node(10);
	root->left = new Node(20);
	root->right = new Node(30);
	root->left->left = new Node(40);
	root->left->right = new Node(50);
	root->right->left = new Node(60);
	root->right->right = new Node(70);
	rightView(root);cout<<endl;
	flatten(root);
	rightView(root);
	postorder(root);
}
