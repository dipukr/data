#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
	if (argc == 4) {
		char cmd[10000];
		char *file_name = argv[1];
		char *from_time = argv[2];
		char *total_time = argv[3];
		char *to_time = argv[3];
		if (strcmp(argv[0], "get"))
			sprintf(cmd, "ffmpeg -ss %s -i '%s' -t %s -c copy '_%s' -hide_banner -loglevel error", from_time, file_name, total_time, file_name);
		else if (strcmp(argv[0], "get2"))
			sprintf(cmd, "ffmpeg -i '%s' -ss %s -to %s -c copy '_%s' -hide_banner -loglevel error", file_name, from_time,  to_time, file_name);
		system(cmd);
	}
}