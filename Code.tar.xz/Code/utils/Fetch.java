import java.io.File;
import java.util.List;
import java.util.Queue;
import java.util.ArrayList;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.HashMap;
import java.util.LinkedList;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;

public class Fetch {

	private Map<String, List<String>> filesMap = new HashMap<>();
	private List<String> dirs = new ArrayList<>();

	public Fetch(List<String> dirs) {
		this.dirs = dirs;
	}

	public void fetch(String fileName) {
		for (String dir: dirs) {
			File root = new File(dir);
			walk(root);
		}
		List<String> filePaths = filesMap.get(fileName);
		if (filePaths == null) {
			System.out.printf("File '%s' not found.\n", fileName);
			return;
		}
		int code = 0;
		Runtime runtime = Runtime.getRuntime();
		if (filePaths.size() > 1) {
			int count = 0;
			for (String filePath: filePaths) {
				System.out.printf("[%d][%s]\n", count++, filePath);
			}
			System.out.print("Which one? ");
			try (Scanner scanner = new Scanner(System.in)) {
				String word = scanner.next();
				try {
					code = Integer.valueOf(word);
				} catch (NumberFormatException e) {
					System.out.printf("%c\n", 128544);
					System.exit(0);
				}
			}
			if (code < 0 || code >= filePaths.size()) {
				System.out.printf("%c\n", 128544);
				System.exit(0);
			}
		}
		try {
			String command = String.format("subl %s", filePaths.get(code));
			Process process = runtime.exec(command);
			process.waitFor();
		} catch (Exception e) {
			System.out.println("Fatal error....");
		}
	}

	public void walk(final File root) {
		Queue<File> queue = new LinkedList<>();
		queue.offer(root);
		while (queue.isEmpty() == false) {
			File file = queue.poll();
			String filePath = file.getAbsolutePath();
			if (file.isDirectory()) {
				File[] files = file.listFiles();
				if (files == null) continue;
				for (File elem: files)
					queue.offer(elem);
			} else {
				String fileName = file.getName();
				if (filesMap.containsKey(fileName))
					filesMap.get(fileName).add(filePath);	
				else {
					List<String> filePaths = new ArrayList<>();
					filePaths.add(filePath);
					filesMap.put(fileName, filePaths);
				}
			}
		}
	}
	
	public static void main(String[] args) {
		if (args.length == 1) {
			try {
				String fileName = args[0];
				List<String> dirs = Files.lines(Path.of("/etc/fetch")).toList();
				Fetch fetch = new Fetch(dirs);
				fetch.fetch(fileName);
			} catch (IOException e) {
				System.out.println("File IO error.");
			}
		}
	}
}
