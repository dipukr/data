import java.io.File;
import java.util.Queue;
import java.util.Set;
import java.util.TreeSet;
import java.util.LinkedList;

public class List {
	public static void main(String[] args) throws Exception {
		File root = null;
		if (args.length == 0) root = new File(".");
		else if (args.length == 1) root = new File(args[0]);
		else return;
		Set<String> filePaths = new TreeSet<>();
		Queue<File> queue = new LinkedList<>();
		queue.offer(root);
		while (queue.isEmpty() == false) {
			File file = queue.poll();
			if (file.isDirectory()) {
				File[] files = file.listFiles();
				if (files != null)
					for (File elem: files)
						queue.offer(elem);
			} else {
				String filePath = file.getCanonicalPath();
				filePaths.add(filePath);
			}
		}
		filePaths.stream().forEach(System.out::println);
	}
}
