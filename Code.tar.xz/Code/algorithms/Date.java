import java.text.SimpleDateFormat;
import java.sql.Time;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

public class ControllerLayer {

	public class Data {
		public Date fromDate;
		public Date toDate;		
		public Time fromTime;
		public Time toTime;
		public Float data;
	}
	
	public boolean isOverlaping(List<Data> datas) throws Exception {
		Map<Integer, Map<Integer, Map<Integer, Float>>> map = new TreeMap<>();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		Date currDate = formatter.parse("24-08-2022");

		for (Data data: datas) {
			int month = DateUtil.getMonth(quantumData.getFromDate());
			if (!map.containsKey(month))
				map.put(month, new TreeMap<Integer, Map<Integer, Float>>());
			int startDay = DateUtils.getDay(quantumData.getFromDate());
			int endDay = DateUtils.getDay(quantumData.getToDate());
			for (int day = startDay; day <= endDay; day++) {
				if (!map.get(month).containsKey(day))
					map.get(month).put(day, new TreeMap<Integer, Float>());
				int startMinute = DateUtils.getMinute(quantumData.getFromTime());
				int endMinute = DateUtils.getMinute(quantumData.getToTime());
				for (int minute = startMinute; minute <= endMinute; minute++) {
					if (map.get(month).get(day).containsKey(minute)) {
						return true;
					else map.get(month).get(day).put(minute, quantumData.getQuantum()); 
				}
			}
		}		
	}
	return false;
}
