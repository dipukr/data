public class Main {
	public static void main(String[] args) throws Exception {
		BinaryHeap bh = new BinaryHeap<Integer>();
		bh.insert(200);
		bh.insert(300);
		bh.insert(100);
		Integer min = bh.deleteMin()
		System.out.println(min);
	}
}