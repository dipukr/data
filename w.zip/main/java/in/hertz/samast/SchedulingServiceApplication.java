package in.hertz.samast;

import java.time.Instant;
import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@ComponentScan({"in.hertz.samast"})
@EntityScan({"in.hertz.samast.entity"})
@EnableJpaRepositories("in.hertz.samast.dao")
@EnableEurekaClient
@EnableSwagger2
public class SchedulingServiceApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(SchedulingServiceApplication.class, args);
		System.out.printf("%s: Application Has Started on Port 8780", Date.from(Instant.now()));
	}

	@Bean
	public Docket productApi() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("Scheduling Service").select()
				.apis(RequestHandlerSelectors.basePackage("in.hertz.samast.ctrl")).build();
	}
}