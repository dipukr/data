package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.UtilitiesTraderGenco;

@SuppressWarnings("rawtypes")
@Repository
public interface GenerationDao extends JpaRepository<Generation, Integer> {
	
	@Query("SELECT genco FROM Generation genco WHERE genco.utilitiesTraderGenco = :utg")
	public Generation findByUtg(@Param("utg") UtilitiesTraderGenco utg);
}
