import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import java.util.ArrayList;
import java.util.List;

public class Snake {
	
	public List<Cell> cells = new ArrayList<>();
	public boolean collison = false;
	
	public void grow(Cell cell) {
		cells.add(cell);
	}
	
	public void eat(Food food) {
		if (food.x == cells.get(0).x && food.y == cells.get(0).y) {
			grow(new Cell(-1, -1));
			food.update(this);
		}
	}
	
	public void move(int dir) {
		for (int i = cells.size() - 1; i > 0; i--) {
			cells.get(i).x = cells.get(i - 1).x;
			cells.get(i).y = cells.get(i - 1).y;
		}
		switch (dir) {
		case UP:
			cells.get(0).y--;
			if (cells.get(0).y <= 0) collison = true;
			break;
		case DOWN:
			cells.get(0).y++;
			if (cells.get(0).y >= ROWS) collison = true;
			break;
		case LEFT:
			cells.get(0).x--;
			if (cells.get(0).x <= 0) collison = true;
			break;
		case RIGHT:
			cells.get(0).x++;
			if (cells.get(0).x >= COLS) collison = true;
			break;
		}
	}
	
	public void draw(Graphics2D gc) {
		for (Cell cell: cells) {
			gc.setColor(Color.blue);
			gc.fillRect(cell.x * SIZE, cell.y * SIZE, SIZE - 1, SIZE - 1);
		}
	}
}
