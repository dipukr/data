public class Cell {
	
	public int x;
	public int y;
	
	public Cell(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public static Cell of(int x, int y) {
		return new Cell(x, y);
	}
}
