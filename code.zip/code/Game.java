import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Game extends JPanel {

	public static final int ROWS = 25;
	public static final int COLS = 40;
	public static final int WIDTH = SIZE * COLS;
	public static final int HEIGHT = SIZE * ROWS;
	
	public static final int UP = KeyEvent.VK_UP;
	public static final int DOWN = KeyEvent.VK_DOWN;
	public static final int LEFT = KeyEvent.VK_LEFT;
	public static final int RIGHT = KeyEvent.VK_RIGHT;

	public Snake snake = new Snake();
	public Food food = new Food();
	public boolean gameOver = false;
	public boolean running = false;
	public int dir = KeyEvent.VK_RIGHT;
	
	public Game() {
		setVisible(true);
		setPreferredSize(new Dimension(COLS * SIZE, ROWS * SIZE));
		setBackground(new Color(39, 40, 34));
		snake.grow(new Cell(10, 10));
		snake.grow(new Cell(11, 10));
		snake.grow(new Cell(12, 10));
	}
	
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D gc = (Graphics2D) g;
		food.draw(gc);
		snake.draw(gc);
		snake.eat(food);
		snake.move(dir);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {}
		if (snake.collison == false)
			repaint();
	}

	private class KeyHandler implements KeyListener {
		private Game game;
		
		public KeyHandler(Game game) {
			this.game = game;
		}
		
		@Override
		public void keyTyped(KeyEvent e) {}
		
		@Override
		public void keyReleased(KeyEvent e) {}

		@Override
		public void keyPressed(KeyEvent e) {
			dir = e.getKeyCode();
		}
	}

	public static void main(String[] args) throws Exception {
		JFrame frame = new JFrame();
		Game game = new Game();
		keyHandler keyHandler = new KeyHandler(game);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.addKeyListener(keyHandler);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(game, BorderLayout.CENTER);
		frame.pack();
	}
}
