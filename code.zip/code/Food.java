import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

public class Food {
	
	private final Random rand = new Random();

	public int x;
	public int y;

	public Food(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public void update(Snake snake) {
		while (true) {
			x = rand.nextInt(Snake.COLS);
			y = rand.nextInt(Snake.ROWS);
			if (valid(snake))
				break;
		}
	}
	
	public boolean valid(Snake snake) {
		for (Cell cell: snake.body)
			if (cell.x == x || cell.y == y)
				return false;
		return true;
	}

	public void draw(Graphics2D gc) {
		gc.setColor(Color.yellow);
		gc.fillRect(x, y, Snake.SIZE, Snake.SIZE);
	}

	public static Food of(int x, int y) {
		return new Food(x, y);
	}
}
