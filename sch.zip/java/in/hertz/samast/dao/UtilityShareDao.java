package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import in.hertz.samast.entity.UtilityShare;

@Repository
public interface UtilityShareDao extends JpaRepository<UtilityShare, Integer> {
}
