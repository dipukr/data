package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.GenerationUnitType;
import in.hertz.samast.entity.UtilitiesTraderGenco;

@Repository
public interface GenerationDao<T> extends JpaRepository<Generation<T>, Integer> {

	@Query("SELECT gen.generationTypeDetail FROM Generation gen WHERE gen.utilitiesTraderGenco = :utg")
	public GenerationUnitType findGenerationTypeByUTG(UtilitiesTraderGenco utg);
	
}
