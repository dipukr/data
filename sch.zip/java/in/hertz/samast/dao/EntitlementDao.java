package in.hertz.samast.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import in.hertz.samast.entity.Entitlement;

@Repository
public interface EntitlementDao extends JpaRepository<Entitlement, Integer> {

	@Query("FROM Entitlement e WHERE e.drawingEntity.UID = :buyer AND e.forDate = :date AND e.revision = :revision")
	public List<Entitlement> findAllByBuyerDateAndRevision(int buyerId, Date date, int revision);
}
