package in.hertz.samast.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.hertz.samast.domain.CoalPositionBO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.entity.Draft;

/**
 * 
 * @author Bibhuti Parida
 * This is Draft Repository interface which manages draft table data for scheduling services
 *
 * @param <T>
 */
@Repository
public interface DraftRepository<T> extends JpaRepository<Draft<T>, Integer> {

	@Query("SELECT a FROM Draft a " + "WHERE a.functionalityArea = 'Scheduling_DC' and a.status = 'NEW' and function('JSON_EXTRACT', a.data, '$.sellerUTGId') = ?1 and function('JSON_EXTRACT', a.data, '$.forDate') = ?2")
	public List<Draft<ScheduleQuantumBaseDTO>> findDraftByName(int utgId, String forDate); 
	
	@Query("SELECT dt FROM Draft dt " + "WHERE dt.functionalityArea='Scheduling_CoalPoistion' and dt.status = 'NEW' and function('JSON_EXTRACT', dt.data, '$.utgId') = ?1 and function('JSON_EXTRACT', dt.data, '$.forDate') = ?2")
	public List<Draft<CoalPositionBO>> findDraftByDate(int utgId, String forDate);
}
