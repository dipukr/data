package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import in.hertz.samast.entity.EntitlementDetails;

@Repository
public interface EntitlementDetailsDao extends JpaRepository<EntitlementDetails, Integer> {

}
