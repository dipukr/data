package in.hertz.samast.service;

import java.util.Date;
import java.util.List;

import in.hertz.samast.entity.Generation;

public interface UtilityShareService {

	public List<Generation<Void>> findEntitledGenerators(int utgId, Date forDate);
}
