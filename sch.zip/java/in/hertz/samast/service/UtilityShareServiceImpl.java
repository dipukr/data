package in.hertz.samast.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import in.hertz.samast.dao.GenerationDao;
import in.hertz.samast.dao.TimeIntervalRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.dao.UtilityShareDao;

@Service
public class UtilityShareServiceImpl {
	
	@Autowired
	private UtilityShareDao utilityShareDao;
	
	@Autowired
	private TimeIntervalRepository timeIntervalDao;
	
	@Autowired
	private GenerationDao<Void> generationDao;
	
	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoDao;
	
	
}
