package in.hertz.samast.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.hertz.samast.dao.GenerationDao;
import in.hertz.samast.dao.TimeIntervalRepository;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.dao.UtilityShareDao;
import in.hertz.samast.domain.GeneratorDetailsDTOType;
import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.UtilityShare;

@Service
public class UtilityShareServiceImpl {
	
	@Autowired
	private UtilityShareDao utilityShareDao;
	@Autowired
	private TimeIntervalRepository timeIntervalDao;
	@Autowired
	private GenerationDao<GeneratorDetailsDTOType> generationDao;
	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoDao;
	
	public List<UtilityShare> 
	
	@Override
	public List<UtilityShare> findBeneficiarySharesForDate(Integer utgId, Date forDate, ShareType shareType)
			throws BusinessException {
		List<UtilityShare> beneficiarySharesForDate = null;
		try {
			beneficiarySharesForDate = utilityShareDAO.findBeneficiarySharesForDate(utgId, forDate, shareType);
		} catch (ParseException e) {
			throw new BusinessException("Date is not in proper format");
		}
		return beneficiarySharesForDate;
	}

	@Override
	public List<UtilityShare> findShare(Integer beneficiaryUtgId, Integer utilityUtgId, Date forDate,
			ShareType shareType) throws ParseException {
		return utilityShareDAO.findShare(beneficiaryUtgId, utilityUtgId, forDate, shareType);
	}

	@Override
	public List<UtilityShare> findInjectorShare(Integer utgId, Date forDate, ShareType shareType)
			throws ParseException, BusinessException {
		List<UtilityShare> beneficiarySharesForDate = null;
		beneficiarySharesForDate = utilityShareDAO.findInjectorSharesForDate(utgId, forDate, shareType);
		return beneficiarySharesForDate;
	}

	@Override
	public List<UtilityShareBO> findInjectorShareBO(Integer utgId, Date forDate, ShareType shareType)
			throws ParseException, BusinessException {
		List<UtilityShare> beneficiarySharesForDate = utilityShareDAO.findInjectorSharesForDate(utgId, forDate,
				shareType);
		return transform(beneficiarySharesForDate);
	}

	@Override
	public void addUtilityShare(List<UtilityShareBO> boList) throws BusinessException {
		boolean exists = false;
		StringBuilder msg = new StringBuilder();
		msg.append("Data Aleady exits for these : ");

		for (UtilityShareBO bo : boList) {
			Integer beneficiaryUtgId = bo.getDraweeUtgId();
			Integer utilityUtgId = bo.getInjectorUtgId();
			String type = bo.getType();
			Date fromDate = bo.getFromDate();
			Date toDate = bo.getToDate();
			List<BlockRangeQuantumsDTO> detailsDTO = bo.getDetails();

			Assert.notNull(beneficiaryUtgId, "Beneficiary Id must not be null.");
			Assert.notNull(utilityUtgId, "Utility Id must not be null.");
			Assert.notNull(fromDate, "ValidFrom date must not be null.");
			Assert.notNull(toDate, "ValidTo Date must not be null.");
			Assert.notNull(type, "Share Type must not be null.");
			Assert.notEmpty(detailsDTO, "BlockRangeQuantumsDTO List must contain at least single value.");

			UtilitiesTraderGenco beneficiaryUTG = utgDAO.findOne(beneficiaryUtgId);
			UtilitiesTraderGenco utilityUTG = utgDAO.findOne(utilityUtgId);

			ShareType shareType = ShareType.valueOf(type);
			List<UtilityShare> existShare = utilityShareDAO.findSharedForDateRange(beneficiaryUtgId, utilityUtgId,
					fromDate, toDate, shareType);
			if (existShare != null && !existShare.isEmpty()) {
				msg.append(utilityUTG.getName() + ", ");
				exists = true;
			} else {
				UtilityShare entity = new UtilityShare();
				entity.setBeneficiaryUtg(beneficiaryUTG);
				entity.setInjectorUtg(utilityUTG);
				entity.setFromDate(fromDate);
				entity.setToDate(toDate);
				entity.setShareType(shareType);
				utilityShareDAO.create(entity);
				Set<UtilityShareDetails> detailsSet = new HashSet<>();
				for (BlockRangeQuantumsDTO brqDTO : detailsDTO) {
					UtilityShareDetails detailEntity = new UtilityShareDetails();
					detailEntity.setFromBlock(timeIntervalDAO.findOne(brqDTO.getFromBlockId()));
					detailEntity.setToBlock(timeIntervalDAO.findOne(brqDTO.getToBlockId()));
					detailEntity.setShare(getBigDecimalValue(brqDTO.getQuantum()));
					detailEntity.setRegulatedShare(entity);
					detailsSet.add(detailEntity);
				}
				entity.setShareDetails(detailsSet);
				utilityShareDAO.update(entity);
			}
		}
		if (exists) {
			throw new BusinessException(msg.toString());
		}
	}

	@Override
	public void editUtilityShare(List<UtilityShareBO> bos) throws BusinessException {
		StringBuilder errorMsg = new StringBuilder();
		errorMsg.append("Data already exist for:");
		Boolean exists = false;

		for (UtilityShareBO bo : bos) {
			Integer beneficiaryUtgId = bo.getDraweeUtgId();
			Integer utilityUtgId = bo.getInjectorUtgId();
			Integer shareId = bo.getId();
			String type = bo.getType();
			Date fromDate = bo.getFromDate();
			Date toDate = bo.getToDate();
			List<BlockRangeQuantumsDTO> detailsDTO = bo.getDetails();

			Assert.notNull(shareId, "Utility Share Id must not be null.");
			Assert.notNull(beneficiaryUtgId, "Beneficiary Id must not be null.");
			Assert.notNull(utilityUtgId, "Utility Id must not be null.");
			Assert.notNull(fromDate, "ValidFrom date must not be null.");
			Assert.notNull(toDate, "ValidTo Date must not be null.");
			Assert.notNull(type, "Share Type must not be null.");
			Assert.notEmpty(detailsDTO, "BlockRangeQuantumsDTO List must contain at least single value.");

			ShareType shareType = ShareType.valueOf(type);
			List<UtilityShare> existShare = utilityShareDAO.findSharedForDateRange(beneficiaryUtgId, utilityUtgId,
					fromDate, toDate, shareType);

			if (existShare.size() > 1) {
				errorMsg.append("<br> Beneficiary: " + utgDAO.findOne(beneficiaryUtgId).getName() + " Generator: "
						+ utgDAO.findOne(utilityUtgId).getName() + " and For Date Range: " + bo.getFromDate() + " - "
						+ bo.getToDate() + " .");
				exists = true;
			} else if (existShare.size() == 1 && !existShare.get(0).getUID().equals(shareId)) {
				errorMsg.append("<br> Beneficiary: " + existShare.get(0).getBeneficiaryUtg().getName() + " Generator: "
						+ utgDAO.findOne(utilityUtgId).getName() + " and For Date Range: "
						+ existShare.get(0).getFromDate() + " to " + existShare.get(0).getToDate());
				exists = true;
			} else {
				UtilityShare entity = utilityShareDAO.findOne(shareId);
				utilityShareDetailDAO.deleteByUtilityShare(entity);

				Set<UtilityShareDetails> detailsSet = new HashSet<>();
				for (BlockRangeQuantumsDTO brqDTO : detailsDTO) {
					UtilityShareDetails detailEntity = new UtilityShareDetails();
					detailEntity.setFromBlock(timeIntervalDAO.findOne(brqDTO.getFromBlockId()));
					detailEntity.setToBlock(timeIntervalDAO.findOne(brqDTO.getToBlockId()));
					detailEntity.setShare(getBigDecimalValue(brqDTO.getQuantum()));
					detailEntity.setRegulatedShare(entity);
					detailsSet.add(detailEntity);
					utilityShareDetailDAO.create(detailEntity);
				}
				entity.setFromDate(fromDate);
				entity.setToDate(toDate);
				entity.setBeneficiaryUtg(utgDAO.findOne(beneficiaryUtgId));
				entity.setShareDetails(detailsSet);
				utilityShareDAO.update(entity);
			}
		}
		if (exists) {
			throw new BusinessException(errorMsg.toString());
		}
	}

	@Override
	public void deleteUtilityShare(Integer utilityShareId) {
		utilityShareDAO.deleteById(utilityShareId);
	}

	@Override
	public List<UtilityShareBO> getCompleteBenificaryUtilityShares(Integer beneficiaryUtgId, Date forDate,
			ShareType shareType) throws BusinessException {
		List<UtilityShareBO> utilityShareBOs = new ArrayList<>();
		UtilitiesTraderGenco utg = utgDAO.findOne(beneficiaryUtgId);
		if (utg == null) {
			throw new BusinessException("Utility Not found in Records");
		}

		if (utg.getTypeOfUtilities() == null) {
			throw new BusinessException("Utility Type not set with the selected utility " + utg.getName());
		}
		// it is basically keep utg and it may be discome utg,state utg,ppc
		// utg
		// and soo on

		List<UtilityShareBO> beneficiaryShares = null;
		switch (UtilityType.valueOf(utg.getTypeOfUtilities().getType())) {

		case Generators:
			beneficiaryShares = getBeneficiaryShareBOs(utg.getUID(), forDate, shareType);
			if (beneficiaryShares == null) {
				throw new BusinessException("Share not found for the Utility : " + utg.getName());
			}
			utilityShareBOs.addAll(beneficiaryShares);
			break;
		case DISCOMs:
			Discom discom = discomDAO.getDiscomByUTG(utg);
			// discom Share
			beneficiaryShares = getBeneficiaryShareBOs(utg.getUID(), forDate, shareType);
			if (beneficiaryShares == null) {
				LOG.info("Discoms Share not found for the Utility : {}", utg.getName());
			} else {
				utilityShareBOs.addAll(beneficiaryShares);
			}

			// discom PPC share
			// change method for GAP page NA issue
			DiscomPPCShare discomPPCShare = discomPPCShareService.getPPCShareByUTGId(utg.getUID());
			if (discomPPCShare == null) {
				LOG.info("Discom PPC share not found for {}", utg.getName());
			} else {
				List<UtilityShareBO> trnsfmPpc = null;

				if (discomPPCShare.getPpc() == null) {
					LOG.info("Discom {} not mapped with any PPC ", utg.getName());
				} else {
					trnsfmPpc = getBeneficiaryShareBOs(discomPPCShare.getPpc().getUID(), forDate, shareType);
					if (trnsfmPpc != null) {
						trnsfmPpc = getUtilityShareOfUtilityFromShare(trnsfmPpc, discomPPCShare.getShare());
						utilityShareBOs.addAll(trnsfmPpc);
					}
				}
			}

			// state share
			if (discom.getState() == null) {
				LOG.info("Discom {} not mapped with state", utg.getName());
			} else if (discomPPCShare == null || discomPPCShare.getPpc() == null) {
				LOG.info("Discom {} not mapped with any PPC so State Share can not be divided for", utg.getName());
			} else if (discom.getState().getUtilitiesTraderGenco() != null) {
				List<UtilityShareBO> trnsfmState = getBeneficiaryShareBOs(
						discom.getState().getUtilitiesTraderGenco().getUID(), forDate, shareType);
				if (trnsfmState != null) {
					List<UtilityShareBO> utilityShareOfUtilityFromShare = getUtilityShareOfUtilityFromShare(trnsfmState,
							discomPPCShare.getShare());
					utilityShareBOs.addAll(utilityShareOfUtilityFromShare);
				}
			} else {
				LOG.info("State {} not mapped with any Utg", discom.getState());
			}
			break;
		case Constituents:
			beneficiaryShares = getBeneficiaryShareBOs(utg.getUID(), forDate, shareType);
			if (beneficiaryShares != null && !beneficiaryShares.isEmpty()) {
				utilityShareBOs.addAll(beneficiaryShares);
			} else {
				LOG.info("Constituents share not found for {}", utg.getName());
				throw new BusinessException("Constituents share not found for " + utg.getName());
			}
			break;
		case Trader:
			throw new BusinessException(
					"Utility is of Type" + utg.getTypeOfUtilities().getType() + ",for which Share is not availabe");
		case Exchange:
			throw new BusinessException(
					"Utility is of Type" + utg.getTypeOfUtilities().getType() + ",for which Share is not availabe");
		case State:
			beneficiaryShares = getBeneficiaryShareBOs(utg.getUID(), forDate, shareType);
			if (beneficiaryShares != null && !beneficiaryShares.isEmpty()) {
				utilityShareBOs.addAll(beneficiaryShares);
			} else {
				LOG.info("State share not found for {}", utg.getName());
				throw new BusinessException("State share not found for " + utg.getName());
			}
			break;
		case OA_Consumers:
			beneficiaryShares = getBeneficiaryShareBOs(utg.getUID(), forDate, shareType);
			if (beneficiaryShares != null && !beneficiaryShares.isEmpty()) {
				utilityShareBOs.addAll(beneficiaryShares);
			} else {
				LOG.info("OA_Consumers share not found for {}", utg.getName());
				throw new BusinessException("OA_Consumers share not found for " + utg.getName());
			}
			break;
		case PPC:
			// in this case two case
			// 1 case ppc is benificiary
			// 2 case ppc's belonging state is benificiary then calculate
			// result its share with ppc and add it to list
			// both combined result
			List<UtilityShareBO> beneficiaryShareBOs = getBeneficiaryShareBOs(utg.getUID(), forDate, shareType);
			if (beneficiaryShareBOs != null && !beneficiaryShareBOs.isEmpty()) {
				utilityShareBOs.addAll(beneficiaryShareBOs);
			}

			// in state case with ppc
			PPC ppcByUtgId = ppcdao.getPPCByUtgId(utg);
			List<UtilityShareBO> beneficiaryShareBOs2 = getBeneficiaryShareBOs(
					ppcByUtgId.getState().getUtilitiesTraderGenco().getUID(), forDate, shareType);
			if (beneficiaryShareBOs2 != null && !beneficiaryShareBOs2.isEmpty()) {
				List<UtilityShareBO> utilityShareOfUtilityFromShare = getUtilityShareOfUtilityFromShare(
						beneficiaryShareBOs2, 100f);
				utilityShareBOs.addAll(utilityShareOfUtilityFromShare);
			}
			break;
		default:
			LOG.warn("For the specified Utility type share not found for {}", utg.getName());
			break;
		}
		return mergeShareBOs(utilityShareBOs);
	}

	protected List<UtilityShareBO> getUtilityShareOfUtilityFromShare(List<UtilityShareBO> utilityShareBOs,
			Float share) {

		if (utilityShareBOs == null) {
			return new ArrayList<>();
		}
		for (UtilityShareBO utilityShareBO : utilityShareBOs) {
			for (BlockRangeQuantumsDTO utilityShareDetailBo : utilityShareBO.getDetails()) {
				utilityShareDetailBo.setQuantum((utilityShareDetailBo.getQuantum() / 100) * share);
			}

		}

		LOG.info("return Result drawlSchedules for Utility from PPC Share size is --> {}", utilityShareBOs.size());
		return utilityShareBOs;
	}

	protected List<UtilityShareBO> transformList(List<UtilityShare> utilityShares) {
		List<UtilityShareBO> utilityShareBOs = new ArrayList<>();
		try {
			if (utilityShares != null) {
				for (UtilityShare utilityShare : utilityShares) {
					utilityShareBOs.add(EntityTransformer.transform(utilityShare));
				}
			}
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
		}
		return utilityShareBOs;
	}

	@Override
	public UtilityShareBO findById(Integer id) {
		UtilityShare utilityShare = utilityShareDAO.findOne(id);
		return EntityTransformer.transform(utilityShare);
	}

	List<UtilityShareBO> transform(List<UtilityShare> utilityShares) {
		List<UtilityShareBO> shareBos = null;
		if (utilityShares == null) {
			return shareBos;
		}
		shareBos = new ArrayList<>();
		for (UtilityShare share : utilityShares) {
			shareBos.add(EntityTransformer.transform(share));
		}
		return shareBos;
	}

	@Override
	public List<UtilitiesTraderGenco> findEntitledUtgs(Integer utgId, Date forDate, ShareType shareType)
			throws BusinessException {
		List<UtilityShare> shares = findBeneficiarySharesForDate(utgId, forDate, shareType);
		if (shares == null) {
			throw new BusinessException("No share found.");
		}
		List<UtilitiesTraderGenco> allocatedUtgs = new ArrayList<>();
		for (UtilityShare sh : shares) {
			allocatedUtgs.add(sh.getInjectorUtg());
		}
		return allocatedUtgs;
	}

	@Override
	public List<Generation> findEntitledGenerators(Integer utgId, Date forDate) throws BusinessException {
		UtilitiesTraderGenco utg = utgDAO.findOne(utgId);
		List<Integer> utgIds = new ArrayList<>();

		if (utg.getTypeOfUtilities().getType().equals(UtilityType.DISCOMs.name())) {
			Discom discom = discomDAO.getDiscomByUtgId(utgId);
			utgIds.add(discom.getState().getUtilitiesTraderGenco().getUID());
		} else if (utg.getTypeOfUtilities().getType().equals(UtilityType.PPC.name())) {
			PPC ppc = ppcdao.getPPCByUtgId(utg);
			utgIds.add(ppc.getState().getUtilitiesTraderGenco().getUID());
		} else if (utg.getTypeOfUtilities().getType().equals(UtilityType.State.name())) {
		} else if (utg.getTypeOfUtilities().getType().equals(UtilityType.Constituents.name())) {
		} else {
			throw new BusinessException(
					"Specified Utility is of type " + utg.getUtilityType().name() + ", not supported for Entitlement");
		}
		utgIds.add(utgId);

		Set<Generation> set = new HashSet<>();
		for (Integer utilityId : utgIds) {
			List<Generation> allocatedGenerators = findEntitledGenerators(utilityId, forDate, ShareType.ALLOCATED);
			List<Generation> unAllocatedGenerators = findEntitledGenerators(utilityId, forDate, ShareType.UN_ALLOCTED);
			if (unAllocatedGenerators != null && !unAllocatedGenerators.isEmpty()) {
				set.addAll(unAllocatedGenerators);
			}
			if (allocatedGenerators != null && !allocatedGenerators.isEmpty()) {
				set.addAll(allocatedGenerators);
			}
		}

		List<Generation> list = new ArrayList<>();
		if (!set.isEmpty()) {
			list.addAll(set);
			Collections.sort(list);
		}
		return list;
	}

	@Override
	public List<Generation> findEntitledGenerators(Integer utgId, Date forDate, ShareType shareType)
			throws BusinessException {
		List<UtilitiesTraderGenco> findEntitledUtgs = findEntitledUtgs(utgId, forDate, shareType);
		List<Generation> allocatedGencos = null;
		if (findEntitledUtgs != null) {
			allocatedGencos = new ArrayList<>();
			for (UtilitiesTraderGenco utg : findEntitledUtgs) {
				if (utg.getTypeOfUtilities().getType().equals(UtilityType.Generators.name())) {
					Generation gencoByUTG = generationDAO.getGencoByUTG(utg);
					if (gencoByUTG != null)
						allocatedGencos.add(gencoByUTG);
				}
			}
		}
		return allocatedGencos;
	}

	BigDecimal getBigDecimalValue(Float f) {
		return new BigDecimal(f.toString());
	}

	List<UtilityShareBO> getBeneficiaryShareBOs(Integer utgId, Date forDate, ShareType shareType)
			throws BusinessException {
		List<UtilityShare> beneficiaryShares = null;
		List<UtilityShareBO> transformList = null;
		beneficiaryShares = findBeneficiarySharesForDate(utgId, forDate, shareType);
		if (beneficiaryShares != null && !beneficiaryShares.isEmpty()) {
			transformList = transformList(beneficiaryShares);
		}
		return transformList;
	}

	List<UtilityShareBO> mergeShareBOs(List<UtilityShareBO> baseList) {
		Map<Integer, UtilityShareBO> boMap = new HashMap<>();
		Map<Integer, Float[]> gencoQuntm = new HashMap<>();

		for (UtilityShareBO utilityShareBO : baseList) {
			Float[] quantums = gencoQuntm.get(utilityShareBO.getInjectorUtgId());
			boMap.put(utilityShareBO.getInjectorUtgId(), utilityShareBO);
			if (quantums == null) {
				quantums = new Float[97];
			}
			for (BlockRangeQuantumsDTO blk1 : utilityShareBO.getDetails()) {
				for (int block = blk1.getFromBlockId(); block <= blk1.getToBlockId(); block++) {
					if (quantums[block] != null) {
						quantums[block] = quantums[block] + blk1.getQuantum();
					} else {
						quantums[block] = blk1.getQuantum();
					}
				}
			}
			gencoQuntm.put(utilityShareBO.getInjectorUtgId(), quantums);
		}

		for (Entry<Integer, UtilityShareBO> e : boMap.entrySet()) {
			List<BlockRangeQuantumsDTO> setBlocks = setBlocksQuantum(gencoQuntm.get(e.getKey()));
			e.getValue().setDetails(setBlocks);
		}
		return new ArrayList<>(boMap.values());
	}

	public List<BlockRangeQuantumsDTO> setBlocksQuantum(Float[] quantams) {
		Float preQ = null;
		Integer endBlock = null;
		Integer startBlock = null;
		List<BlockRangeQuantumsDTO> blocks = new ArrayList<>();
		for (int block = 1; block < quantams.length; block++) {
			Float q = quantams[block];
			if (q == null && preQ == null) {
				continue;
			}
			if (q != null) {
				if (startBlock == null) {
					startBlock = block;
					preQ = q;
				} else {// quantum same as previous
					if (q.equals(preQ)) {
						endBlock = block;
						preQ = q;
					} // quantum not as previous add the block with quantum and blocks
					else {
						// add to list
						BlockRangeQuantumsDTO b2 = new BlockRangeQuantumsDTO();
						b2.setFromBlockId(startBlock);
						b2.setQuantum(preQ);
						b2.setToBlockId(endBlock);
						blocks.add(b2);
						startBlock = block;
						endBlock = block;
						preQ = q;
					}
				}
			}
		}
		BlockRangeQuantumsDTO b2 = new BlockRangeQuantumsDTO();
		b2.setFromBlockId(startBlock);
		b2.setQuantum(preQ);
		b2.setToBlockId(endBlock);
		blocks.add(b2);
		return blocks;
	}

	@Override
	public List<UtilitiesTraderGencoBO> findEntitledBeneficiaries(Integer utgId, ShareType shareType,
			String utilityTypeStr) throws BusinessException {
		List<UtilitiesTraderGencoBO> utgBOList = new ArrayList<>();
		List<UtilityShare> findInjectorShare = utilityShareDAO.findInjectorShares(Arrays.asList(utgId), shareType);
		if (findInjectorShare == null || findInjectorShare.isEmpty()) {
			throw new BusinessException(
					"Entitled beneficiaries not found for Generator: " + utgDAO.findOne(utgId).getName());
		}
		for (UtilityShare utilityShare : findInjectorShare) {
			UtilitiesTraderGenco beneficiaryUtg = utilityShare.getBeneficiaryUtg();
			if (utilityTypeStr != null) {
				if (StringUtils.equalsIgnoreCase(beneficiaryUtg.getTypeOfUtilities().getType(), utilityTypeStr)) {
					UtilitiesTraderGencoBO utg = EntityTransformer.transform(beneficiaryUtg);
					utgBOList.add(utg);
				}
			} else {
				UtilitiesTraderGencoBO utg = EntityTransformer.transform(beneficiaryUtg);
				utgBOList.add(utg);
			}
		}
		return utgBOList;
	}

	@Override
	public List<ObjectBO> findEntitledBeneficiariesByGeneratorIDs(List<UtilitiesTraderGencoBO> utgBOs,
			ShareType shareType) throws BusinessException {
		if (utgBOs == null || utgBOs.size() <= 0) {
			throw new BusinessException("Please assign atleast one generator.");
		}
		List<Integer> gencoUTGIds = new ArrayList<>();
		utgBOs.forEach(utg -> gencoUTGIds.add(utg.getUtilitiesTraderGencoId()));

		Map<Integer, List<UtilityShare>> utilityShareMap = new TreeMap<>();
		List<UtilityShare> list = null;
		List<UtilityShare> utilityShareList = utilityShareDAO.findInjectorShares(gencoUTGIds, shareType);
		for (UtilityShare utilityShare : utilityShareList) {
			if (utilityShareMap.get(utilityShare.getInjectorUtg().getUID()) == null) {
				list = new ArrayList<>();
				utilityShareMap.put(utilityShare.getInjectorUtg().getUID(), list);
			}
			utilityShareMap.get(utilityShare.getInjectorUtg().getUID()).add(utilityShare);
			utilityShareMap.put(utilityShare.getInjectorUtg().getUID(), list);
		}

		List<ObjectBO> gencoBOList = new ArrayList<>();
		for (Map.Entry<Integer, List<UtilityShare>> entry : utilityShareMap.entrySet()) {
			List<ObjectBO> beneficiaryBOList = new ArrayList<>();
			List<UtilityShare> shareList = entry.getValue();
			for (UtilityShare utilityShare : shareList) {
				ObjectBO beneficiaryBO = new ObjectBO();
				beneficiaryBO.setID(utilityShare.getBeneficiaryUtg().getUID());
				beneficiaryBO.setName(utilityShare.getBeneficiaryUtg().getName());
				beneficiaryBOList.add(beneficiaryBO);
			}
			ObjectBO gencoBO = new ObjectBO();
			gencoBO.setID(entry.getKey());
			gencoBO.setName(shareList.get(0).getInjectorUtg().getName());
			gencoBO.setObjectList(beneficiaryBOList);
			gencoBOList.add(gencoBO);
		}

		return gencoBOList;
	}

	@Override
	public Map<String, Object> getDrawlEntitiesShare(Integer utilityUtgId) throws BusinessException {
		Float share = 1.0f;
		UtilitiesTraderGenco utg = utgDAO.findOne(utilityUtgId);
		DiscomPPCShare ppcShareByDiscomUTG = null;
		List<Integer> draweeUTGs = new ArrayList<>();
		List<Integer> draweePPCUTGs = new ArrayList<>();
		String utgType = utg.getTypeOfUtilities().getType();
		Map<String, Object> values = new HashMap<>();
		// change method for GAP page NA issue
		if (utgType.equals(UtilityType.DISCOMs.name())) {
			ppcShareByDiscomUTG = discomPPCShareService.getPPCShareByUTGId(utilityUtgId);
			draweeUTGs.add(utilityUtgId);
			if (ppcShareByDiscomUTG == null) {
				LOG.warn("NO Entry Found in PPC Share for Discom with UTGID# {}", utilityUtgId);
			} else {
				// discom Share % of PPC
				draweePPCUTGs.add(ppcShareByDiscomUTG.getPpc().getUID());
				share = ppcShareByDiscomUTG.getShare() / 100;
			}
		} else if (utgType.equals(UtilityType.State.name())) {
			// adding all discoms utgs of the state ,to get all the contracts of the
			// discoms
			List<Integer> findBeneficiariesByStateUtgId = findStateDiscoms(utg.getUID());
			if (findBeneficiariesByStateUtgId != null && !findBeneficiariesByStateUtgId.isEmpty()) {
				draweePPCUTGs.addAll(findBeneficiariesByStateUtgId);
			}
			List<PPC> ppcUtgs = discomPPCShareService.findByStateUtgId(utg.getUID());
			draweePPCUTGs.add(utilityUtgId);
			for (PPC ppc : ppcUtgs) {
				if (ppc.getUtilitiesTraderGenco() != null) {
					draweePPCUTGs.add(ppc.getUtilitiesTraderGenco().getUID());
				}
			}
		} else if (utgType.equals(UtilityType.PPC.name())) {
			List<PPC> ppcUtgs = discomPPCShareService.findByStateUtgId(utg.getUID());
			draweePPCUTGs.add(utilityUtgId);
			for (PPC ppc : ppcUtgs) {
				if (ppc.getUtilitiesTraderGenco() != null) {
					draweePPCUTGs.add(ppc.getUtilitiesTraderGenco().getUID());
				}
			}
		} else {
			throw new BusinessException(
					String.format("Type of Utility {} is not supported for Drawl Schedule Calculation ",
							utg.getTypeOfUtilities().getType()));
		}
		values.put(DISCOM_UTGS, draweeUTGs);
		values.put(PPC_UTGS, draweePPCUTGs);
		values.put(SHARE, share);
		values.put(UTG_TYPE, utgType);
		return values;
	}

	public List<Integer> findStateDiscoms(Integer utgId) {
		List<Integer> stateDiscomsUtgs = null;
		if (utgId != null) {
			List<Discom> discoms = discomDAO.findByStateUtgId(utgId);
			stateDiscomsUtgs = new ArrayList<>();
			for (Discom discom : discoms) {
				if (discom.getUtilitiesTraderGenco() != null) {
					stateDiscomsUtgs.add(discom.getUtilitiesTraderGenco().getUID());
				}
			}
		}
		return stateDiscomsUtgs;
	}

	@Override
	public List<UtilityShareBO> viewProfitRatio(String forDateStr, List<Integer> utgIds, String profitSharingType)
			throws ParseException {
		Assert.notNull(forDateStr, "Date must not be null.");
		SimpleDateFormat sdf = new SimpleDateFormat(DateFormats.DD_MM_YYYY);
		Date forDate = sdf.parse(forDateStr);

		List<UtilityShare> entityList = utilityShareDAO.findSharesByDateAndGencoUTGIds(utgIds,
				ShareType.valueOf(profitSharingType), forDate);
		List<UtilityShareBO> boList = new ArrayList<>();
		for (UtilityShare entity : entityList) {
			boList.add(EntityTransformer.transform(entity));
		}
		return boList;
	}

	@Override
	public List<UtilityShareBO> getDiscomProfitShare(UtilityShareBO requestBO) throws BusinessException {
		List<UtilityShareBO> responseBOList = new ArrayList<>();
		Assert.notNull(requestBO.getType(), "Please provide valid parameters.");
		if (requestBO.getInjectorUtgId() == null
				&& (requestBO.getFromDate() == null && requestBO.getToDate() == null)) {
			throw new BusinessException("Please provide either injector ID or DateRange.");
		}
		ShareType type = ShareType.valueOf(requestBO.getType());
		Assert.notNull(type, requestBO.getType() + " enum type not defined, Please contact to admin.");

		List<UtilityShare> utilityShareList = null;
		if (requestBO.getInjectorUtgId() != null && requestBO.getFromDate() != null && requestBO.getToDate() != null) {
			utilityShareList = utilityShareDAO.findInjectorShareForDateRange(requestBO.getInjectorUtgId(),
					requestBO.getFromDate(), requestBO.getToDate(), type);
		} else if (requestBO.getInjectorUtgId() != null) {
			utilityShareList = utilityShareDAO.findInjectorShares(Arrays.asList(requestBO.getInjectorUtgId()), type);
		} else if (requestBO.getFromDate() != null && requestBO.getToDate() != null) {
			utilityShareList = utilityShareDAO.findSharesByDateRange(type, requestBO.getFromDate(),
					requestBO.getToDate());
		}

		for (UtilityShare utilityShare : utilityShareList) {
			TypeOfUtilities utilityType = utilityShare.getBeneficiaryUtg().getTypeOfUtilities();
			Assert.notNull(utilityType,
					utilityShare.getBeneficiaryUtg() + " utility type not defined, Please contact to admin.");

			UtilityShareBO utilityShareBO = new UtilityShareBO();
			utilityShareBO.setId(utilityShare.getUID());
			utilityShareBO.setFromDate(utilityShare.getFromDate());
			utilityShareBO.setToDate(utilityShare.getToDate());
			utilityShareBO.setInjectorUtgId(utilityShare.getInjectorUtg().getUID());
			utilityShareBO.setInjectorName(utilityShare.getInjectorUtg().getName());
			utilityShareBO.setType(utilityShare.getShareType().name());
			for (UtilityShareDetails detailObj : utilityShare.getShareDetails()) {
				utilityShareBO.addDetail(EntityTransformer.transform(detailObj));
			}

			if (StringUtils.equalsIgnoreCase(utilityType.getType(), "DISCOMs")) {
				Discom discom = discomDAO.getDiscomByUTG(utilityShare.getBeneficiaryUtg());
				UtilitiesTraderGenco stateUTG = discom.getState().getUtilitiesTraderGenco();
				utilityShareBO.setDiscomName(utilityShare.getBeneficiaryUtg().getName());
				utilityShareBO.setDiscomUtgId(utilityShare.getBeneficiaryUtg().getUID());
				utilityShareBO.setDraweeUtgId(stateUTG.getUID());
				utilityShareBO.setDraweeName(stateUTG.getName());
			} else {
				utilityShareBO.setDraweeUtgId(utilityShare.getBeneficiaryUtg().getUID());
				utilityShareBO.setDraweeName(utilityShare.getBeneficiaryUtg().getName());
			}
			responseBOList.add(utilityShareBO);
		}
		return responseBOList;
	}

}
UtilityShareService