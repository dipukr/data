package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.hertz.samast.ctrl.BusinessException;
import in.hertz.samast.ctrl.DateTime;
import in.hertz.samast.ctrl.Generation;
import in.hertz.samast.ctrl.HashSet;
import in.hertz.samast.ctrl.HibernateException;
import in.hertz.samast.ctrl.JSONArray;
import in.hertz.samast.ctrl.JSONException;
import in.hertz.samast.ctrl.JSONObject;
import in.hertz.samast.ctrl.ParseException;
import in.hertz.samast.ctrl.Set;
import in.hertz.samast.ctrl.SimpleDateFormat;
import in.hertz.samast.ctrl.UtilitiesTraderGencoBO;
import in.hertz.samast.dao.EntitlementDao;
import in.hertz.samast.dao.GenerationDao;
import in.hertz.samast.domain.GeneratorDetailsDTOType;
import in.hertz.samast.domain.UrsBO;
import in.hertz.samast.entity.Entitlement;
import in.hertz.samast.entity.UtilitiesTraderGenco;

@Service
public class EntitlementServiceImpl implements EntitlementService {
	
	public List<UrsBO> getSgsIsgsEntitlement(Integer beneficiaryUTGId, Date forDate) throws BusinessException {
		List<UrsBO> entitlementForUtility = getBuyerEntitlementForDatasource(beneficiaryUTGId, forDate, SELUtil.RLDC);
		try {
			if (entitlementForUtility == null || entitlementForUtility.isEmpty()) {
				entitlementForUtility = getUtilityShareOfDCOfGencoTypes(beneficiaryUTGId, forDate,
						ContractType.ISGS.name());
			}
		} catch (BusinessException e) {
			LOG.warn("Error ", e.getMessage());
		}
		try {
			// sgs entitlement
			List<UrsBO> beneficiarySGSEntitlement = getUtilityShareOfDCOfGencoTypes(beneficiaryUTGId, forDate,
					ContractType.SGS.name());
			if (beneficiarySGSEntitlement != null) {
				entitlementForUtility.addAll(beneficiarySGSEntitlement);
			}
		} catch (BusinessException e) {
			LOG.warn("Error ", e.getMessage());
		}
		return entitlementForUtility;
	}
	
	/***
	 * 
	 * @param utgId
	 * @param forDate
	 * @param gencoType
	 * @return UrsBO list converted from DC share find for Beneficiary/Buyer for
	 *         specified type of Gencos and date
	 * @throws BusinessException
	 */
	@Override
	public List<UrsBO> getUtilityShareOfDCOfGencoTypes(Integer utgId, Date forDate, String gencoType)
			throws BusinessException {
		List<Integer> gencoUtgs = getBeneficiaryEntitledGencosUtgsByType(utgId, forDate, gencoType);
		return getUtilityShareOfDCByGencoUtgs(utgId, forDate, gencoUtgs);
	}

	/***
	 * 
	 * @param utgId
	 * @param forDate
	 * @return UrsBO list converted from DC Share find for Beneficiary/Buyer for
	 *         specified List of GencoUtgs and date if gencoUtgs is null then all
	 *         generators having share with beneficiary returned else only for the
	 *         specified.
	 * @throws BusinessException
	 */
	@Override
	public List<UrsBO> getUtilityShareOfDCByGencoUtgs(Integer utgId, Date forDate, List<Integer> gencoUtgs)
			throws BusinessException {
		Map<Integer, Map<Integer, Float>> utilityShareMap = getUtilityShareMap(utgId, forDate);
		UtilitiesTraderGenco utg = utilitiesTraderGencoDAO.findOne(utgId);
		if (utg == null) {
			LOG.error("Utility with #{} not found for share allocation", utgId);
			throw new BusinessException("Requested Utility not Found in records ");
		}
		String name = utg.getName();
		List<UrsBO> dcShare = new ArrayList<>();
		List<Integer> gencUtgIds = new ArrayList<>();
		if (utilityShareMap == null || utilityShareMap.isEmpty()) {
			LOG.warn("No share alloaction found for Date {} for UtilityId  {}", forDate, utgId);
			throw new BusinessException(
					"No share allocation found for Date " + forDate + " for UtilityId :" + utg.getName());
		}
		// if gencos are null then find share for all gencos having share with
		// beneficiary
		if (gencoUtgs == null) {
			gencUtgIds.addAll(utilityShareMap.keySet());
		} else {
			gencUtgIds = gencoUtgs;
		}
		List<DeclareCapability> decCap = null;

		decCap = declareCapabilityService.getDeclaredCapabilityByGencoUtgsDateRange(gencUtgIds, forDate, forDate);

		if (decCap == null) {
			LOG.error("NO dc found for Date {} for UtilityId  {}", forDate, utgId);
			throw new BusinessException("Declared Capability not found for Date " + forDate + " for " + utg.getName());
		}
		for (DeclareCapability declareCapability : decCap) {
			Integer gencUtg = declareCapability.getUtilitiesTraderGenco().getUID();
			try {
				Map<Integer, Float> shareMap = utilityShareMap.get(gencUtg);
				List<BlockQuantumsDTO> blocks = new ArrayList<>();
				for (DeclareCapabilityDetails dcd : declareCapability.getCapabilityDetails()) {
					Float sharePerc = shareMap.get(dcd.getTimeIntervalId());
					if (sharePerc != null) {
						BlockQuantumsDTO block = new BlockQuantumsDTO();
						if (dcd.getQuantumOnBar() != null) {
							block.setQuantum(dcd.getQuantumOnBar() * (sharePerc / 100));
						} else {
							block.setQuantum(dcd.getQuantumOfPower() * (sharePerc / 100));
						}
						block.setTimeBlockId(dcd.getTimeIntervalId());
						blocks.add(block);
					}
				}
				UtilitiesTraderGenco gencoUtg = utilitiesTraderGencoDAO.findOne(gencUtg);
				UrsBO bo = new UrsBO();
				bo.setDiscomName(name);
				bo.setDiscomUTGId(utgId);
				bo.setGencoUTGId(gencUtg);
				bo.setGencoName(gencoUtg.getName());
				bo.setForDate(forDate);
				bo.setDataSource("Share%");
				bo.setUtgId(utgId);
				bo.setUtilityName(name);
				Collections.sort(blocks);
				bo.setDetails(blocks);
				dcShare.add(bo);
			} catch (Exception e) {
				LOG.error(e.getMessage(), e);
				throw new BusinessException("Error while processing Data");
			}
		}
		return dcShare;
	}
	
	@Override
	public String generateExcelForEntitlement(Integer utilityUtgId, Date forDate, String dataSource)
			throws BusinessException, FileNotFoundException, IOException {
		
//		List<UrsBO> ursBOList = handledUrsForEntitlement(utilityUtgId, forDate, dataSource);
		List<UrsBO> ursBOList = getDetailedEntitlement(utilityUtgId, forDate, dataSource);


		if (ursBOList.isEmpty()) {
			throw new BusinessException("Enitilement Not found for UTG: {}" + utilityUtgId + " Date {}" + forDate);
		}
		String tempProperty = "java.io.tmpdir";
		SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyy");

		String utgName = utilitiesTraderGencoDAO.findOne(utilityUtgId).getName();
		String tempDir = System.getProperty(tempProperty);

		String reportName = "ISGS_Entitlement_Report_" + utgName + "_" + sdf.format(forDate) + ".xls";
		List<UrsBO> list = new ArrayList<>();
		for (UrsBO ursBO : ursBOList) {
			Generation gencoByUtgID = generationDAO.getGencoByUtgID(ursBO.getGencoUTGId());
			if (gencoByUtgID.getGenerationTypeDetail().getGenerationTypeShortName().equals(ContractType.SGS.name())) {

				continue;
			}
			list.add(ursBO);

		}
		ExcelFileUtilities.generateEntitlementDetailsExcel(list, tempDir + "/" + reportName);
		// new BusinessException("ISGS ENtitlement Excel Uploaded
		// Successfully");
		return reportName;
	}

	@Override
	public List<UrsBO> getDetailedEntitlement(Integer utilityUtgId, Date forDate, String dataSource)
			throws BusinessException {
		List<UrsBO> buyerEntitlementForDatasource = null;
		buyerEntitlementForDatasource = getBuyerEntitlementForDatasource(utilityUtgId, forDate, dataSource);

		if (buyerEntitlementForDatasource != null && buyerEntitlementForDatasource.isEmpty()) {
			buyerEntitlementForDatasource = getUtilityShareOfDC(utilityUtgId, forDate);
		}
		return buyerEntitlementForDatasource;
	}
	
	@Override
	public List<UrsBO> getBuyerEntitlementForDatasource(Integer buyerUTGId, Date forDate, String dataSourceStr) {
		List<UrsBO> list = new ArrayList<>();
		List<Entitlement> buyerEntitlementByDatasource = getBuyerEntitlementByDatasource(buyerUTGId, forDate,
				dataSourceStr);
		if (buyerEntitlementByDatasource != null && !buyerEntitlementByDatasource.isEmpty()) {
			for (Entitlement entitlement : buyerEntitlementByDatasource) {
				UrsBO bo = new UrsBO();
				bo.setUtgId(entitlement.getDrawingEntity().getUID());
				bo.setUtilityName(entitlement.getDrawingEntity().getName());
				bo.setGencoName(entitlement.getInjectingEntity().getName());
				bo.setGencoUTGId(entitlement.getInjectingEntity().getUID());
				bo.setForDate(forDate);
				bo.setDataSource(entitlement.getDataSource().name());
				bo.setIssueDate(entitlement.getIssueDate());
				List<BlockQuantumsDTO> blocks = new ArrayList<>();
				for (EntitlementDetails ent : entitlement.getEntitlementDetails()) {
					BlockQuantumsDTO block = new BlockQuantumsDTO();
					block.setQuantum(ent.getOnbarQuantumOfPower());
					block.setTimeBlockId(ent.getTimeIntervalId());
					blocks.add(block);
				}
				Collections.sort(blocks);
				bo.setDetails(blocks);
				list.add(bo);
			}
		}
		return list;
	}
	
	public List<UrsBO> getSgsIsgsEntitlement(Integer beneficiaryUTGId, Date forDate) throws BusinessException {
		List<UrsBO> entitlementForUtility = getBuyerEntitlementForDatasource(beneficiaryUTGId, forDate, SELUtil.RLDC);
		try {
			if (entitlementForUtility == null || entitlementForUtility.isEmpty()) {
				entitlementForUtility = getUtilityShareOfDCOfGencoTypes(beneficiaryUTGId, forDate,
						ContractType.ISGS.name());
			}
		} catch (BusinessException e) {
			LOG.warn("Error ", e.getMessage());
		}
		try {
			// sgs entitlement
			List<UrsBO> beneficiarySGSEntitlement = getUtilityShareOfDCOfGencoTypes(beneficiaryUTGId, forDate,
					ContractType.SGS.name());
			if (beneficiarySGSEntitlement != null) {
				entitlementForUtility.addAll(beneficiarySGSEntitlement);
			}
		} catch (BusinessException e) {
			LOG.warn("Error ", e.getMessage());
		}
		return entitlementForUtility;
	}
	
	@Override
	public List<UtilitiesTraderGencoBO> getEntitledGeneratorsByDateRange(JSONObject jsonObj)
			throws BusinessException, JSONException {
		// TODO Auto-generated method stub
		List<UtilitiesTraderGencoBO> entitledGeneratorList = new ArrayList<UtilitiesTraderGencoBO>();
		String msg = null;
		List<Integer> utgIds = null;
		if (jsonObj.equals(null)) {
			throw new BusinessException("Please submit proper request");
		} else {
			JSONArray jsonArray = jsonObj.getJSONArray("discomIds");
			utgIds = new ArrayList<>();
			for (int i = 0; i < jsonArray.length(); i++) {
				int discomIds = jsonArray.getInt(i);

				// Integer utgId =
				// discomDAO.findOne(int1).getUtilitiesTraderGenco().getUID();
				utgIds.add(discomIds);
			}
			Set<UtilitiesTraderGencoBO> gencoSet = new HashSet<UtilitiesTraderGencoBO>();
			Set<Integer> ids = new HashSet<>();
			String fromDateStr = "";
			String toDateStr = "";
			SimpleDateFormat df = new SimpleDateFormat(DateFormats.DD_MM_YYYY);
			Date fDate = null;
			Date tDate = null;
			try {

				if (!jsonObj.getString("fromDate").isEmpty()) {
					fromDateStr = jsonObj.getString("fromDate");
					fDate = df.parse(fromDateStr);
				}
				if (!jsonObj.getString("toDate").isEmpty()) {
					toDateStr = jsonObj.getString("toDate");
					tDate = df.parse(toDateStr);
				}
				List<Generation> entitledGenerator = new ArrayList<Generation>();
				for (DateTime date = new DateTime(fDate); date.toDate().compareTo(tDate) <= 0; date = date.plusDays(1)) {

					for (Integer utg : utgIds) {
						entitledGenerator.addAll(getEntitledGenerator(utg, date.toDate()));
					}
				}
				for (Generation generation : entitledGenerator) {
					if (ids.contains(generation.getUtilitiesTraderGenco().getUID())) {
						continue;
					}
					ids.add(generation.getUtilitiesTraderGenco().getUID());
					UtilitiesTraderGencoBO transform = EntityTransformer
							.transform(generation.getUtilitiesTraderGenco());
					gencoSet.add(transform);
				}
				entitledGeneratorList.addAll(gencoSet);
				Collections.sort(entitledGeneratorList);
			} catch (HibernateException | JSONException | ParseException ex) {
				throw new BusinessException(" error in getting Entitled Generators for given Date Range", ex);
			}
			return entitledGeneratorList;
		}
	}
	
	public List<Generation> getEntitledGenerator(Integer utilityUtgId, Date fromDate) throws BusinessException {
		return utilityShareService.findEntitledGenerators(utilityUtgId, fromDate);

	}
	
	@Override
	public UrsBO getUtilityGencoDCShare(Integer beneficiaryUtgId, Integer InjectorUtgId, Date forDate, ShareType shareType) throws BusinessException {
		// Genco Utg as key, value =<block ,quantum>
		Map<Integer, Map<Integer, Float>> shareMap = getUtilityShareMap(beneficiaryUtgId, InjectorUtgId, forDate, shareType);
		List<Integer> gencoList = new ArrayList<Integer>(InjectorUtgId);
		gencoList.add(InjectorUtgId);
		UrsBO bo = null;
		if (shareMap != null && !shareMap.isEmpty()) {
			List<UrsBO> entitlementForUtilityGencoIds = new ArrayList<>();
			UrsBO entitlementUrsBo = getEntitlementByForDateGencoAndDraweeId(beneficiaryUtgId, InjectorUtgId, forDate);
			if (entitlementUrsBo != null) {
				entitlementForUtilityGencoIds.add(entitlementUrsBo);
			} else {
				entitlementForUtilityGencoIds = getEntitlementForUtilityGencoIdsDateWise(beneficiaryUtgId, forDate, forDate, false, gencoList);
			}

			if (entitlementForUtilityGencoIds != null) {
				for (UrsBO ursBo : entitlementForUtilityGencoIds) {
					Map<Integer, Float> blockShareMap = shareMap.get(ursBo.getGencoUTGId());
					for (BlockQuantumsDTO block : ursBo.getDetails()) {
						Float share = blockShareMap.get(block.getTimeBlockId());
						if (share == null) {
							share = 0.0f;
						}
						block.setQuantum(block.getQuantum() * (share / 100));
					}
					bo = ursBo;
				}
			}
		} else {
			throw new BusinessException(shareType.name() + " SHARE NOT FOUND");
		}

		return bo;
	}
	
	@Override
	public UrsBO getEntitlementByForDateGencoAndDraweeId(Integer utilityUtgId, Integer gencoUtgId, Date forDate) {
		UrsBO ursBo = null;
		Entitlement entitlement = entitlementDAO.findEntitlement(utilityUtgId, gencoUtgId, forDate);
		if (entitlement == null) {
			return ursBo;
		} else {
			ursBo = new UrsBO();
			ursBo.setUtilityName(entitlement.getDrawingEntity().getName());
			ursBo.setGencoName(entitlement.getInjectingEntity().getName());
			ursBo.setGencoUTGId(entitlement.getInjectingEntity().getUID());
			ursBo.setForDate(entitlement.getForDate());
			ursBo.setDataSource(entitlement.getDataSource().name());
			ursBo.setRevisionNo(entitlement.getRevision());

			List<BlockQuantumsDTO> dtoList = new ArrayList<>();
			Set<EntitlementDetails> details = entitlement.getEntitlementDetails();
			for (EntitlementDetails detail : details) {
				BlockQuantumsDTO dto = new BlockQuantumsDTO();
				dto.setTimeBlockId(detail.getTimeIntervalId());
				dto.setAvailQuantum(detail.getOnbarQuantumOfPower());
				dto.setQuantum(detail.getOnbarQuantumOfPower());
				dtoList.add(dto);
			}
			Collections.sort(dtoList);
			ursBo.setDetails(dtoList);
			return ursBo;
		}
	}
}
