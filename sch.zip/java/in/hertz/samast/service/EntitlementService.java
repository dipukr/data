package in.hertz.samast.service;

import java.util.Date;
import java.util.List;
import in.hertz.samast.domain.UrsBO;

public interface EntitlementService {
	
	public List<UrsBO> findDetailedEntitlement(int discomId, Date forDate, int revision, String gencoType);
	public List<UrsBO> findDetailedEntitlementForSGS(int discomId, Date forDate, int revision);
	public List<UrsBO> findDetailedEntitlementForISGS(int discomId, Date forDate, int revision);
	public List<UrsBO> findDetailedEntitlementForSolar(int discomId, Date forDate, int revision);
}