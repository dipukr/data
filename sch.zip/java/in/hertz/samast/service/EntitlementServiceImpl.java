package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import in.hertz.samast.dao.GenerationDao;
import in.hertz.samast.domain.UrsBO;
import in.hertz.samast.entity.Generation;

@Service
public class EntitlementServiceImpl implements EntitlementService {
	
	@Autowired
	private UtilityShareService utilityShareService;
	
	@Autowired
	private GenerationDao<Void> generationDao;
	
	@Autowired
	private DeclareCapacityService declareCapacityService;
	
	@Override
	public List<UrsBO> findDetailedEntitlement(int discomId, Date forDate, int revision, String gencoType) {
		if (gencoType.equalsIgnoreCase("SGS")) {
			return findDetailedEntitlementForSGS(discomId, forDate, revision);
		} else if (gencoType.equalsIgnoreCase("ISGS")) {
			return findDetailedEntitlementForISGS(discomId, forDate, revision);
		} else if (gencoType.equalsIgnoreCase("Solar")) {
			return findDetailedEntitlementForSolar(discomId, forDate, revision);
		} else {
			List<UrsBO> ursBOs = new ArrayList<>();
			ursBOs.addAll(findDetailedEntitlementForSGS(discomId, forDate, revision));
			ursBOs.addAll(findDetailedEntitlementForISGS(discomId, forDate, revision));
			ursBOs.addAll(findDetailedEntitlementForSolar(discomId, forDate, revision));
			return ursBOs;
		}
	}
	
	public List<Generation<Void>> findEntitledGenerators(int discomId, Date forDate, String gencoType) {
		List<Generation<Void>> entitledGencos = utilityShareService.findEntitledGenerators(discomId, forDate);
		List<Generation<Void>> gencos = new ArrayList<>();
		for (Generation<Void> genco: entitledGencos)
			if (genco.getGenerationTypeDetail().getGenerationTypeShortName().equals(gencoType))
				gencos.add(genco);
		return gencos;
	}
	
	public List<Integer> findEntitledGencosUtgIds(int discomId, Date forDate, String gencoType) {
		List<Generation<Void>> gencos = findEntitledGenerators(discomId, forDate, gencoType);
		List<Integer> gencoUtgIds = new ArrayList<>();
		for (Generation<Void> genco: gencos)
			gencoUtgIds.add(genco.getGenerationUid());
		return gencoUtgIds;
	}

	@Override
	public List<UrsBO> findDetailedEntitlementForSGS(int discomId, Date forDate, int revision) {
		List<Integer> gencoUtgIds = findEntitledGencosUtgIds(discomId, forDate, "SGS");
		
		return null;
	}

	@Override
	public List<UrsBO> findDetailedEntitlementForISGS(int discomId, Date forDate, int revision) {
		return null;
	}

	@Override
	public List<UrsBO> findDetailedEntitlementForSolar(int discomId, Date forDate, int revision) {
		return null;
	}
}