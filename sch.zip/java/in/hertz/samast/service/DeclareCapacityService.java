package in.hertz.samast.service;


import java.util.Date;
import java.util.List;

import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;

/**
 * 
 * @author Bibhuti Parida
 * This is service interface for implementation of declare Capacity
 *
 */
public interface DeclareCapacityService {

	public ScheduleQuantumBaseDTO getDeclaredCapacityByUTG(Date forDate, 
			int utgId) throws Exception, BusinessException;
	
	public ScheduleQuantumBaseDTO getDeclaredCapacityByUTG(Date forDate, 
			int utgId, int revsionNo) throws Exception, BusinessException;
	
	public ScheduleQuantumBaseDTO saveDC(ScheduleQuantumBaseDTO ursBO, int timeBlockValidate) 
			throws Exception, BusinessException;
	
	public Draft<ScheduleQuantumBaseDTO> fetchDraftData(Date forDate, int utgId) 
			throws Exception, BusinessException;
	
	public Draft<ScheduleQuantumBaseDTO> saveDraft(DraftDTO<ScheduleQuantumBaseDTO> draftDTO, int timeBlockValidate)  
			throws Exception, BusinessException;
	
	public ScheduleQuantumBaseDTO newDeclareCapacity(Date forDate, int utgId)
			throws Exception, BusinessException;
	
	public List<ScheduleQuantumBaseDTO> getAllDeclaredCapacity() 
			throws Exception, BusinessException;
	
	public TimeInterval getCurrentTimeBlock() throws Exception, BusinessException;
	
	public List<Integer> getAllRevisionNo(Date forDate, int utgId) throws Exception, BusinessException;
	
	public Integer getLatestRevisionNoByUTG(Date forDate, int utgId) throws Exception, BusinessException;
	
	public Integer getExBusCapacity(int utgId) throws Exception, BusinessException;
	
	public List<Integer> getRevisionNoByDCType(Date forDate, int utgId, String dcType) throws Exception, BusinessException;
}
