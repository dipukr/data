package in.hertz.samast.ctrl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.http.HttpStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.web.bind.annotation.RestController;


import in.hertz.samast.domain.DraftDTO;
import in.hertz.samast.domain.ScheduleQuantumBaseDTO;
import in.hertz.samast.domain.WSResp;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Draft;
import in.hertz.samast.entity.TimeInterval;
import in.hertz.samast.service.DeclareCapacityService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 
 * @author Bibhuti Parida
 * 
 * This is controller for Declare Capacity module
 * It manages the all rest APIs for declare capacity
 * 
 *
 */
@RestController
@RequestMapping("/declare-capacity")
public class DeclareCapacityCtrl {

	@Autowired
	private DeclareCapacityService declareCapacityService;
	
	private static final Logger log = LogManager.getLogger(DeclareCapacityCtrl.class);

	@GetMapping("/{utgId}/{forDate}")
	public ResponseEntity<WSResp<ScheduleQuantumBaseDTO>> getDeclaredCapacity(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		ScheduleQuantumBaseDTO dcBO = declareCapacityService.getDeclaredCapacityByUTG(forDate, utgId);
		if (Objects.nonNull(dcBO)) {
			Calendar c = Calendar.getInstance();
			c.setTime(forDate);
			c.add(Calendar.DATE, 1);
			dcBO.setForDate(c.getTime());
		}
		if (Objects.nonNull(dcBO)) {
			return new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
					new WSResp<ScheduleQuantumBaseDTO>(dcBO, true, "DC Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
					new WSResp<ScheduleQuantumBaseDTO>(dcBO , false, "Declare Capacity not found"),
					HttpStatus.OK);
		}
	}
	
	@GetMapping("/findDCByRevNo/{utgId}/{forDate}/{revisionNo}")
	public ResponseEntity<WSResp<ScheduleQuantumBaseDTO>> getDeclaredCapacityByRevisionNo(
			@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate,
			@PathVariable("revisionNo") int revisionNo) throws Exception, BusinessException {
		ScheduleQuantumBaseDTO dcBO = declareCapacityService.getDeclaredCapacityByUTG(forDate, utgId, revisionNo);
		if (Objects.nonNull(dcBO)) {
			Calendar c = Calendar.getInstance();
			c.setTime(forDate);
			c.add(Calendar.DATE, 1);
			dcBO.setForDate(c.getTime());
		}

		if (Objects.nonNull(dcBO)) {
			return new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
					new WSResp<ScheduleQuantumBaseDTO>(dcBO, true, "DC Data Fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
					new WSResp<ScheduleQuantumBaseDTO>(dcBO, false, "Declare Capacity not found"),
					HttpStatus.OK);
		}

	}
	
	@PostMapping("/saveDraft/{timeBlock}")
	public ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>> saveDraft(@PathVariable("timeBlock") int timeBlock,
			@RequestBody DraftDTO<ScheduleQuantumBaseDTO> draftDTO) throws Exception, BusinessException {
		Draft<ScheduleQuantumBaseDTO> savedDraft = declareCapacityService.saveDraft(draftDTO, timeBlock);
		if (Objects.nonNull(savedDraft)) {
			return new ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>>(
					new WSResp<Draft<ScheduleQuantumBaseDTO>>(savedDraft, true, "Draft Data Saved Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>>(
					new WSResp<Draft<ScheduleQuantumBaseDTO>>(savedDraft, false, "Error in Saving Draft Data!"),
					HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/findDraft/{utgId}/{forDate}")
	public ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>> findDraft(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		Draft<ScheduleQuantumBaseDTO> draftBO = declareCapacityService.fetchDraftData(forDate, utgId);
		if (Objects.nonNull(draftBO)) {
			return new ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>>(
					new WSResp<Draft<ScheduleQuantumBaseDTO>>(draftBO, true, "Data Fetched Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<Draft<ScheduleQuantumBaseDTO>>>(
					new WSResp<Draft<ScheduleQuantumBaseDTO>>(draftBO, false, "Data not found"), HttpStatus.OK);
		}
	}
	
	@PostMapping("/saveDC/{timeBlock}")
	public ResponseEntity<WSResp<ScheduleQuantumBaseDTO>> saveDeclareCapacity(@PathVariable("timeBlock") int timeBlock,
			@RequestBody ScheduleQuantumBaseDTO scheduleQuantumBaseDTO) throws Exception, BusinessException {
		ScheduleQuantumBaseDTO dc = declareCapacityService.saveDC(scheduleQuantumBaseDTO, timeBlock);
		if (Objects.nonNull(dc)) {
			return new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
					new WSResp<ScheduleQuantumBaseDTO>(dc, true, "DC Data Saved Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
					new WSResp<ScheduleQuantumBaseDTO>(dc, false, "Error in Saving DC Data!"), HttpStatus.BAD_REQUEST);
		}

	}
	
	@GetMapping("/newDC/{utgId}/{forDate}")
	public ResponseEntity<WSResp<ScheduleQuantumBaseDTO>> newDeclareCapacity(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		ScheduleQuantumBaseDTO dcBO = declareCapacityService.newDeclareCapacity(forDate, utgId);
		if (Objects.nonNull(dcBO)) {
			Calendar c = Calendar.getInstance();
			c.setTime(forDate);
			c.add(Calendar.DATE, 1);
			dcBO.setForDate(c.getTime());
		}
		if (Objects.nonNull(dcBO)) {
			return new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
					new WSResp<ScheduleQuantumBaseDTO>(dcBO, true, "DC Data Saved Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<ScheduleQuantumBaseDTO>>(
					new WSResp<ScheduleQuantumBaseDTO>(dcBO, false, "Error in Saving DC Data!"), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/findAllDC")
	public ResponseEntity<WSResp<List<ScheduleQuantumBaseDTO>>> getAllDeclaredCapacity()
			throws Exception, BusinessException {
		List<ScheduleQuantumBaseDTO> dcBOList = declareCapacityService.getAllDeclaredCapacity();

		if (Objects.nonNull(dcBOList) && !dcBOList.isEmpty()) {
			return new ResponseEntity<WSResp<List<ScheduleQuantumBaseDTO>>>(
					new WSResp<List<ScheduleQuantumBaseDTO>>(dcBOList, true, "DC Data fetched Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<List<ScheduleQuantumBaseDTO>>>(
					new WSResp<List<ScheduleQuantumBaseDTO>>(dcBOList, false, "Error in fetching DC Data!"),
					HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/findCurrentTimeBlock")
	public ResponseEntity<WSResp<TimeInterval>> getCurrentTimeBlock() throws Exception, BusinessException {
		TimeInterval timeBlock = declareCapacityService.getCurrentTimeBlock();
		if (Objects.nonNull(timeBlock)) {
			return new ResponseEntity<WSResp<TimeInterval>>(
					new WSResp<TimeInterval>(timeBlock, true, "Time Block fetched Successfully!"), HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<TimeInterval>>(
					new WSResp<TimeInterval>(timeBlock, false, "Error in fetching Time block Data!"),
					HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/findAllRevisionNo/{utgId}/{forDate}")
	public ResponseEntity<WSResp<List<Integer>>> getAllRevisionNo(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		List<Integer> revisionList = declareCapacityService.getAllRevisionNo(forDate, utgId);

		if (Objects.nonNull(revisionList) && !revisionList.isEmpty()) {
			return new ResponseEntity<WSResp<List<Integer>>>(
					new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		} else {
			revisionList = new ArrayList<Integer>();
			return new ResponseEntity<WSResp<List<Integer>>>(
					new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		}
	}
	
	@GetMapping("/findLatestRevisionNo/{utgId}/{forDate}")
	public ResponseEntity<WSResp<Integer>> getLatestRevisionNo(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate)
			throws Exception, BusinessException {
		Integer revisionNo = declareCapacityService.getLatestRevisionNoByUTG(forDate, utgId);

		if (Objects.nonNull(revisionNo) ) {
			return new ResponseEntity<WSResp<Integer>>(
					new WSResp<Integer>(revisionNo, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		} else {
			revisionNo = null;
			return new ResponseEntity<WSResp<Integer>>(
					new WSResp<Integer>(revisionNo, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		}
	}
	
	@GetMapping("/findExBusCapacity/{utgId}")
	public ResponseEntity<WSResp<Integer>> getExBusCapacity(@PathVariable("utgId") int utgId)
			throws Exception, BusinessException {
		Integer exBusCapacity = declareCapacityService.getExBusCapacity(utgId);

		if (Objects.nonNull(exBusCapacity) ) {
			return new ResponseEntity<WSResp<Integer>>(
					new WSResp<Integer>(exBusCapacity, true, "Ex-Bus Capacity fetched Successfully!"),
					HttpStatus.OK);
		} else {
			return new ResponseEntity<WSResp<Integer>>(
					new WSResp<Integer>(exBusCapacity, true, "Ex-Bus Capacity fetched Successfully!"),
					HttpStatus.OK);
		}
	}
	
	
	@GetMapping("/findRevisionNoByDCType/{utgId}/{forDate}/{dcType}")
	public ResponseEntity<WSResp<List<Integer>>> getRevisionNoByDCType(@PathVariable("utgId") int utgId,
			@PathVariable("forDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date forDate, @PathVariable("dcType") String dcType)
			throws Exception, BusinessException {
		List<Integer> revisionList = declareCapacityService.getRevisionNoByDCType(forDate, utgId, dcType);

		if (Objects.nonNull(revisionList) && !revisionList.isEmpty()) {
			return new ResponseEntity<WSResp<List<Integer>>>(
					new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		} else {
			revisionList = new ArrayList<Integer>();
			return new ResponseEntity<WSResp<List<Integer>>>(
					new WSResp<List<Integer>>(revisionList, true, "Revision Number fetched Successfully!"),
					HttpStatus.OK);
		}
	}
	
}