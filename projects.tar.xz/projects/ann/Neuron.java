public class Neuron {
	public static double sigmoid(double z) {
		return 1.0 / (1.0 + Math.exp(-z));
	}
	
	public static double dsigmoid(double z) {
		return sigmoid(z) / (1 - sigmoid(z));
	}
	
	public static double tanh(double z) {
		return Math.tanh(z);
	}
	
	public static double dtanh(double z) {
		return 1.0 / Math.pow(Math.cos(z), 2);
	}
	
	public static double relu(double z) {
		return Math.max(0, z);
	}
	
	public static double drelu(double z) {
		return (z < 0) ? 0 : 1;
	} 
}