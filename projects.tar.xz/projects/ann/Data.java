public interface Data {
	DataSet getTrainData();
	DataSet getTestData();
}