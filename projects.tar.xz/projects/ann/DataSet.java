import java.util.List;
import java.util.ArrayList;

public class DataSet {

	public List<DataItem> dataItems = new ArrayList<DataItem>();

	public void add(DataItem item) {
		dataItems.add(item);
	}

	public int size() {
		return dataItems.size();
	}

	public String toString() {
		return dataItems.toString();
	}
}