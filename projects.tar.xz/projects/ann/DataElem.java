public class DataElem {

	public Vector feature;
	public Vector label;

	public DataElem(Vector feature, Vector label) {
		this.feature = feature;
		this.label = label;
	}

	public String toString() {
		return feature+":"+label;
	}
}