public class NeuralNetwork {

	private int inputc, hiddenc, outputc;
	private Matrix w1, w2;
	private Matrix b1, b2;

	public NeuralNetwork(int inputc, int hiddenc, int outputc) {
		this.inputc = inputc;
		this.hiddenc = hiddenc;
		this.outputc = outputc;
		this.w1 = new Matrix(hiddenc, inputc);
		this.w2 = new Matrix(outputc, hiddenc);
		this.b1 = new Matrix(hiddenc, 1);
		this.b2 = new Matrix(outputc, 1);
		this.w1.randomize();
		this.w2.randomize();
		this.b1.randomize();
		this.b2.randomize();
	}

	public Vector predict(Vector input) {
		Matrix a1 = Matrix.of(input);
		Matrix z2 = Matrix.mul(w1, a1).add(b1);
		Matrix a2 = z2.sigmoid();
		Matrix z3 = Matrix.mul(w2, a2).add(b2);
		Matrix a3 = z3.sigmoid();
		return a3.toVector();
		return null;
	}

	public void train(DataSet dataSet, int epoch, double eta) {}
	public void evaluate(DataSet testData) {}
}
