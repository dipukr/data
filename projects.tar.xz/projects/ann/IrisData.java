import java.io.File;
import java.util.Scanner;

public class IrisData implements Data {

	public DataSet trainSet = new DataSet();
	public DataSet testSet = new DataSet();

	public IrisData(String fileName) throws Exception {
		File file = new File(fileName);
		Scanner sc = new Scanner(file);
		String line = sc.nextLine();
		String[] ss = line.split(",");
		int n = Integer.parseInt(ss[0]);
		for (int d = 0; d < n; d++) {
			line = sc.nextLine();
			ss = line.split(",");
			Vector feature = new Vector(4);
			Vector label = new Vector(3);
			for (int i = 0; i < 4; i++)
				feature.data[i] = Double.parseDouble(ss[i]);
			label.data[Integer.parseInt(ss[4])] = 1.0;
			DataItem item = new DataItem(feature, label);
			if (Math.random() < 0.66) trainSet.add(item);
			else testSet.add(item);
		}
	}

	@Override
	public DataSet getTrainData() {
		return trainSet;
	}
	
	@Override
	public DataSet getTestData() {
		return testSet;
	}
}