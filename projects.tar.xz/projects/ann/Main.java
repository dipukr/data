public class Main {
	public static void main(String[] args) throws Exception {
		Data data = new IrisData("iris.csv");
		DataSet trainData = data.getTrainData();
		DataSet testData = data.getTestData();
		NeuralNetwork net = new NeuralNetwork(4, 8, 3);
		net.train(trainData, 1000, 0.1);
		net.evaluate(testData);
	}
}