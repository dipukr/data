import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

import java.util.ArrayList;
import java.util.List;

public class Snake {
	
	public List<Cell> body = new ArrayList<>();
	public boolean collison = false;
	
	public void grow(Cell cell) {
		body.add(cell);
	}
	
	public void eat(Food food) {
		if (food.x == body.get(0).x && food.y == body.get(0).y) {
			grow(new Cell(-1, -1));
			food.update(this);
		}
	}
	
	public void move(int dir) {
		for (int i = body.size() - 1; i > 0; i--) {
			body.get(i).x = body.get(i - 1).x;
			body.get(i).y = body.get(i - 1).y;
		}
		switch (dir) {
		case UP:
			body.get(0).y--;
			if (body.get(0).y <= 0) collison = true;
			break;
		case DOWN:
			body.get(0).y++;
			if (body.get(0).y >= ROWS) collison = true;
			break;
		case LEFT:
			body.get(0).x--;
			if (body.get(0).x <= 0) collison = true;
			break;
		case RIGHT:
			body.get(0).x++;
			if (body.get(0).x >= COLS) collison = true;
			break;
		}
	}
	
	public void draw(Graphics2D gc) {
		for (Cell cell: body) {
			gc.setColor(Color.blue);
			gc.fillRect(cell.x * SIZE, cell.y * SIZE, SIZE - 1, SIZE - 1);
		}
	}
}
