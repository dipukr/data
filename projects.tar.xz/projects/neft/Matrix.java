import java.util.Random;

public class Matrix {

	private double[][] data;
	private int rowc;
	private int colc;

	public Matrix(int rowc, int colc) {
		this.rowc = rowc;
		this.colc = colc;
		this.data = new double[rowc][colc];
	}

	public void randomize() {
		for (int i = 0; i < rowc; ++i)
			for (int j = 0; j < colc; ++j)
				this.data[i][j] = Math.random();
	}

	public void print() {
		for (int i = 0; i < rowc; ++i) {
			for (int j = 0; j < colc; ++j)
				System.out.print(data[i][j]+" ");
			System.out.println();
		}
		System.out.println();
	}

	public double[] toArray() {
		double[] result = new double[rowc*colc];
		for (int i = 0; i < rowc; ++i)
			for (int j = 0; j < colc; ++j)
				result[colc*i + j] = data[i][j];
		return result;
	}
	
	public double relu(double a) {
		return Math.max(0, a);
	}

	public Matrix activate() {
		Matrix result = new Matrix(rowc, colc);
		for (int i = 0; i < rowc; ++i)
			for (int j = 0; j < colc; ++j)
				result.data[i][j] = relu(data[i][j]);
		return result;
	}

	public static Matrix dot(Matrix a, Matrix b) {
		verify(a.colc == b.rowc);
		Matrix result = new Matrix(a.rowc, b.colc);
		for (int i = 0; i < a.rowc; ++i)
			for (int j = 0; j < b.colc; ++j) {
				double sum = 0;
				for (int k = 0; k < a.colc; k++)
					sum += a.data[i][k]*b.data[k][j];
				result.data[i][j] = sum;
			}
		return result;
	}

	public Matrix crossover(Matrix partner) {
		Matrix child = new Matrix(rowc, colc);
		int row = Math.floor(rowc*Math.random());
		int col = Math.floor(colc*Math.random());
		for (int i = 0; i < rowc; ++i)
			for (int j = 0; j < colc; ++j) {
				
			}
		return child;
	}

	public void mutate(double rate) {
		Random rand = new Random();
		for (int i = 0; i < rowc; ++i)
			for (int j = 0; j < colc; ++j) {
				if (rate > Math.random()) {
					data[i][j] += rand.nextGaussian();
					if (data[i][j] > 1)
						data[i][j] = 1;
					if (data[i][j] < -1)
						data[i][j] = -1;
				}
			}
	}



	public Matrix clone() {
		Matrix result = new Matrix(rowc, colc);
		for (int i = 0; i < rowc; ++i)
			for (int j = 0; j < colc; ++j)
				result.data[i][j] = data[i][j];
		return result;
	}

	public static void verify(boolean cond) {
		if (!cond)
			throw new Error("fatal error, matrix shape missmatch");
	}

	public static void main(String[] args) {
		var m = new Matrix(4, 4);
		m.randomize();
		m.activate().print();
	}
}