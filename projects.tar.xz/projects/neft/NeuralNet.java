public class NeuralNet {

	private Matrix[] weights;
	private int iNodes;
	private int hNodes;
	private int oNodes;
	private int hLayers;

	public NeuralNet(int iNodes, int hNodes, int oNodes, int hLayers) {
		this.iNodes = iNodes;
		this.hNodes = hNodes;
		this.oNodes = oNodes;
		this.hLayers = hLayers;

		for (var w: weights)
			w.randomize();
	}

	public void mutate(double rate) {
		for (var w: weights)
			w.mutate(rate);
	}

	public NeuralNet crossover(NeuralNet partner) {
		NeuralNet child = new NeuralNet(iNodes, hNodes, oNodes, hLayers);
		for (int i = 0; i < weights.length; i++)
			child.weights[i] = weights[i].crossover(partner.weights[i]);
		return child;
	}

	public NeuralNet clone() {
		NeuralNet copy = new NeuralNet(iNodes, hNodes, oNodes, hLayers);
		for (int i = 0; i < weights.length; i++)
			copy.weights[i] = weights[i].clone();
		return copy;
	}

	
}