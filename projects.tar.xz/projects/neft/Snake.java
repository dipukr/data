public class Snake {

	private double fitness;
	private boolean dead;
	
	private Point head;
	private List<Point> body;
	private NeuralNet brain;

	private double[] vision;
	private double[] decision;

	private Food food;
	private List<Food> foods;

	private int score;
	
}