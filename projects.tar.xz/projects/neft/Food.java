public class Food {

	public Point pos;

	public Food(Point pos) {
		this.pos = pos;
	}
}