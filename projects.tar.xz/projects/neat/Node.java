public class Node {

	public static final int INPUT  = 0;
	public static final int HIDDEN = 1;
	public static final int OUTPUT = 2;

	public int id;
	public int kind;

	public Node(int id, int kind) {
		this.id = id;
		this.kind = kind;
	}
}