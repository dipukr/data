import java.util.List;
import java.util.ArrayList;

public class Genome {

	public List<Node> nodes;
	public List<Connection> connections;

	public Genome() {
		this.nodes = new ArrayList<Node>();
		this.connections = new ArrayList<Connection>();
	}

	public Genome addNodeMutation() {
		return null;
	}

	public Genome addConnectionMutation() {
		return null;
	}

	public static Genome crossover(Genome first, Genome second) {
		Genome child = new Genome();
		return child;
	}
}