public class Connection {

	public int from, to;
	public double weight;
	public int innovation;
	public boolean enabled;
	
	public Connection(int from, int to, double weight, int innovation, boolean enabled) {
		this.from = from;
		this.to = to;
		this.weight = weight;
		this.enabled = enabled;
		this.innovation = innovation;
	}
}