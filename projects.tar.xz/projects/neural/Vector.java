public class Vector {

	private double[] data;
	private int size;

	public Vector(int size) {
		this.size = size;
		this.data = new double[size];
	}

	public Vector(double... data) {
		this.size = data.length;
		this.data = new double[size];
		for (int i = 0; i < size; i++)
			this.data[i] = data[i];
	}

	public void scale(double factor) {
		for (int i = 0; i < size; i++)
			data[i] = factor * data[i];
	}

	public Vector times(double factor) {
		Vector tmp = new Vector(size);
		for (int i = 0; i < size; i++)
			tmp.data[i] = factor * data[i];
		return tmp;
	}

	public Vector plus(Vector that) {
		if (this.size != that.size) throw new Error("dim incompatible");
		Vector tmp = new Vector(size);
		for (int i = 0; i < size; i++)
			tmp.data[i] = this.data[i] + that.data[i];
		return tmp;
	}

	public Vector minus(Vector that) {
		if (this.size != that.size) throw new Error("dim incompatible");
		Vector tmp = new Vector(size);
		for (int i = 0; i < size; i++)
			tmp.data[i] = this.data[i] - that.data[i];
		return tmp;
	}

	public double dot(Vector that) {
		if (this.size != that.size) throw new Error("dim incompatible");
		double result = 0.0;
		for (int i = 0; i < size; i++)
			result += this.data[i] * that.data[i];
		return result;
	}

	public Vector direction() {
		if (magnitude() == 0.0) throw new Error("zero vector has not direction");
		return times(1.0 / magnitude());
	}

	public double distanceTo(Vector that) {
		if (this.size != that.size) throw new Error("dim incompatible");
		return this.minus(that).magnitude();
	}

	public double magnitude() { return Math.sqrt(dot(this)); }
	public double cartesian(int i) { return data[i]; }
	public int size() { return data.length; }

	public String toString() {
		StringBuilder b = new StringBuilder("[");
		for (double d: data)
			b.append(d).append(" ");
		b.setCharAt(b.length()-1, ']');
		return b.toString();
	}
}