public class Data {
	
	public double[] features;
	public double[] label;

	public static void loadImage(File file) throws Exception {
		BufferedImage image = ImageIO.read(file);
		float[] in  = new float[784];
		for (int i = 0; i < 28; i++)
			for (int n = 0; n < 28; n++)
				in[n*28+i] = (float)(new Color(image.getRGB(i, n)).getRed())/256f;
	}
}