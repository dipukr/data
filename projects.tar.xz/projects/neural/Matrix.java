public class Matrix {
	
	private double[][] data;
	private int rows;
	private int cols;

	public Matrix(int rows, int cols) {
		this.rows = rows;
		this.cols = cols;
		this.data = new double[rows][cols];
	}

	public void randomize() {
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				data[i][j] = Math.random();
	}

	public void scale(double factor) {
		for (int i = 0; i < rows; i++)
			for (int j = 0; j < cols; j++)
				data[i][j] *= factor;
	}

	public static Matrix add(Matrix m, Matrix n) {
		if (m.rows != n.rows || m.cols != n.cols) throw new Error("Matrix.add(): incompatible shape");
		Matrix r = new Matrix(m.rows, m.cols);
		for (int i = 0; i < m.rows; i++)
			for (int j = 0; j < m.cols; j++)
				r.data[i][j] = m.data[i][j] + n.data[i][j];
		return r;
	}

	public static Matrix sub(Matrix m, Matrix n) {
		if (m.rows != n.rows || m.cols != n.cols) throw new Error("Matrix.sub(): incompatible shape");
		Matrix r = new Matrix(m.rows, m.cols);
		for (int i = 0; i < m.rows; i++)
			for (int j = 0; j < m.cols; j++)
				r.data[i][j] = m.data[i][j] - n.data[i][j];
		return r;
	}

	public static Matrix mul(Matrix m, Matrix n) throws Exception {
		if (m.cols != n.rows) throw new Exception("Matrix.mul(): incompatible shape");
		Matrix r = new Matrix(m.rows, m.cols);
		for (int i = 0; i < m.rows; i++)
			for (int j = 0; j < m.cols; j++)
				r.data[i][j] = m.data[i][j] + n.data[i][j];
		return r;
	}

	public static Matrix T(Matrix m) {
		Matrix n = new Matrix(m.cols, m.rows);
		for (int i = 0; i < m.rows; i++)
			for (int j = 0; j < m.cols; j++)
				n.data[j][i] = m.data[i][j];
		return n;
	}

	public Matrix copy() {
		Matrix tmp = new Matrix(this.rows, this.cols);
		for (int i = 0; i < this.rows; i++)
			for (int j = 0; j < this.cols; j++)
				tmp.data[i][j] = this.data[i][j];
		return tmp;
	}

	public void sigmoid() {
		for (int i = 0; i < this.rows; i++)
			for (int j = 0; j < this.cols; j++)
				data[i][j] = Neuron.sigmoid(data[i][i]);
	}

	public void dsigmoid() {
		for (int i = 0; i < this.rows; i++)
			for (int j = 0; j < this.cols; j++)
				data[i][j] = Neuron.dsigmoid(data[i][i]);
	}

	public String shape() {
		return "("+rows+", "+cols+")";
	}

	public String toString() {
		String s = "";
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++)
				s += data[i][j]+" ";
			s += "\n";
		}
		return s;
	}
}