public class Main {

	public static void main(String[] args) throws Exception {
		Test.vector();
		Test.matrix();
	}
}