public class Neuron {

	public static double sigmoid(double z) {
		return 1.0 / (1 + Math.exp(-z));
	}
	
	public static double dsigmoid(double z) {
		return z / (1 - z);
	}
	
	public static double tanh(double z) {
		return Math.tanh(z);
	}
	
	public static double dtanh(double z) {
		return 1.0 / Math.pow(Math.cos(z), 2);
	}
}