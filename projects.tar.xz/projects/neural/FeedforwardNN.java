public class FeedforwardNN {

	private static final double eta = 0.1;

	private Matrix[] weights;
	private Matrix[] biases;
	private int[] layers;

	public FeedforwardNN(int[] layers) {
		this.layers = layers;
	}

	public Vector predict(Vector input) {
		Matrix a = input.toMatrix();
		for (int i = 0; i < layers.length; i++) {
			a = Matrix.add(Matrix.mul(w[i], a), b[i]).sigmoid();
		return a.toVector();
	}


}