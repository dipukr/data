public class NeuralNetwork {

	private int inputc, hiddenc, outputc;
	private Matrix w1, w2;
	private Matrix b1, b2;

	public NeuralNetwork(int inputc, int hiddenc, int outputc) {
		this.inputc = inputc;
		this.hiddenc = hiddenc;
		this.outputc = outputc;
		this.w1 = new Matrix(hiddenc, inputc);
		this.w2 = new Matrix(outputc, hiddenc);
		this.b1 = new Matrix(hiddenc, 1);
		this.b2 = new Matrix(outputc, 1);
		this.w1.randomize();
		this.w2.randomize();
		this.b1.randomize();
		this.b2.randomize();
	}

	public double[] predict(double[] input) {
		
	}

	public void train(int epochs, double lr) {

	}
}