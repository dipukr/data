public class GeneticAlgorithm {

	private final double crossoverRate = 0.95;
	private final double mutationRate = 0.009;

	public Population init(int size, int count) {
		Population population = new Population(size, count);
		return population;
	}

	public double calculate(Genome genome) {
		int count = 0;
		for (int i = 0; i < genome.size(); i++)
			if (genome.data[i] == Main.solution[i])
				count++;
		double fitness = (double) count / genome.size();
		genome.fitness = fitness;
		return fitness;
	}

	public void evaluate(Population population) {
		double fitness = 0;
		for (Genome genome: population.data)
			fitness += calculate(genome);
		population.fitness = fitness;
	}

	public Genome select(Population population) {
		double spin = 0;
		double roulette = Math.random() * population.fitness;
		for (Genome genome: population.data) {
			spin += genome.fitness;
			if (spin >= roulette)
				return genome;
		}
		return population.data[population.size() - 1];
	}

	public Population crossover(Population population) {
		Population newpop = new Population(population.size());
		for (int index = 0; index < population.size(); index++) {
			Genome he = population.best(index);
			if (crossoverRate > Math.random() && index > 1) {
				Genome she = select(population);
				Genome baby = he.crossover(she);
				newpop.data[index] = baby;
			} else newpop.data[index] = he;
		}
		return newpop;
	}

	public Population mutation(Population population) {
		Population newpop = new Population(population.size());
		for (int index = 0; index < population.size(); index++) {
			Genome genome = population.best(index);
			if (mutationRate > Math.random() && index > 1) {
				newpop.data[index] = genome.mutation();
			} else newpop.data[index] = genome;
		}
		return newpop;
	}

	public boolean goalReached(Population population) {
		for (Genome genome: population.data)
			if (genome.fitness == 1)
				return true;
		return false;
	}
}