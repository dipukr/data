import java.util.Random;
import java.util.Comparator;

public class Genome implements Comparable<Genome> {
	
	public byte[] data;
	public double fitness = -1;

	public Genome(int size) {
		Random rand = new Random();
		data = new byte[size];
		for (int i = 0; i < size; ++i) {
			data[i] = Main.alphabet[rand.nextInt(Main.alphabet.length)];
		}
	}

	public Genome crossover(Genome other) {
		Genome baby = new Genome(size());
		for (int i = 0; i < size(); i++) {
			if (Math.random() < 0.5)
				baby.data[i] = this.data[i];
			else baby.data[i] = other.data[i];
		}
		return baby;
	}

	public Genome mutation() {
		Random rand = new Random();
		for (int i = 0; i < size(); i++)
			data[i] = Main.alphabet[rand.nextInt(Main.alphabet.length)];
		return this;
	}

	public int compareTo(Genome that) {
		if (this.fitness > that.fitness)
			return -1;
		if (this.fitness < that.fitness)
			return +1;
		return 0;
	}

	public int size() {return data.length;}
	public String toString() {return new String(data);}
}