import java.util.Random;
import java.util.Arrays;

public class Population {

	public Genome[] data;
	public double fitness = -1;

	public Population(int size) {
		data = new Genome[size];
	}

	public Population(int size, int count) {
		this(count);
		for (int i = 0; i < count; i++)
			data[i] = new Genome(size);
	}

	public Genome best(int offset) {
		Arrays.sort(data);
		return data[offset];
	}

	public int size() { return data.length; }
}