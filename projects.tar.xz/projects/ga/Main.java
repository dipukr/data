public class Main {

	public static final byte[] alphabet = "abcdefghijklmnopqrstuvwxyz ".getBytes();
	public static final byte[] solution = "satyam shivam sundaram".getBytes();

	public static void main(String[] args) throws Exception {
		GeneticAlgorithm ga = new GeneticAlgorithm();
		Population population = ga.init(solution.length, 200);
		ga.evaluate(population);
		int generation = 1;
		while (ga.goalReached(population) == false) {
			System.out.println("Best solution: "+population.best(0));
			population = ga.crossover(population);
			population = ga.mutation(population);
			ga.evaluate(population);
			generation++;
		}
		System.out.println("Found solution in "+generation+" generations");
		System.out.println("Best solution: "+population.best(0));
	}
}