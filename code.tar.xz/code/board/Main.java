import java.util.Arrays;
import java.util.Stack;
import java.util.Map;
import java.util.HashMap;

public class Main {

	public static void main(String[] args) throws Exception {
		Board board = new Board();
		byte[] curr = board.data.clone();
		var parent = Search.astar(board.data);
		long count = Search.count;
		System.out.println("expanded nodes: "+count);
		var stack = new Stack<byte[]>();
		stack.push(Board.GOAL.clone());
		while (!Arrays.equals(stack.peek(), curr))
			stack.push(parent.get(Search.make(stack.peek())));
		stack.pop();
		System.out.println("moves: "+stack.size());
	}
}