class Node:
	def __init__(self, data, next=None):
		self.data = data
		self.next = next

class List:
	def __init__(self):
		self.head = None
		self.tail = None
		self.nodeCount = 0

	def insertAtHead(self, data):
		if self.empty():
			self.head = self.tail = Node(data)
		else:
			self.head = Node(data, self.head)
		self.nodeCount += 1

	def insertAtTail(self, data):
		if self.empty():
			self.head = self.tail = Node(data)
		else:
			node = Node(data)
			self.tail.next = node
			self.tail = node
		self.nodeCount += 1	

	def insertAfter(self, data)	

	def size(self):
		return self.nodeCount

	def empty(self):
		return self.size() == 0
		
	def dump(self):
		if self.empty():
			return
		curr = self.head
		while curr != None:
			print(str(curr.data) + "->", end="")
			curr = curr.next
		print("null")

list = List()
list.insertAtHead(100)
list.insertAtHead(200)
list.insertAtHead(300)
list.insertAtTail(400)
list.insertAtTail(500)
list.dump()
