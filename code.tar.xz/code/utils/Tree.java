import java.io.File;

public class Tree {

	public static final char a = '\u2514';
	public static final String RESET = "\u001B[0m";
	public static final String BLACK = "\u001B[30m";
	public static final String RED = "\u001B[31m";
	public static final String GREEN = "\u001B[32m";
	public static final String YELLOW = "\u001B[33m";
	public static final String BLUE = "\u001B[34m";
	public static final String PURPLE = "\u001B[35m";
	public static final String CYAN = "\u001B[36m";
	public static final String WHITE = "\u001B[37m";

	public static void tree(File dir, int root) {
		for (File file: dir.listFiles()) {
			if (file.isDirectory()) {
				for (int i = 0; i < root; i++) {
					if (i % 2 == 0 || i == 0)
						System.out.printf("%c", '\u2502');
					else System.out.print("   ");
				}
				System.out.printf("%s%c%c%c %s\n", BLUE, '\u251c','\u2500','\u2500', file.getName());
				tree(file, root + 2);
			} else {
				for (int i = 0; i < root; i++) {
					if (i % 2 == 0 || i == 0)
						System.out.printf("%c", '\u2502');
					else System.out.print("   ");
				}
				System.out.printf("%s%c%c%c %s\n", GREEN, '\u251c', '\u2500','\u2500', file.getName());
			}
		}
	}
	public static void main(String[] args) throws Exception {
		File dir = new File("/home/rootshell/Media");
		tree(dir, 0);
		System.out.print(RESET);
	}
}