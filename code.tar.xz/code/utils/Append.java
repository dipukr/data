import java.io.File;
import java.io.RandomAccessFile;
import java.io.IOException;
import java.io.FileNotFoundException;

public class Append {

	private File file;

	public Append(File file) {
		this.file = file;
	}

	public void append(String text) {
		try {
			var file = new RandomAccessFile(this.file, "rw");
			long length = file.length();
			file.seek(length - 1);
			char lastCh = (char) file.read();
			if (lastCh != '\n')
				file.write((int) '\n');
			file.writeBytes(String.format("%s\n", text));
			file.close();
		} catch (IOException e) {
			System.out.printf("%s: File IO Error.", this.file.getName());
			System.exit(0);
		} catch (FileNotFoundException e) {
			System.out.printf("File '%s' not found.", this.file.getName());
			System.exit(0);
		}
	}

	public static void main(String[] args) throws Exception {
		if (args.length == 1) {
			File file = new File(args[0]);
			Append append = new Append(file);
			for (int i = 1; i < args.length; i++) {
				append.append(args[i]);
			}
		}
	}
}