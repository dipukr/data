package in.hertz.samast.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import in.hertz.samast.entity.Generation;

public interface UtilityShareService {

	public List<Generation> findEntitledGenerators(int discomId, Date forDate);
	public Map<Integer, Map<Integer, Float>> findUtilityShareMap(int discomId, Date forDate);
}
