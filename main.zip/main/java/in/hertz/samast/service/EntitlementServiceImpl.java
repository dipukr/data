package in.hertz.samast.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.hertz.samast.dao.DeclareCapacityRepository;
import in.hertz.samast.dao.GenerationDao;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.domain.BlockQuantumsDTO;
import in.hertz.samast.domain.UrsBO;
import in.hertz.samast.entity.DeclareCapability;
import in.hertz.samast.entity.DeclareCapabilityDetails;
import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.UtilitiesTraderGenco;

@SuppressWarnings("rawtypes")
@Service
public class EntitlementServiceImpl implements EntitlementService {
	
	@Autowired
	private UtilityShareService utilityShareService;
	
	@Autowired
	private GenerationDao generationDao;
	
	@Autowired
	private DeclareCapacityRepository declareCapacityDao;
	
	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoDao;
	
	@Override
	public List<UrsBO> findDetailedEntitlement(int discomId, Date forDate, int revision, String gencoType) {
		if (gencoType.equalsIgnoreCase("SGS")) {
			return findDetailedEntitlementForSGS(discomId, forDate, revision);
		} else if (gencoType.equalsIgnoreCase("ISGS")) {
			return findDetailedEntitlementForISGS(discomId, forDate, revision);
		} else if (gencoType.equalsIgnoreCase("Solar")) {
			return findDetailedEntitlementForSolar(discomId, forDate, revision);
		} else {
			List<UrsBO> ursBOs = new ArrayList<>();
			ursBOs.addAll(findDetailedEntitlementForSGS(discomId, forDate, revision));
			ursBOs.addAll(findDetailedEntitlementForISGS(discomId, forDate, revision));
			ursBOs.addAll(findDetailedEntitlementForSolar(discomId, forDate, revision));
			return ursBOs;
		}
	}
	
	@Override
	public List<UrsBO> findDetailedEntitlementForSGS(int discomId, Date forDate, int revision) {
		List<Integer> gencoUtgIds = findEntitledGencosUtgIdsByGenerationType(discomId, forDate, "SGS");
		
		return null;
	}
	
	public List<Integer> findEntitledGencosUtgIdsByGenerationType(int discomId, Date forDate, String gencoType) {
		List<Generation> gencos = utilityShareService.findEntitledGenerators(discomId, forDate);
		gencos = filterGeneratorsByGenerationType(gencos, gencoType);
		List<Integer> gencoUtgIds = new ArrayList<>();
		for (Generation genco: gencos)
			gencoUtgIds.add(genco.getGenerationUid());
		return gencoUtgIds;
	}
	
	public List<Generation> filterGeneratorsByGenerationType(List<Generation> gencos, String gencoType) {
		List<Generation> filteredGencos = new ArrayList<>();
		for (Generation genco: gencos)
			if (genco.getGenerationTypeDetail().getGenerationTypeShortName().equals(gencoType))
				filteredGencos.add(genco);
		return filteredGencos;
	}
	
	public List<UrsBO> findEntitlementByGencoUtgIds(int discomId, List<Integer> gencoUtgIds, Date forDate) {
		Map<Integer, Map<Integer, Float>> shareMap = utilityShareService.findUtilityShareMap(discomId, forDate);
		UtilitiesTraderGenco discomUtg = utilitiesTraderGencoDao.findById(discomId).get();
		
		List<DeclareCapability> declareCapabilities = 
				declareCapacityDao.findDeclaredCapabilityByGencoUtgIdsAndDate(gencoUtgIds, forDate);
		
		List<UrsBO> ursBOs = new ArrayList<>();

		for (DeclareCapability declareCapability: declareCapabilities) {
			Integer gencoUtgId = declareCapability.getUtilitiesTraderGenco().getUID();
			UtilitiesTraderGenco gencoUtg = utilitiesTraderGencoDao.findById(gencoUtgId).get();
			
			UrsBO ursBO = new UrsBO();
			ursBO.setDiscomUTGId(discomId);
			ursBO.setDiscomName(discomUtg.getName());
			ursBO.setGencoUTGId(gencoUtgId);
			ursBO.setGencoName(gencoUtg.getName());
			ursBO.setForDate(forDate);
			ursBO.setUtilityName(discomUtg.getName());
			
			Map<Integer, Float> blockMap = shareMap.get(gencoUtgId);
			List<BlockQuantumsDTO> blocks = new ArrayList<>();
			for (DeclareCapabilityDetails dcDetail: declareCapability.getCapabilityDetails()) {
				Float sharePercent = blockMap.get(dcDetail.getTimeIntervalId());
				if (sharePercent != null) {
					BlockQuantumsDTO block = new BlockQuantumsDTO();
					block.setQuantum(dcDetail.getQuantumOfPower() * (sharePercent / 100));
					block.setTimeBlockId(dcDetail.getTimeIntervalId());
					blocks.add(block);
				}
			}
			
			ursBO.setDetails(blocks);
			ursBOs.add(ursBO);
		}			
		return ursBOs;
	}
	

	@Override
	public List<UrsBO> findDetailedEntitlementForISGS(int discomId, Date forDate, int revision) {
		return null;
	}

	@Override
	public List<UrsBO> findDetailedEntitlementForSolar(int discomId, Date forDate, int revision) {
		return null;
	}
}