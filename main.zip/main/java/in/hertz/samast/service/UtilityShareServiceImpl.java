package in.hertz.samast.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import in.hertz.samast.dao.GenerationDao;
import in.hertz.samast.dao.UtilitiesTraderGencoRepository;
import in.hertz.samast.dao.UtilityShareDao;
import in.hertz.samast.domain.exception.BusinessException;
import in.hertz.samast.entity.Generation;
import in.hertz.samast.entity.UtilitiesTraderGenco;
import in.hertz.samast.entity.UtilityShare;
import in.hertz.samast.entity.UtilityShareDetails;

@Service
public class UtilityShareServiceImpl implements UtilityShareService {
	
	@Autowired
	private UtilityShareDao utilityShareDao;
	
	@Autowired
	private GenerationDao generationDao;
	
	@Autowired
	private UtilitiesTraderGencoRepository utilitiesTraderGencoDao;

	@Override
	public List<Generation> findEntitledGenerators(int discomId, Date forDate) {
		List<UtilitiesTraderGenco> findEntitledUtgs = findEntitledUtgs(discomId, forDate);
		List<Generation> generators = null;
		
		return generators;
	}
	
	public List<UtilitiesTraderGenco> findEntitledUtgs(int discomId, Date forDate) {
		return null;
	}
	
	public Map<Integer, Map<Integer, Float>> findUtilityShareMap(int discomId, Date forDate) {
		List<UtilityShare> utilityShares = utilityShareDao.findAllUtilityShareForDate(discomId, forDate);
		Map<Integer, Map<Integer, Float>> shareMap = new HashedMap<>();
		for (UtilityShare utilityShare: utilityShares) {
			Map<Integer, Float> blocksMap = new HashMap<>();
			for (int i = 1; i <= 96; i++)
				blocksMap.put(i, 0.0F);
			for (UtilityShareDetails usd: utilityShare.getShareDetails())
				for (int block = usd.getFromBlock().getBlockNumber(); block <= usd.getToBlock().getBlockNumber(); block++)
					blocksMap.put(block, usd.getShare().floatValue());
			shareMap.put(utilityShare.getInjectorUtg().getUID(), blocksMap);
		}
		return shareMap;
	}
}
