package in.hertz.samast.ctrl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.hertz.samast.dao.GenerationDao;
import in.hertz.samast.domain.UrsBO;
import in.hertz.samast.entity.Generation;
import in.hertz.samast.service.EntitlementService;

@RestController
@RequestMapping("/entitlement")
public class EntitlementCtrl {
	
	@Autowired
	private EntitlementService entitlementService;
	
	@Autowired
	private GenerationDao generationDao;
	
	@GetMapping("/getDetailedEntitlement/{discomId}/{forDate}/{revision}/{gencoType}")
	public List<UrsBO> getDetailedEntitlement(@PathVariable int discomId,
											  @PathVariable Date forDate,
											  @PathVariable int revision,
											  @PathVariable String gencoType) {
		return entitlementService.findDetailedEntitlement(discomId, forDate, revision, gencoType);
	}
	
	@GetMapping("/test")
	public Generation testHandler() {
		return generationDao.findById(2).get();
	}
	
	@GetMapping("/test2")
	public List<Generation> testHandler2() {
		return generationDao.findAll();
	}
}
