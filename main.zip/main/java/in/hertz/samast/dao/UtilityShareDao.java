package in.hertz.samast.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import in.hertz.samast.entity.UtilityShare;

@Repository
public interface UtilityShareDao extends JpaRepository<UtilityShare, Integer> {
	
	@Query("SELECT us FROM UtilityShare us WHERE us.beneficiaryUtg.UID = :discomId AND :forDate BETWEEN us.fromDate AND us.toDate")
	public List<UtilityShare> findAllUtilityShareForDate(@Param("discomId") int discomId,  @Param("forDate") Date forDate);
}
