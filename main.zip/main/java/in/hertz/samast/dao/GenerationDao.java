package in.hertz.samast.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import in.hertz.samast.entity.Generation;

@Repository
public interface GenerationDao extends JpaRepository<Generation, Integer> {
}
