package com.saral;

public class Param {

	public String name;
	public Type type;
	public Symbol symbol;
	
	public Param(String name, Type type) {
		this.name = name;
		this.type = type;
	}
	
	public static Param of(String name, Type type) {
		return new Param(name, type);
	}
}
