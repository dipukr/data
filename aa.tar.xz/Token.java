package com.saral;

public class Token {

	public static final int EOT = 0;
	public static final int DOT = 1;
	public static final int COMMA = 2;
	public static final int COLON = 3;
	public static final int BICOLON = 4;
	public static final int LPAREN = 5;
	public static final int RPAREN = 6;
	public static final int LBRACE = 7;
	public static final int RBRACE = 8;
	public static final int LBRACKET = 9;
	public static final int RBRACKET = 10;
	public static final int SEMICOLON = 11;
	public static final int PLUS = 12;
	public static final int MINUS = 13;
	public static final int MULT = 14;
	public static final int DIV = 15;
	public static final int MOD = 16;
	public static final int INC = 17;
	public static final int DEC = 18;
	public static final int SHL = 19;
	public static final int SHR = 20;
	public static final int BOR = 21;
	public static final int BXOR = 22;
	public static final int BAND = 23;
	public static final int BNOT = 24;
	public static final int REQ = 25;
	public static final int RNE = 26;
	public static final int RLT = 27;
	public static final int RLE = 28;
	public static final int RGT = 29;
	public static final int RGE = 30;
	public static final int OR = 31;
	public static final int AND = 32;
	public static final int NOT = 33;
	public static final int CONDITION = 34;
	public static final int ASSIGN = 35;
	public static final int CLASS = 36;
	public static final int SELF = 37;
	public static final int CONSTRUCTOR = 38;
	public static final int VOID = 39;
	public static final int BOOL = 40;
	public static final int CHAR = 41;
	public static final int INT = 42;
	public static final int LONG = 43;
	public static final int DECIMAL = 44;
	public static final int VAL = 45;
	public static final int VAR = 46;
	public static final int IF = 47;
	public static final int ELSE = 48;
	public static final int REPEAT = 49;
	public static final int UNTIL = 50;
	public static final int WHILE = 51;
	public static final int FOR = 52;
	public static final int FOREVER = 53;
	public static final int FOREACH = 54;
	public static final int BREAK = 55;
	public static final int CONTINUE = 56;
	public static final int RETURN = 57;
	public static final int ASSERT = 58;
	public static final int CONSOLE = 59;
	public static final int NULL = 60;
	public static final int TRUE = 61;
	public static final int FALSE = 62;
	public static final int CHAR_LITERAL = 63;
	public static final int INT_LITERAL = 64;
	public static final int LONG_LITERAL = 65;
	public static final int DECIMAL_LITERAL = 66;
	public static final int STRING_LITERAL = 67;
	public static final int IDENTIFIER = 68;

	public int type;
	public String word;
	public int lineNo;
	
	public Token(int type, String word, int lineNo) {
		this.type = type;
		this.word = word;
		this.lineNo = lineNo;
	}
	
	public static Token of(int type, String word, int lineNo) {
		return new Token(type, word, lineNo);
	}
	
	public String kind() {
		switch (type) {
		case PLUS:
		case MINUS:
		case MULT:
		case DIV:
		case MOD:
		case INC:
		case DEC:
		case SHL:
		case SHR:
		case BOR:
		case BXOR:
		case BAND:
		case BNOT:
		case REQ:
		case RNE:
		case RLT:
		case RLE:
		case RGT:
		case RGE:
		case OR:
		case AND:
		case NOT:
		case CONDITION:
		case ASSIGN:
			return "Operator";
		case CLASS:
		case CONSTRUCTOR:
		case SELF:
		case VOID:
		case BOOL:
		case CHAR:
		case INT:
		case LONG:
		case DECIMAL:
		case VAL:
		case VAR:
		case IF:
		case ELSE:
		case REPEAT:
		case UNTIL:
		case WHILE:
		case FOR:
		case FOREVER:
		case FOREACH:
		case BREAK:
		case CONTINUE:
		case RETURN:
		case ASSERT:
		case CONSOLE:
		case NULL:
		case TRUE:
		case FALSE:
			return "Keyword";
		case DOT:
		case COMMA:
		case COLON:
		case LPAREN:
		case RPAREN:
		case LBRACE:
		case RBRACE:
		case LBRACKET:
		case RBRACKET:
		case SEMICOLON:
			return "Delimiter";
		case CHAR_LITERAL:
		case INT_LITERAL:
		case LONG_LITERAL:
		case DECIMAL_LITERAL:
		case STRING_LITERAL:
			return "Literal";
		default:
			return "Unknown";
		}
	}
	
	@Override
	public String toString() {
		return String.format("%d %s %s", lineNo, kind(), word);
	}
}
