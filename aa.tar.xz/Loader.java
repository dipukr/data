package com.saral;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public final class Loader {
	
	public static char[] load(File file) {
		int length = (int) file.length();
		char[] charStream = new char[length];
		try (FileReader reader = new FileReader(file)) {
			reader.read(charStream, 0, length);
		} catch (IOException e) {
			Error.fatal(String.format("File IO error during read file '%s'", file.getName()));
		}
		return charStream;
	}
}
