package com.saral;

import java.io.File;

public class Main {
	public static void main(final String[] args) throws Exception {
		File file = new File("main.saral");
		CharStream charStream = CharStream.of(file);
		System.out.println(charStream);
		TokenStream tokenStream = TokenStream.of(charStream);
		System.out.println(tokenStream);
	}
}
