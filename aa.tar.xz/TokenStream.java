package com.saral;

import java.util.List;

public final class TokenStream {

	private List<Token> tokens;
	pri
	private int current;
	
	public TokenStream(List<Token> tokens) {
		this.tokens = tokens;
		this.current = 0;
	}
	
	public Token nextToken() {
		return tokens.get(current++);
	}
	
	public Token seekToken() {
		return tokens.get(current);
	}
	
	public void match(int type) {
		Token token = nextToken();
		if (token.type != type)
			Error.report(Error.PARSE, String.format("Expected '%s' found '%s'"), token.lineNo);
	}
	
	public boolean atEnd() {
		return current >= tokens.size();
	}
	
	public static TokenStream of(CharStream charStream) {
		return Scanner.scan(charStream);
	}
}
