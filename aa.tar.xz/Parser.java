package com.saral;

import java.util.List;
import java.util.ArrayList;

public class Parser {

	private TokenStream tokenStream;
	
	public Parser(TokenStream tokenStream) {
		this.tokenStream = tokenStream;
	}

	public List<Statement> parse() {
		return null;
	}

	private Statement parseClassStatement() {
		int lineNo = line;
		tokenStream.match(Token.CLASS);
		String name = token.text;
		match(Token.IDENTIFIER);
		match(Token.LBRACE);
		boolean done = false;
		Statement ctor = null;
		List<Statement> vars = new ArrayList<Statement>();
		List<Statement> functions = new ArrayList<Statement>();
		loop:
		while (true) {
			switch (token.type) {
			case Token.EOT: break loop;
			case Token.RBRACE: break loop;
			case Token.VAR: vars.add(varstmt()); break;
			case Token.FUNCTION: functions.add(functionstmt()); break;
			case Token.IDENTIFIER: ctor = ctorstmt(name, done); done = true; break;
			default: break loop;
			}
		}
		match(Token.RBRACE);
		if (done == false) ctor = defaultctor();
		return new Statement.Classdef(name, ctor, vars, functions, pos);
	}

	private Statement defaultctor() {
		int pos = line;
		String name = "init";
		List<String> args = new ArrayList<String>();
		Statement body = new Statement.Block(new ArrayList<Statement>(), pos);
		return new Statement.Function(name, args, body, pos);
	}

	private Statement ctorstmt(String cname, boolean done) {
		int pos = line;
		if (done) Log.error("multiple constructor not allowed", line);
		if (!cname.equals(token.text)) Log.error("class and ctor need same name", line);
		match(Token.IDENTIFIER);
		List<String> args = parameters();
		Statement body = blockstmt();
		return new Statement.Function(cname, args, body, pos);
	}

	private Statement functionstmt() {
		int pos = line;
		match(Token.FUNCTION);
		String name = token.text;
		match(Token.IDENTIFIER);
		List<String> args = parameters();
		Statement body = blockstmt();
		return new Statement.Function(name, args, body, pos);
	}

	private List<String> parameters() {
		match(Token.LPAREN);
		List<String> args = new ArrayList<>();
		while (token.type == Token.IDENTIFIER) {
			String arg = token.text;
			match(Token.IDENTIFIER);
			args.add(arg);
			if (token.type == Token.COMMA)
				nextoken();
			else break;
		}
		match(Token.RPAREN);
		return args;
	}

	private Statement statement() {
		switch (token.type) {
		case Token.LBRACE: return blockstmt();
		case Token.VAR: return varstmt();
		case Token.IF: return ifelsestmt();
		case Token.REPEAT: return repeatstmt();
		case Token.WHILE: return whilestmt();
		case Token.FOR: return forstmt();
		case Token.FOREACH: return foreachstmt();
		case Token.FOREVER: return foreverstmt();
		case Token.BREAK: return breakstmt();
		case Token.CONTINUE: return continuestmt();
		case Token.RETURN: return returnstmt();
		case Token.ASSERT: return assertstmt();
		case Token.LOG: return logstmt();
		case Token.RBRACE: Log.error("unbalanced braces", line); break;
		case Token.ELSE: Log.error("found else without if", line); break;
		case Token.EOT: Log.error("expected statement found end of program", line); break;
		default: return exprstmt();
		}
		return null;
	}

	private Statement blockstmt() {
		int pos = line;
		match(Token.LBRACE);
		List<Statement> body = new ArrayList<Statement>();
		while (token.type != Token.EOT && token.type != Token.RBRACE)
			body.add(statement());
		match(Token.RBRACE);
		return new Statement.Block(body, pos);
	}

	private Statement varstmt() {
		int pos = line;
		match(Token.VAR);
		String name = token.text;
		match(Token.IDENTIFIER);
		Expression expr = null;
		if (token.type == Token.ASSIGN) {
			nextoken();
			expr = expression();
		}
		return new Statement.Var(name, expr, pos);
	}

	private Statement ifelsestmt() {
		int pos = line;
		match(Token.IF);
		Expression cond = condition();
		Statement ifbody = statement();
		Statement elsebody = null;
		if (token.type == Token.ELSE) {
			nextoken();
			elsebody = statement();
		}
		return new Statement.If(cond, ifbody, elsebody, pos);
	}

	private Statement repeatstmt() {
		int pos = line;
		match(Token.REPEAT);
		match(Token.COLON);
		List<Statement> body = new ArrayList<Statement>();
		while (token.type != Token.EOT && token.type != Token.UNTIL)
			body.add(statement());
		match(Token.UNTIL);
		match(Token.LPAREN);
		Expression cond = condition();
		match(Token.RPAREN);
		return new Statement.Repeat(body, cond, pos);
	}

	private Statement whilestmt() {
		int pos = line;
		match(Token.WHILE);
		Expression cond = condition();
		Statement body = statement();
		return new Statement.While(cond, body, pos);
	}

	private Statement forstmt() {
		int pos = line;
		match(Token.FOR);
		match(Token.LPAREN);
		Statement init = statement();
		match(Token.SEMICOLON);
		Expression cond = expression();
		match(Token.SEMICOLON);
		Expression iter = expression();
		match(Token.RPAREN);
		Statement body = statement();
		return new Statement.For(init, cond, iter, body, pos);
	}

	private Statement foreachstmt() {
		int pos = line;
		match(Token.FOREACH);
		match(Token.LPAREN);
		String lhs = token.text;
		match(Token.IDENTIFIER);
		match(Token.COLON);
		String rhs = token.text;
		match(Token.IDENTIFIER);
		match(Token.RPAREN);
		Statement body = statement();
		return new Statement.Foreach(lhs, rhs, body, pos);
	}

	private Statement foreverstmt() {
		int pos = line;
		match(Token.FOREVER);
		Statement body = statement();
		return new Statement.Forever(body, pos);
	}

	private Statement breakstmt() {
		int pos = line;
		match(Token.BREAK);
		return new Statement.Break(pos);
	}

	private Statement continuestmt() {
		int pos = line;
		match(Token.CONTINUE);
		return new Statement.Continue(pos);
	}

	private Statement returnstmt() {
		int pos = line;
		match(Token.RETURN);
		Expression expr = null;
		if (token.type != Token.SEMICOLON)
			expr = expression();
		else match(Token.SEMICOLON);
		return new Statement.Return(expr, pos);
	}

	private Statement assertstmt() {
		int pos = line;
		match(Token.ASSERT);
		Expression expr = expression();
		return new Statement.Assert(expr, pos);
	}

	private Statement logstmt() {
		int pos = line;
		match(Token.LOG);
		match(Token.LPAREN);
		List<Expression> exprs = arguments();
		match(Token.RPAREN);
		return new Statement.Log(exprs, pos);
	}

	private Statement exprstmt() {
		int pos = line;
		Expression expr = expression();
		return new Statement.Expr(expr, pos);
	}

	private Expression condition() {
		match(Token.LPAREN);
		Expression expr = expression();
		match(Token.RPAREN);
		return expr;
	}

	private Expression expression() {
		return assignment();
	}

	private Expression assignment() {
		Expression lhs = logor();
		while (token.type == Token.ASSIGN) {
			int pos = line;
			match(Token.ASSIGN);
			Expression rhs = assignment();
			lhs = new Expression.Assignment(lhs, rhs, pos);
		}
		return lhs;
	}

	private Expression logor() {
		Expression lhs = logand();
		while (token.type == Token.LOR) {
			int pos = line;
			match(Token.LOR);
			Expression rhs = logand();
			lhs = new Expression.LogicalOR(lhs, rhs, pos);
		}
		return lhs;
	}

	private Expression logand() {
		Expression lhs = boolor();
		while (token.type == Token.LAND) {
			int pos = line;
			match(Token.LAND);
			Expression rhs = boolor();
			lhs = new Expression.LogicalAND(lhs, rhs, pos);
		}
		return lhs;
	}

	private Expression boolor() {
		Expression lhs = boolxor();
		while (token.type == Token.BOR) {
			int pos = line;
			match(Token.BOR);
			Expression rhs = boolxor();
			lhs = new Expression.BooleanOR(lhs, rhs, pos);
		}
		return lhs;
	}

	private Expression boolxor() {
		Expression lhs = booland();
		while (token.type == Token.BXOR) {
			int pos = line;
			match(Token.BXOR);
			Expression rhs = booland();
			lhs = new Expression.BooleanXOR(lhs, rhs, pos);
		}
		return lhs;
	}

	private Expression booland() {
		Expression lhs = equality();
		while (token.type == Token.BAND) {
			int pos = line;
			match(Token.BAND);
			Expression rhs = equality();
			lhs = new Expression.BooleanAND(lhs, rhs, pos);
		}
		return lhs;
	}

	private Expression equality() {
		Expression lhs = comparison();
		Expression rhs = null;
		int pos;
		while (true)
		switch (token.type) {
		case Token.CEQ:
			pos = line;
			match(Token.CEQ);
			rhs = comparison();
			lhs = new Expression.Equal(lhs, rhs, pos);
			break;
		case Token.CNE:
			pos = line;
			match(Token.CNE);
			rhs = comparison();
			lhs = new Expression.NotEqual(lhs, rhs, pos);
			break;
		default: return lhs;
		}
	}

	private Expression comparison() {
		Expression lhs = shift();
		Expression rhs = null;
		int pos;
		while (true)
		switch (token.type) {
		case Token.CLT:
			pos = line;
			match(Token.CLT);
			rhs = shift();
			lhs = new Expression.Less(lhs, rhs, pos);
			break;
		case Token.CLE:
			pos = line;
			match(Token.CLE);
			rhs = shift();
			lhs = new Expression.LessEqual(lhs, rhs, pos);
			break;
		case Token.CGT:
			pos = line;
			match(Token.CGT);
			rhs = shift();
			lhs = new Expression.Greater(lhs, rhs, pos);
			break;
		case Token.CGE:
			pos = line;
			match(Token.CGE);
			rhs = shift();
			lhs = new Expression.GreaterEqual(lhs, rhs, pos);
			break;
		default: return lhs;
		}
	}

	private Expression shift() {
		Expression lhs = addition();
		Expression rhs = null;
		int pos;
		while (true)
		switch (token.type) {
		case Token.SHL:
			pos = line;
			match(Token.SHL);
			rhs = addition();
			lhs = new Expression.ShiftLeft(lhs, rhs, pos);
			break;
		case Token.SHR:
			pos = line;
			match(Token.SHR);
			rhs = addition();
			lhs = new Expression.ShiftRight(lhs, rhs, pos);
			break;
		default: return lhs;
		}
	}

	private Expression addition() {
		Expression lhs = multiply();
		Expression rhs = null;
		int pos;
		while (true)
		switch (token.type) {
		case Token.PLUS:
			pos = line;
			match(Token.PLUS);
			rhs = multiply();
			lhs = new Expression.Addition(lhs, rhs, pos);
			break;
		case Token.MINUS:
			pos = line;
			match(Token.MINUS);
			rhs = multiply();
			lhs = new Expression.Subtraction(lhs, rhs, pos);
			break;
		default: return lhs;
		}
	}

	private Expression multiply() {
		Expression lhs = unary();
		Expression rhs = null;
		int pos;
		while (true)
		switch (token.type) {
		case Token.MULT:
			pos = line;
			match(Token.MULT);
			rhs = unary();
			lhs = new Expression.Multiply(lhs, rhs, pos);
			break;
		case Token.DIV:
			pos = line;
			match(Token.DIV);
			rhs = unary();
			lhs = new Expression.Division(lhs, rhs, pos);
			break;
		case Token.MOD:
			pos = line;
			match(Token.MOD);
			rhs = unary();
			lhs = new Expression.Modulus(lhs, rhs, pos);
			break;
		default: return lhs;
		}
	}

	private Expression unary() {
		Expression expr = null;
		int pos;
		switch (token.type) {
		case Token.PLUS:
			match(Token.PLUS);
			expr = unary();
			break;
		case Token.MINUS:
			pos = line;
			match(Token.MINUS);
			expr = unary();
			expr = new Expression.Negation(expr, pos);
			break;
		case Token.INC:
			pos = line;
			match(Token.INC);
			expr = unary();
			expr = new Expression.Increment(expr, pos);
			break;
		case Token.DEC:
			pos = line;
			match(Token.DEC);
			expr = unary();
			expr = new Expression.Decrement(expr, pos);
		case Token.LNOT:
			pos = line;
			match(Token.LNOT);
			expr = unary();
			expr = new Expression.LogicalNOT(expr, pos);
			break;
		case Token.BNOT:
			pos = line;
			match(Token.BNOT);
			expr = unary();
			expr = new Expression.BooleanNOT(expr, pos);
			break;
		default:
			expr = primary();
			break;
		}
		return expr;
	}

	private Expression primary() {
		Expression expr = null;
		Value value = null;
		String str = null;
		String str2 = null;
		int pos = line;
		switch (token.type) {
		case Token.NULL:
			match(Token.NULL);
			expr = new Expression.Null(pos);
			break;
		case Token.TRUE:
			match(Token.TRUE);
			expr = new Expression.True(pos);
			break;
		case Token.FALSE:
			match(Token.FALSE);
			expr = new Expression.False(pos);
			break;
		case Token.THIS:
			match(Token.THIS);
			expr = new Expression.Identifier("this", pos);
			break;
		case Token.INTLIT:
			value = new Value(Long.valueOf(token.text));
			match(Token.INTLIT);
			expr = new Expression.Literal(value, pos);
			break;
		case Token.FLTLIT:
			value = new Value(Double.valueOf(token.text));
			match(Token.FLTLIT);
			expr = new Expression.Literal(value, pos);
			break;
		case Token.STRLIT:
			value = new Value(token.text);
			match(Token.STRLIT);
			expr = new Expression.Literal(value, pos);
			break;
		case Token.IDENTIFIER:
			str = token.text;
			match(Token.IDENTIFIER);
			expr = new Expression.Identifier(str, pos);
			break;
		case Token.NEW:
			expr = newexpr();
			break;
		case Token.LPAREN:
			match(Token.LPAREN);
			expr = expression();
			match(Token.RPAREN);
			break;
		default: Log.error("invalid expression systax", pos);
		}
		return subscript(expr);
	}

	private Expression subscript(Expression lhs) {
		Expression rhs = null;
		int pos;
		while (true)
		switch (token.type) {
		case Token.DOT:
			pos = line;
			match(Token.DOT);
			String mem = token.text;
			match(Token.IDENTIFIER);
			lhs = new Expression.Dot(lhs, mem, pos);
			break;
		case Token.LPAREN:
			pos = line;
			match(Token.LPAREN);
			lhs = new Expression.Call(lhs, arguments(), pos);
			match(Token.RPAREN);
			break;
		case Token.LBRACKET:
			pos = line;
			match(Token.LBRACKET);
			rhs = expression();
			match(Token.RBRACKET);
			lhs = new Expression.Subscript(lhs, rhs, pos);
			break;
		default: return lhs;
		}
	}

	private Expression newexpr() {
		int pos = line;
		match(Token.NEW);
		if (token.type == Token.VAR) {
			match(Token.VAR);
			match(Token.LBRACKET);
			Expression e = expression();
			match(Token.RBRACKET);
			return new Expression.NewArray(e, pos);
		}
		Expression ctor = newctor();
		match(Token.LPAREN);
		Expression expr = new Expression.New(ctor, arguments(), pos);
		match(Token.RPAREN);
		return expr;
	}

	private Expression newctor() {
		int pos = line;
		String s = token.text;
		match(Token.IDENTIFIER);
		Expression lhs = new Expression.Identifier(s, pos);
		if (token.type == Token.DOT) {
			match(Token.DOT);
			String rhs = token.text;
			match(Token.IDENTIFIER);
			return new Expression.Dot(lhs, rhs, pos);
		}
		return lhs;
	}

	private List<Expression> arguments() {
		List<Expression> args = new ArrayList<>();
		if (token.type == Token.RPAREN)
			return args;
		while (true) {
			args.add(assignment());
			if (token.type == Token.COMMA)
				nextoken();
			else break;
		}
		return args;
	}

	private void nextoken() {
		token = tokens.get(index++);
		if (token.type == Token.NEWLINE) {
			line++;
			nextoken();
		}
	}

	private void match(int type) {
		if (token.type == type)
			nextoken();
		else Log.error("expected "+lexema(type)+" found "+lexema(token.type), line);
	}

	private String lexema(int type) {
		switch (type) {
		case Token.EOT: return("<eot>");
		case Token.DOT: return(".");
		case Token.COMMA: return(",");
		case Token.COLON: return(":");
		case Token.LPAREN: return("(");
		case Token.RPAREN: return(")");
		case Token.LBRACE: return("{");
		case Token.RBRACE: return("}");
		case Token.LBRACKET: return("[");
		case Token.RBRACKET: return("]");
		case Token.SEMICOLON: return(";");
		case Token.ASSIGN: return("=");
		case Token.PLUS: return("+");
		case Token.MINUS: return("-");
		case Token.MULT: return("*");
		case Token.DIV: return("/");
		case Token.MOD: return("%");
		case Token.INC: return("++");
		case Token.DEC: return("--");
		case Token.SHL: return("<<");
		case Token.SHR: return(">>");
		case Token.BOR: return("|");
		case Token.BXOR: return("^");
		case Token.BAND: return("&");
		case Token.BNOT: return("~");
		case Token.LOR: return("||");
		case Token.LAND: return("&&");
		case Token.LNOT: return("!");
		case Token.CEQ: return("==");
		case Token.CNE: return("!=");
		case Token.CLT: return("<");
		case Token.CLE: return("<=");
		case Token.CGT: return(">");
		case Token.CGE: return(">=");
		case Token.NEW: return("new");
		case Token.IMPORT: return("import");
		case Token.CLASS: return("class");
		case Token.FUNCTION: return("function");
		case Token.THIS: return("this");
		case Token.VAR: return("var");
		case Token.IF: return("if");
		case Token.ELSE: return("else");
		case Token.REPEAT: return("repeat");
		case Token.UNTIL: return("until");
		case Token.WHILE: return("while");
		case Token.FOR: return("for");
		case Token.FOREACH: return("foreach");
		case Token.FOREVER: return("forever");
		case Token.BREAK: return("break");
		case Token.CONTINUE: return("continue");
		case Token.RETURN: return("return");
		case Token.ASSERT: return("assert");
		case Token.LOG: return("log");
		case Token.NULL: return("null");
		case Token.TRUE: return("true");
		case Token.FALSE: return("false");
		case Token.INTLIT: return("integer");
		case Token.FLTLIT: return("number");
		case Token.STRLIT: return("string");
		case Token.IDENTIFIER: return("identifier");
		default: return("<error>");
		}
	}
}