package com.saral;

public class Type {

	public String name;

	public Type(String name) {
		this.name = name;
	}
	
	public static Type of(String name) {
		return new Type(name);
	}
}
