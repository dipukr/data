package com.saral;

public class DataType {

	public static final int BOOLEAN = 0;
	public static final int CHAR = 1;
	public static final int INT = 2;
	public static final int LONG = 3;
	public static final int DECIMAL = 4;
	public static final int STRING = 5;
	public static final int OBJECT = 6;
	public static final int OTHER = 7;
}
