package com.saral;

import java.util.HashMap;
import java.util.Map;

public final class Scope {
	
	private Map<String, Symbol> symbols = new HashMap<>();
	private Scope parent;

	public Scope(Scope parent) {
		this.parent = parent;
	}
	
	public boolean contains(Symbol sym) {
		return symbols.containsKey(sym.name) ? true : false;
	}

	public void define(Symbol sym) {
		symbols.put(sym.name, sym);
		sym.scope = this;
	}

	public Symbol resolve(String name) {
		Symbol sym = symbols.get(name);
		if (sym != null) return sym;
		if (parent != null) return parent.resolve(name);
		return null;
	}

	public Scope parentScope() {
		return parent;
	}
	
	@Override
	public String toString() {
		return String.format("Scope{syms: %s}", symbols.values());
	}
}