package com.saral;

import java.util.List;

public abstract class Statement {
	
	public int lineNo;
	
	public Statement(int lineNo) {
		this.lineNo = lineNo;
	}
	public abstract void accept(Visitor visitor);
	
	public static class ClassDef extends Statement {
		public Name name;
		public List<Var> vars;
		public List<Statement> functions;
		public Symbol symbol;
		
		public ClassDef(Name name, List<Var> vars, List<Statement> functions, int lineNo) {
			super(lineNo);
			this.name = name;
			this.vars = vars;
			this.functions = functions;
		}
		
		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class Function extends Statement {
		public Name name;
		public List<Param> parameters;
		public List<Statement> statements;
		public boolean isConstructor;
		public boolean isClassLevel;
		public Symbol symbol;
		
		public Function(Name name, List<String> parameters, List<Statement> statements, 
				boolean isConstructor, boolean isClassLevel, int lineNo) {
			super(lineNo);
			this.name = name;
			this.parameters = parameters;
			this.statements = statements;
			this.isConstructor = isConstructor;
			this.isClassLevel = isClassLevel;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Var extends Statement {
		public String name;
		public Expression expression;
		public Symbol sym;

		public Var(String name, Expression expression, int lineNo) {
			super(lineNo);
			this.name = name;
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class Val extends Statement {
		public String name;
		public Expression expression;
		public Symbol symbol;

		public Val(String name, Expression expression, int lineNo) {
			super(lineNo);
			this.name = name;
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Block extends Statement {
		public List<Statement> statements;

		public Block(List<Statement> statements, int lineNo) {
			super(lineNo);
			this.statements = statements;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class IfElse extends Statement {
		public Expression condition;
		public Statement ifStatement;
		public Statement elseStatement;

		public IfElse(Expression condition, Statement ifStatement, Statement elseStatement, int lineNo) {
			super(lineNo);
			this.condition = condition;
			this.ifStatement = ifStatement;
			this.elseStatement = elseStatement;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Repeat extends Statement {
		public Expression condition;
		public List<Statement> statements;

		public Repeat(Expression condition, List<Statement> statements, int lineNo) {
			super(lineNo);
			this.condition = condition;
			this.statements = statements;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class While extends Statement {
		public Expression condition;
		public Statement statement;

		public While(Expression condition, Statement statement, int lineNo) {
			super(lineNo);
			this.condition = condition;
			this.statement = statement;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class For extends Statement {
		public Statement variable;
		public Expression condition;
		public Expression iteration;
		public Statement statement;

		public For(Statement variable, Expression condition, Expression iteration, Statement statement, int lineNo) {
			super(lineNo);
			this.variable = variable;
			this.condition = condition;
			this.iteration = iteration;
			this.statement = statement;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Foreach extends Statement {
		public String left;
		public String right;
		public Statement statement;
		
		public Foreach(String left, String right, Statement statement, int lineNo) {
			super(lineNo);
			this.left = left;
			this.right = right;
			this.statement = statement;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Forever extends Statement {
		public Statement statement;
		
		public Forever(Statement statement, int lineNo) {
			super(lineNo);
			this.statement = statement;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Break extends Statement {
		public Break(int lineNo) {
			super(lineNo);
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Continue extends Statement {
		public Continue(int lineNo) {
			super(lineNo);
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Return extends Statement {
		public Expression expression;

		public Return(Expression expression, int lineNo) {
			super(lineNo);
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Assert extends Statement {
		public Expression expression;

		public Assert(Expression expression, int lineNo) {
			super(lineNo);
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Console extends Statement {
		public List<Expression> expressions;

		public Console(List<Expression> expressions, int lineNo) {
			super(lineNo);
			this.expressions = expressions;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Expresion extends Statement {
		public Expression expression;

		public Expresion(Expression expression, int lineNo) {
			super(lineNo);
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public interface Visitor {
		void visit(ClassDef statement);
		void visit(Function statement);
		void visit(Var statement);
		void visit(Val statement);
		void visit(Block statement);
		void visit(IfElse statement);
		void visit(Repeat statement);
		void visit(While statement);
		void visit(For statement);
		void visit(Foreach statement);
		void visit(Forever statement);
		void visit(Break statement);
		void visit(Continue statement);
		void visit(Return statement);
		void visit(Assert statement);
		void visit(Console statement);
		void visit(Expresion statement);
	}
}