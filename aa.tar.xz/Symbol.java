package com.saral;

public class Symbol {

	public String name;
	public Type type;
	public Scope scope;

	public Symbol(String name) {
		this(name, null);
	}
	
	public Symbol(String name, Type type) {
		this.name = name;
		this.type = type;
	}
	
	public static Symbol of(String name, Type type) {
		return new Symbol(name, type);
	}
	
	@Override
	public String toString() {
		return String.format("Symbol{name: %s}", name);
	}
}
