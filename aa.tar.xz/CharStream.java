package com.saral;

import java.io.File;

public final class CharStream {

	private final char[] chars;
	private int current;
	
	public CharStream(File file) {
		this.chars = Loader.load(file);
		this.current = 0;
	}
	
	public boolean atEnd() {
		return current >= chars.length;
	}
	
	public char seekChar() {
		return chars[current];
	}

	public char nextChar() {
		return chars[current++];
	}
	
	public void advance() {
		current++;
	}
	
	public int current() {
		return current;
	}

	public boolean match(char c) {
		if (atEnd()) return false;
		if (seekChar() != c) return false;
		nextChar();
		return true;
	}
	
	public String extractWord(int start) {
		return new String(chars, start, current - start);
	}
	
	public static CharStream of(File file) {
		return new CharStream(file);
	}
	
	@Override
	public String toString() {
		return new String(chars);
	}
}
