package com.saral;

import java.util.List;

public abstract class Expression {

	public Expression() {}
	public abstract void accept(Visitor visitor);

	public static class Negation extends Expression {
		public Expression expression;

		public Negation(Expression expression) {
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Increment extends Expression {
		public Expression expression;

		public Increment(Expression expression) {
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Decrement extends Expression {
		public Expression expression;

		public Decrement(Expression expression) {
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Addition extends Expression {
		public Expression left;
		public Expression right;

		public Addition(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}
		
		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Subtraction extends Expression {
		public Expression left;
		public Expression right;

		public Subtraction(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Multiply extends Expression {
		public Expression left;
		public Expression right;

		public Multiply(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Division extends Expression {
		public Expression left;
		public Expression right;

		public Division(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Modulus extends Expression {
		public Expression left;
		public Expression right;

		public Modulus(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class ShiftLeft extends Expression {
		public Expression left;
		public Expression right;

		public ShiftLeft(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class ShiftRight extends Expression {
		public Expression left;
		public Expression right;

		public ShiftRight(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class BitwiseOR extends Expression {
		public Expression left;
		public Expression right;

		public BitwiseOR(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class BitwiseXOR extends Expression {
		public Expression left;
		public Expression right;

		public BitwiseXOR(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class BitwiseAND extends Expression {
		public Expression left;
		public Expression right;

		public BitwiseAND(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class BitwiseNOT extends Expression {
		public Expression expression;

		public BitwiseNOT(Expression expression) {
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class Equal extends Expression {
		public Expression left;
		public Expression right;

		public Equal(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class NotEqual extends Expression {
		public Expression left;
		public Expression right;

		public NotEqual(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class LessThan extends Expression {
		public Expression left;
		public Expression right;

		public LessThan(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class LessEqual extends Expression {
		public Expression left;
		public Expression right;

		public LessEqual(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class GreaterThan extends Expression {
		public Expression left;
		public Expression right;

		public GreaterThan(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class GreaterEqual extends Expression {
		public Expression left;
		public Expression right;

		public GreaterEqual(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class LogicalOR extends Expression {
		public Expression left;
		public Expression right;

		public LogicalOR(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class LogicalAND extends Expression {
		public Expression left;
		public Expression right;

		public LogicalAND(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class LogicalNOT extends Expression {
		public Expression expression;

		public LogicalNOT(Expression expression) {
			this.expression = expression;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class FunctionCall extends Expression {
		public Expression caller;
		public List<Expression> arguments;

		public FunctionCall(Expression caller, List<Expression> arguments) {
			this.caller = caller;
			this.arguments = arguments;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Subscript extends Expression {
		public Expression left;
		public Expression right;

		public Subscript(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class Conditional extends Expression {
		public Expression condition;
		public Expression left;
		public Expression right;
		
		public Conditional(Expression condition, Expression left, Expression right) {
			this.condition = condition;
			this.left = left;
			this.right = right;
		}
		
		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Assignment extends Expression {
		public Expression left;
		public Expression right;

		public Assignment(Expression left, Expression right) {
			this.left = left;
			this.right = right;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Identifier extends Expression {
		public Name name;
		public Scope scope;
		public Symbol sym;

		public Identifier(Name name) {
			this.name = name;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class Null extends Expression {
		public Null() {}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class True extends Expression {
		public True() {}

		public void accept(Visitor v) {
			v.visit(this);
		}
	}

	public static class False extends Expression {
		public False() {}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static class IntLiteral extends Expression {
		public int value;

		public IntLiteral(int value) {
			this.value = value;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class LongLiteral extends Expression {
		public long value;

		public LongLiteral(int value) {
			this.value = value;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class DecimalLiteral extends Expression {
		public double value;

		public DecimalLiteral(Double value) {
			this.value = value;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}
	
	public static class StringLiteral extends Expression {
		public String value;

		public StringLiteral(String value) {
			this.value = value;
		}

		public void accept(Visitor visitor) {
			visitor.visit(this);
		}
	}

	public static interface Visitor {
		public void visit(Negation       expression);
		public void visit(Increment      expression);
		public void visit(Decrement      expression);
		public void visit(Addition       expression);
		public void visit(Subtraction    expression);
		public void visit(Multiply       expression);
		public void visit(Division       expression);
		public void visit(Modulus        expression);
		public void visit(ShiftLeft      expression);
		public void visit(ShiftRight     expression);
		public void visit(BitwiseOR      expression);
		public void visit(BitwiseXOR     expression);
		public void visit(BitwiseAND     expression);
		public void visit(BitwiseNOT     expression);
		public void visit(Equal          expression);
		public void visit(NotEqual       expression);
		public void visit(LessThan       expression);
		public void visit(LessEqual      expression);
		public void visit(GreaterThan  	 expression);
		public void visit(GreaterEqual   expression);
		public void visit(LogicalOR      expression);
		public void visit(LogicalAND     expression);
		public void visit(LogicalNOT     expression);
		public void visit(FunctionCall   expression);
		public void visit(Subscript      expression);
		public void visit(Conditional    expression);
		public void visit(Assignment     expression);
		public void visit(Identifier     expression);
		public void visit(Null           expression);
		public void visit(True           expression);
		public void visit(False          expression);
		public void visit(IntLiteral     expression);
		public void visit(LongLiteral    expression);
		public void visit(DecimalLiteral expression);
		public void visit(StringLiteral  expression);
	}
}