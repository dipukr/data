package com.saral;

public class Name {

	public String name;
	public int lineNo;
	
	public Name(String name, int lineNo) {
		this.name = name;
		this.lineNo = lineNo;
	}
	
	public static Name of(String name, int lineNo) {
		return new Name(name, lineNo);
	}
}
