package com.saral;

public final class Error {
	
	public static final String FATAL = "Fatal";
	public static final String LEXICAL = "Lexical";
	public static final String PARSE = "Parse";
	public static final String SEMANTIC = "Semantic";
	
	public static void fatal(String msg) {
		System.err.printf("Fatal error: %s\n", msg);
		System.exit(0);
	}
	
	public static void fatal(String what, int lineNo) {
		report(FATAL, what, lineNo);
	}
	
	public static void report(String kind, String what, int lineNo) {
		System.err.printf("%s error: %s on line %d\n", kind, what, lineNo);
		System.exit(0);
	}
	
	public static void lexical(char ch, int lineNo) {
		System.err.printf("Lexical error: illegal char '%c' on line %d\n", ch, lineNo);
		System.exit(0);
	}
}
