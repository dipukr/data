package com.saral;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Scanner {
	
	private Map<String, Integer> keywords = new HashMap<String, Integer>();
	private List<Token> tokens = new ArrayList<Token>();
	private CharStream charStream;
	private int lineNo;
	private int start;
	private char ch;
	
	public Scanner(CharStream charStream) {
		this.charStream = charStream;
		this.lineNo = 1;
		this.start = 0;
		this.ch = '\0';
	}

	public List<Token> scan() {
		populateKeywords();
		scanAll();
		tokens.add(Token.of(Token.EOT, null, -1));
		return tokens;
	}

	public void scanAll() {
		while (!charStream.atEnd()) {
			this.start = charStream.current();
			this.scanToken();
		}
	}

	private void scanComment() {
		while (!charStream.atEnd() && charStream.seekChar() != '\n')
			charStream.advance();
	}

	private void scanToken() {
		switch (ch = charStream.nextChar()) {
		case ' ':
		case '\t':
		case '\r': break;
		case '\n': lineNo++; break;
		case '.': addToken(Token.DOT); break;
		case '?': addToken(Token.CONDITION); break;
		case ',': addToken(Token.COMMA); break;
		case ':': addToken(charStream.match(':') ? Token.BICOLON : Token.COLON); break;
		case '(': addToken(Token.LPAREN); break;
		case ')': addToken(Token.RPAREN); break;
		case '{': addToken(Token.LBRACE); break;
		case '}': addToken(Token.RBRACE); break;
		case '[': addToken(Token.LBRACKET); break;
		case ']': addToken(Token.RBRACKET); break;
		case ';': addToken(Token.SEMICOLON); break;
		case '*': addToken(Token.MULT); break;
		case '/': addToken(Token.DIV); break;
		case '%': addToken(Token.MOD); break;
		case '^': addToken(Token.BXOR); break;
		case '~': addToken(Token.BNOT); break;
		case '+': addToken(charStream.match('+') ? Token.INC : Token.PLUS); break;
		case '-': addToken(charStream.match('-') ? Token.DEC : Token.MINUS); break;
		case '|': addToken(charStream.match('|') ? Token.OR  : Token.BOR); break;
		case '&': addToken(charStream.match('&') ? Token.AND : Token.BAND); break;
		case '!': addToken(charStream.match('=') ? Token.RNE : Token.NOT); break;
		case '=': addToken(charStream.match('=') ? Token.REQ : Token.ASSIGN); break;
		case '<': addToken(charStream.match('<') ? Token.SHL : charStream.match('=') ? Token.RLE : Token.RLT); break;
		case '>': addToken(charStream.match('>') ? Token.SHR : charStream.match('=') ? Token.RGE : Token.RGT); break;
		case '"': scanString(); break;
		case '@': scanComment(); break;
		default:
		if (digit(ch)) scanNumber();
		else if (alpha(ch)) scanIdentifier();
		else Error.lexical(ch, lineNo);
		}
	}

	private void addToken(int type) {
		String word = charStream.extractWord(start);
		tokens.add(Token.of(type, word, lineNo));
	}

	private void addToken(int type, String word) {
		tokens.add(Token.of(type, word, lineNo));
	}

	private void scanString() {
		StringBuilder builder = new StringBuilder();
		while (!charStream.atEnd() && charStream.seekChar() != '"') {
			char ch = charStream.nextChar();
			if (charStream.seekChar() == '\\') {
				switch (charStream.nextChar()) {
				case 't' : builder.append('\t');
				case 'n' : builder.append('\n');
				case '\\': builder.append('\\');
				case '\'': builder.append('\'');
				default: Error.lexical(charStream.seekChar(), lineNo);
				}
			} else builder.append(ch);
		}
		if (charStream.seekChar() == '"') charStream.advance();
		else Error.report(Error.LEXICAL, "unbalanced string quotes", lineNo);
		String word = builder.toString();
		tokens.add(Token.of(Token.STRLIT, word, lineNo));
	}

	private void scanIdentifier() {
		int start = charStream.current();
		while (alnum(charStream.seekChar()))
			charStream.advance();
		String word = charStream.extractWord(start);
		int type = findTokenType(word);
		addToken(type, word);
	}

	private void scanNumber() {
		while (digit(charStream.seekChar()))
			charStream.advance();
		if (charStream.seekChar() == '.') {
			if (charStream.seekChar() == '.') {
				charStream.advance();
				while (digit(charStream.seekChar()))
					charStream.advance();
			}
			addToken(Token.DECLIT);
		} else addToken(Token.INTLIT);
	}

	private int findTokenType(String word) {
		return keywords.containsKey(word) ? keywords.get(word) : Token.IDENTIFIER;
	}

	private boolean digit(char c) {
		return (c >= '0' && c <= '9');
	}

	private boolean alpha(char c) {
		return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c == '_');
	}

	private boolean alnum(char c) {
		return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
	}

	private void populateKeywords() {
		keywords.put("void", Token.VOID);
		keywords.put("char", Token.CHAR);
		keywords.put("int", Token.INT);
		keywords.put("long", Token.LONG);
		keywords.put("decimal", Token.DECIMAL);
		keywords.put("if", Token.IF);
		keywords.put("else", Token.ELSE);
		keywords.put("while", Token.WHILE);
		keywords.put("repeat", Token.REPEAT);
		keywords.put("until", Token.UNTIL);
		keywords.put("for", Token.FOR);
		keywords.put("forever", Token.FOREVER);
		keywords.put("foreach", Token.FOREACH);
		keywords.put("break", Token.BREAK);
		keywords.put("continue", Token.CONTINUE);
		keywords.put("return", Token.RETURN);
		keywords.put("assert", Token.ASSERT);
		keywords.put("console", Token.CONSOLE);
		keywords.put("null", Token.NULL);
		keywords.put("true", Token.TRUE);
		keywords.put("false", Token.FALSE);
		keywords.put("or", Token.OR);
		keywords.put("and", Token.AND);
		keywords.put("not", Token.NOT);
		keywords.put("new", Token.NEW);
		keywords.put("using", Token.USING);
		keywords.put("class", Token.CLASS);
		keywords.put("self", Token.SELF);
		keywords.put("function", Token.SELF);
	}
	
	public static TokenStream scan(CharStream charStream) {
		Scanner scanner = new Scanner(charStream);
		List<Token> tokens = scanner.scan();
		return new TokenStream(tokens);
	}
}
