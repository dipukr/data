public class Terminal extends Symbol {
	
	public Terminal(int code, String name) {
		super(code, name);
	}
	
	public boolean equals(Object obj) {
		if (obj == this)
			return true;
		if(obj == null)
			return false;
		if (obj.getClass() != Terminal.class)
			return false;
		Terminal ts = (Terminal) obj;
		return this.getCode() == ts.getCode();
	}
	
	public boolean isTerminal() { return true; }
	public boolean isNonTerminal() { return false; }
}