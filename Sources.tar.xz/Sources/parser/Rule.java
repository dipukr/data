import java.util.Arrays;

// Represents productions in context-free grammar. In this type of grammars left
// side of productions contains only one nonterminal symbol.

public class Rule {
	private int ruleNumber;       // Number of the rule
	private NonTerminal leftSide; // Left side of production
	private Symbol[] rightSide;   // Right side of production

	// Creates a rule
	// ruleNumber: number of rule as it is in grammar description
	// leftSide: nonterminal symbol in the left side of rule
	// rightSide: terminals and nonterminals in the right side
	
	public Rule(int ruleNumber, NonTerminal leftSide, Symbol[] rightSide) {
		this.ruleNumber = ruleNumber;
		this.leftSide = leftSide;
		this.rightSide = rightSide;
	}

	public int getRuleNumber() {
		return ruleNumber;
	}

	public NonTerminal getLeftSide() {
		return leftSide;
	}

	public Symbol[] getRightSide() {
		return rightSide;
	}

	public String toString() {
		return "Rule number: " + ruleNumber + "| " + leftSide + " -> " + Arrays.toString(rightSide);
	}

}