#include <stdio.h>
#include "../jam.h"
#include "../sig.h"

int extraArgSpace(MethodBlock *mb) {
    return (mb->access_flags & ACC_STATIC ? mb->args_count+1 : mb->args_count) + 1;
}

u4 *callJNIMethod(void *env, Class *class, char *sig, int extra, u4 *ostack, unsigned char *f) {
    u4 args[extra];
    u4 *opntr = ostack;
    u4 *apntr = &args[2];
   
    args[0] = (u4)env;
    args[1] = class ? (u4)class : *opntr++;

    SCAN_SIG(sig, *((u8*)apntr)++ = *((u8*)opntr)++, *apntr++ = *opntr++);

    switch(*sig) {
        case 'V':
            (*(void (*)())f)();
            break;

        case 'D':
            *((double*)ostack)++ = (*(double (*)())f)();
            break;

        case 'F':
            *((float*)ostack)++ = (*(float (*)())f)();
            break;

        case 'J':
            *((long long*)ostack)++ = (*(long long (*)())f)();
            break;

        default:
            *ostack++ = (*(u4 (*)())f)();
            break;
    }

    return ostack;
}
