#ifndef CREATING
#include <pthread.h>
#include <setjmp.h>

/* Thread states */

#define CREATING     0
#define STARTED      1
#define RUNNING      2
#define WAITING      3
#define SUSPENDED    5

typedef struct thread Thread;

typedef struct monitor {
    pthread_mutex_t lock;
    pthread_cond_t cv;
    Thread *owner;
    int count;
    int waiting;
    int notifying;
    int interrupting;
    int entering;
    struct monitor *next;
    char in_use;
} Monitor;

struct thread {
    char state;
    char interrupted;
    char interrupting;
    char suspend;
    char blocking;
    pthread_t tid;
    int id;
    ExecEnv *ee;
    void *stack_top;
    void *stack_base;
    Monitor *wait_mon;
    Thread *prev, *next;
};

extern Thread *threadSelf();
extern Thread *threadSelf0(Object *jThread);

extern void *getStackTop(Thread *thread);
extern void *getStackBase(Thread *thread);

extern void threadInterrupt(Thread *thread);
extern void threadSleep(Thread *thread, long long ms, int ns);
extern int systemIdle(Thread *self);

extern void disableSuspend0(Thread *thread, void *stack_top);
extern void enableSuspend(Thread *thread);

#define disableSuspend(thread)          \
{                                       \
    sigjmp_buf *env;                    \
    env = alloca(sizeof(sigjmp_buf));   \
    sigsetjmp(*env, FALSE);             \
    disableSuspend0(thread, (void*)env);\
}

typedef struct {
    pthread_mutex_t lock;
    pthread_cond_t cv;
} VMWaitLock;

typedef pthread_mutex_t VMLock;

#define initVMLock(lock) pthread_mutex_init(&lock, NULL)
#define initVMWaitLock(wait_lock) {            \
    pthread_mutex_init(&wait_lock.lock, NULL); \
    pthread_cond_init(&wait_lock.cv, NULL);    \
}

#define lockVMLock(lock, self) { \
    self->state = WAITING;       \
    pthread_mutex_lock(&lock);   \
    self->state = RUNNING;       \
}

#define unlockVMLock(lock, self) pthread_mutex_unlock(&lock)

#define lockVMWaitLock(wait_lock, self) lockVMLock(wait_lock.lock, self)
#define unlockVMWaitLock(wait_lock, self) unlockVMLock(wait_lock.lock, self)
#define waitVMWaitLock(wait_lock, self) {              \
    self->state = WAITING;                             \
    pthread_cond_wait(&wait_lock.cv, &wait_lock.lock); \
    self->state = RUNNING;                             \
}
#define notifyVMWaitLock(wait_lock, self) pthread_cond_signal(&wait_lock.cv)
#endif
