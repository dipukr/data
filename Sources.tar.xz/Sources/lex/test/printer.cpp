/* Java Pretty-Printer. */

#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

void BeforeLexing() {
  cout << "<html>" << endl;
  cout << "  <head>" << endl;
  cout << "    <title>Java Pretty Print</title>" << endl;
  cout << "  </head>" << endl;
  cout << "  <body style=\"font-family: monospace;\">" << endl;
}

void AfterLexing() {
  cout << "  </body>" << endl;
  cout << "</html>" << endl;
}

string TransformHTML(const string& input) {
  string result;
  for (string::const_iterator itr = input.begin(); itr != input.end(); ++itr) {
    if (*itr == ' ')
      result += "&nbsp;";
    else if (*itr == '\n')
      result += "<br>";
    else if (*itr == '\t')
      result += "&nbsp;&nbsp;";
    else if (*itr == '<')
      result += "&lt;";
    else if (*itr == '>')
      result += "&gt;";
    else if (*itr == '&')
      result += "&amp;";
    else if (*itr == '"')
      result += "&quot;";
    else
      result += *itr;
  }
  return result;
}

void ProcessToken(const std::string& rawLexeme,
                  const std::string& tokenType) {
  string lexeme = TransformHTML(rawLexeme);
  if (tokenType == "Keyword")
    cout << "<span style=\"color: blue\">" << lexeme << "</span>";
  else if (tokenType == "Operator" || 
           tokenType == "Syntax" ||
           tokenType == "Identifier" ||
           tokenType == "Whitespace")
    cout << lexeme;
  else if (tokenType == "Literal" || tokenType == "String")
    cout << "<span style=\"color: orange\">" << lexeme << "</span>";
  else if (tokenType == "Comment")
    cout << "<span style=\"color: green\">" << lexeme << "</span>";
  else if (tokenType == "Annotation")
    cout << "<span style=\"color: gray\">" << lexeme << "</span>";
  else if (tokenType == "JavadocComment")
    cout << "<span style=\"color: magenta\">" << lexeme << "</span>";
  else
    throw runtime_error("Unknown token type: " + tokenType);
}
