/************************************************
 * File: main.cpp
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * Main entry point for the Strain lexer.  This
 * code glues together all of the pieces defined
 * elsewhere into a coherent executable.
 */

#include "Lexer.h"
#include "Parser.h"
#include "Lexemes.h"
#include "Expression.h"
#include "LexemeQueue.h"
#include "CFGElement.h"
#include "Automaton.h"
#include "CodeGenerator.h"
#include <iostream>
#include <set>
#include <queue>
#include <iomanip>
#include <typeinfo>
#include <cstdlib>
#include <fstream>
#include <stdexcept>
using namespace std;

/* Configuration struct.  This holds information about what
 * operation we are to perform.
 */
struct StrainConfiguration {
  bool isVerbose;           // Print lots of output?
  string outputFile;        // Where to write the result.
  istream* inputFile;       // The input file
  CodeGenerator* generator; // The code generator to use on the result.
};

/* Prints info about how this is supposed to be used. */
void PrintUsage() {
  cout << "strain: Like flex, but more likely to hurt." << endl;
  cout << "Usage: strain inputfile [-o outputfile] [-v]" << endl;
  cout << "   -o outputfile: Write result to file rather than stdout." << endl;
  cout << "   -v: Verbose mode." << endl;
}

/* Parses command-line options into a StrainConfiguration struct. */
StrainConfiguration ParseOptions(int argc, const char* argv[]) {

  /* Convert argv[] to a list of strings to make processing
   * easier.
   */
  vector<string> args(argv, argv + argc);

  /* Check that we have at least two args (so we have an
   * input file)
   */
  if (argc < 2) {
    PrintUsage();
    exit(0);
  }

  string inputFile = argv[1];
  string outputFile;
  bool hasOutputFile = false;
  bool isVerbose = false;

  /* Parse options */
  for (size_t i = 2; i < args.size(); ++i) {
    if (args[i] == "-v") {
      isVerbose = true;
    } else if (args[i] == "-o") {
      ++i;
      if (i == args.size()) {
        cout << "-o must be followed by output file." << endl;
        exit(-1);
      }
      hasOutputFile = true;
      outputFile = args[i];
    } else {
      cout << "Unknown option: " << args[i] << endl;
      exit(-1);
    }
  }

  /* Convert to a result struct. */
  StrainConfiguration result;
  result.isVerbose = isVerbose;
  result.generator = new CCodeGenerator();
  result.outputFile = outputFile;
  
  ifstream* input = new ifstream(inputFile.c_str());
  if (!input)
    throw runtime_error("Could not open input file: " + inputFile);
  if (!hasOutputFile)
    throw runtime_error("Must specify an output file.");
  result.inputFile = input;

  return result;
}

/* Parses the input file into a list of regexps and token names. */
vector< pair<string, string> > ReadFileContents(istream& input) {
  /* File format is:
   * 
   * TokenName
   * Regexp
   * 
   * TokenName
   * Regexp
   *
   * ... etc ...
   */
  vector< pair<string, string> > result;

  string token, regexp, dummy;
  while (true) {
    if (!getline(input, token)) return result; // Okay to fail here.
    if (!getline(input, regexp))
      throw runtime_error("Expected regexp, found EOF.");
    if (!getline(input, dummy))
      throw runtime_error("Expected blank line, found EOF.");

    /* Check that the dummy is empty. */
    if (!dummy.empty())
      throw runtime_error("Unexpected line: " + dummy);

    /* Add the token/regexp pair. */
    result.push_back(make_pair(token, regexp));
  }
}

/**
 * Syntax:
 * strain inputfile [-o outputFile] [-v]
 */ 
int main(int argc, const char* argv[]) {
  try{
    /* Get configuration information. */
    StrainConfiguration config = ParseOptions(argc, argv);

    /* If verbose is not turned on, kill clog.  All operations which then
     * try to write to it will not produce any output.
     */
    if (!config.isVerbose)
      clog.setstate(ios::failbit);

    /* Get back the list of regexps and their names. */
    vector< pair<string, string> > fileContents =
      ReadFileContents(*config.inputFile);

    /* Log them. */
    for (size_t i = 0; i < fileContents.size(); ++i) {
      clog << "Token:  " << fileContents[i].first << endl;
      clog << "Regexp: " << fileContents[i].second << endl;
    }

    /* Lex and parse each line. */
    vector<Expression*> regexps;
    for (size_t i = 0; i < fileContents.size(); ++i) {
      clog << "Lexing and parsing regexp: " 
           << fileContents[i].second << endl;
      regexps.push_back(Parse(Lex(fileContents[i].second)));
    }

    /* Convert each to an automaton. */
    vector<RegexpAutomaton> automata;
    for (size_t i = 0; i < regexps.size(); ++i) {
      clog << "Converting regexp " << i << " to an automaton." << endl;
      automata.push_back(regexps[i]->toAutomaton(i));
    }

    /* Create a new e-NFA whose start state has epsilon transitions to
     * each of these automata's start states.  This automaton is what
     * ends up doing the lexing.
     */
    RegexpAutomaton lexerENFA;
    lexerENFA.start = new MachineState;
    for (size_t i = 0; i < automata.size(); ++i)
      lexerENFA.start->eTransitions.insert(automata[i].start);

    /* Use the subset construction to build a single DFA for the entire
     * world.
     */
    clog << "Constructing lexer DFA." << endl;
    RegexpAutomaton lexerDFA = DoSubsetConstruction(lexerENFA);

    /* Minimize the DFA to reduce the number of states we produce. */
    clog << "Minimizing lexer DFA." << endl;
    MinimizeDFA(lexerDFA);

    /* Generate the lexer! */
    config.generator->writeLexer(lexerDFA, fileContents, config.outputFile);

  } catch (const exception& e) {
    cout << e.what() << endl;
    return -1;
  }
}
