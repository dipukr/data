/*************************************************
 * File: Lexer.hh
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * Exports the Lex function, which lexes a string
 * containing a regular expression into a
 * LexemeQueue.  See the .cpp file for a more
 * in-depth discussion of how the lexer works.
 */

#ifndef Lexer_Included
#define Lexer_Included

/* #includes and forward-declarations. */
#include <string>
class LexemeQueue;

/**
 * Lexes a string, returning a LexemeQueue of the tokens it contains.
 */
LexemeQueue Lex(const std::string& sourceString);

#endif
