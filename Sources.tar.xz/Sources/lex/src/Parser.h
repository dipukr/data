/*************************************************
 * File: Parser.hh
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * Exports the Parse function, which converts a
 * token stream into an Expression.
 */

#ifndef Parser_Included
#define Parser_Included

/* Forward declarations */
class Expression;
class LexemeQueue;

/**
 * Parses the specified LexemeQueue into a regular expression.
 */
Expression* Parse(LexemeQueue lexemes);

#endif
