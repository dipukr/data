/*************************************************
 * File: CodeGenerator.hh
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * An interface representing something that can
 * generate code for the lexer.  There is currently
 * only one of these, though I hope to someday
 * extend the hierarchy to handle PHP, Java, etc.
 */
#ifndef CodeGenerator_Included
#define CodeGenerator_Included

#include <vector>
#include <string>
#include <utility>
#include <ostream>
class RegexpAutomaton;

class CodeGenerator {
public:
  virtual ~CodeGenerator() {}

  /* The parameters are:
   * 1. The minimized DFA automaton.
   * 2. A list of pairs of token types and their associated regexps.
   * 3. A file to write the result.
   */
  virtual void writeLexer(RegexpAutomaton automaton,
                          const std::vector< std::pair<std::string, std::string> >& tokens,
                          const std::string& outFile) const = 0;
};

/* A class that builds up a C++ lexer. */
class CCodeGenerator: public CodeGenerator {
  virtual void writeLexer(RegexpAutomaton automaton,
                          const std::vector< std::pair<std::string,
                          std::string> >& tokens,
                          const std::string& outFile) const;
};

#endif
