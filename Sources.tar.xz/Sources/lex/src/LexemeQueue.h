/***************************************************
 * File: LexemeQueue.hh
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * A class that acts like a queue of lexemes with the
 * restriction that a dequeue on an empty queue always
 * produces the EOFLexeme lexeme.
 */

#ifndef LexemeQueue_Included
#define LexemeQueue_Included

#include <queue>
#include "Lexemes.h"

/* A class representing a queue of Lexemes.  Its dequeue function
 * will return an EOFLexeme if no elements are left.
 */
class LexemeQueue {
public:
  void enqueue(Lexeme*);
  Lexeme* front() const;
  Lexeme* dequeue();

private:
  std::queue<Lexeme*> mQueue;
};

#endif
