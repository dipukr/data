/****************************************************
 * File: Expression.hh
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * A class hierarchy of expressions.  These classes are
 * essentially the AST from which we can derive a
 * state machine representation of the regular expression.
 */

#ifndef Expression_Included
#define Expression_Included

#include <string>
#include <set>
#include "Lexemes.h"
#include "Automaton.h"

/* Base class of all expressions. */
class Expression {
public:
  virtual ~Expression() {}

  /* Provides a string representation of the expression. */
  virtual std::string toString() const = 0;

  /* Converts the expression to an automaton where each terminal state
   * has the specified value.
   */
  virtual RegexpAutomaton toAutomaton(int exprNum) const = 0;
};

/* Character class expression. */
class CharacterClassExpression: public Expression {
public:
  explicit CharacterClassExpression(const std::set<char>& chars);
  std::string toString() const;
  RegexpAutomaton toAutomaton(int exprNum) const;

  /* The set of characters represented by this expression.  This can be
   * zero, one, or many characters depending on what created this.
   */
  std::set<char> characters() const;

private:
  const std::set<char> mChars;
};

/* Concatenation expression. */
class ConcatenationExpression: public Expression {
public:
  ConcatenationExpression(Expression* left, Expression* right);
  std::string toString() const;
  RegexpAutomaton toAutomaton(int exprNum) const;

  /* The left and right subexpressions. */
  Expression* left() const;
  Expression* right() const;

private:
  Expression* const mLeft;
  Expression* const mRight;
};

/* Disjunction expression. */
class DisjunctionExpression: public Expression {
public:
  DisjunctionExpression(Expression* left, Expression* right);
  std::string toString() const;
  RegexpAutomaton toAutomaton(int exprNum) const;

  /* The left and right subexpressions. */
  Expression* left() const;
  Expression* right() const;

private:
  Expression* const mLeft;
  Expression* const mRight;
};

/* Kleene closure expression. */
class KleeneClosureExpression: public Expression {
public:
  explicit KleeneClosureExpression(Expression* expr);
  std::string toString() const;
  RegexpAutomaton toAutomaton(int exprNum) const;

  /* The expression to be iterated. */
  Expression* expression() const;

private:
  Expression* const mExpr;
};

/* Empty expression. */
class EmptyStringExpression: public Expression {
public:
  std::string toString() const;
  RegexpAutomaton toAutomaton(int exprNum) const;
};

#endif
