/*********************************************
 * File: Lexemes.cpp
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * Implementation of the member functions of the
 * Lexeme classes.
 */

#include "Lexemes.h"
#include <cctype>
#include <algorithm>
#include <stdexcept>
using namespace std;

/* Character implementation */
Character::Character(char ch) : mChar(ch) {

}

char Character::character() const {
  return mChar;
}

/* CharacterClass implementation */
bool CharacterClass::passesPredicate(char ch) const {
  return !!mPredicate(ch);
}

/* Helper function that always returns true */
static int AlwaysTrue(int ch) {
  return 1;
}

/* Maps the appropriate string to a matching function. */
CharacterClass::CharacterClass(const std::string& str) {
  string upperCopy = str;
  transform(upperCopy.begin(), upperCopy.end(),
	    upperCopy.begin(),
	    ::toupper);

  if (upperCopy == "ALL") mPredicate = AlwaysTrue;
  else if (upperCopy == "ALPHA") mPredicate = isalpha;
  else if (upperCopy == "ALNUM") mPredicate = isalnum;
  else if (upperCopy == "LOWER") mPredicate = islower;
  else if (upperCopy == "UPPER") mPredicate = isupper;
  else if (upperCopy == "DIGIT") mPredicate = isdigit;
  else if (upperCopy == "SPACE") mPredicate = isspace;
  else if (upperCopy == "GRAPH") mPredicate = isgraph;
  else if (upperCopy == "XDIGIT") mPredicate = isxdigit;
  else throw invalid_argument("Unknown character class: " + upperCopy);
}
