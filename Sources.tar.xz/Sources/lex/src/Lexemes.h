/************************************************
 * File: Lexemes.hh
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * A file defining all possible lexemes.  Lexemes
 * inherit from the abstract base class Lexeme.
 */

#ifndef Lexemes_Included
#define Lexemes_Included

#include <string>

/* Base class of all lexemes. */
class Lexeme {
public:
  virtual ~Lexeme() {}

};

/* Empty string. */
class EmptyString: public Lexeme {
  // Empty for now
};

/* Single character. */
class Character: public Lexeme {
public:
  explicit Character(char ch);
  char character() const;

private:
  const char mChar;
};

/* Character class. */
class CharacterClass: public Lexeme {
public:
  explicit CharacterClass(const std::string& name);
  bool passesPredicate(char ch) const;
  
private:
  int (*mPredicate)(int);
};

/* Kleene Star */
class KleeneStar: public Lexeme {
  // Empty for now
};

/* Disjunction */
class Disjunction: public Lexeme {
  // Empty for now
};

/* Open Paren */
class OpenParenthesis: public Lexeme {
  // Empty for now
};

/* Close Paren */
class CloseParenthesis: public Lexeme {
  // Empty for now
};

/* Open curly brace */
class OpenCurlyBrace: public Lexeme {
  // Empty for now
};

/* Close curly brace */
class CloseCurlyBrace: public Lexeme {
  // Empty for now
};

/* Addition operator */
class Union: public Lexeme {
  // Empty for now
};

/* Difference operator */
class Subtraction: public Lexeme {
  // Empty for now
};

/* EOF Marker */
class EOFLexeme: public Lexeme {
  // Empty for now
};

#endif
