/******************************************************
 * File: LexemeQueue.cpp
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * Implementation of the LexemeQueue class.
 */

#include "LexemeQueue.h"

void LexemeQueue::enqueue(Lexeme* lex) {
  mQueue.push(lex);
}

/* If the stack is empty, pretend there is an EOF lexeme there. */
Lexeme* LexemeQueue::front() const {
  return mQueue.empty()? new EOFLexeme() : mQueue.front();
}

Lexeme* LexemeQueue::dequeue() {
  /* Note that this hands back EOFLexeme if there is nothing in
   * the queue.
   */
  Lexeme* result = front();

  if (!mQueue.empty()) mQueue.pop();
  return result;
}

