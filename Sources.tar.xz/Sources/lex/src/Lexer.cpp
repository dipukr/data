/****************************************************
 * File: Lexer.cpp
 * Author: Keith Schwarz (htiek@cs.stanford.edu)
 *
 * A lexer which breaks regular expressions apart into their
 * individual tokens.  Due to an error on my part, this lexer
 * compresses adjacent * characters together into a single *,
 * which is fine since * is idempotent.  See Parser.cpp for
 * an explanation of what went wrong.
 */

#include "Lexer.h"
#include "Lexemes.h"
#include "LexemeQueue.h"
#include <stdexcept>
using namespace std;

/* Lexes the specified string.  This uses a state machine
 * with the following states:
 *
 * 1. Main, for absorbing most tokens.
 * 2. Escape, which starts escape sequences.
 * 3. Group, which reads [group names]
 * 4. Kleene, which compresses sequences of Kleene stars.
 *
 * We compress Kleene stars because they are idempotent and
 * simplify the parser implementation.
 */
LexemeQueue Lex(const string& str) {
  enum State { Main, Escape, Group, Kleene } state = Main;
  string buffer;
  LexemeQueue result;

  for (string::const_iterator itr = str.begin(); 
       itr != str.end(); ++itr) {
    switch (state) {
      case Main:
        if (*itr == '\\')
          state = Escape;
        else if (*itr == '[')
          state = Group;
        else if (*itr == '{')
          result.enqueue(new OpenCurlyBrace());
        else if (*itr == '}')
          result.enqueue(new CloseCurlyBrace());
        else if (*itr == '(')
          result.enqueue(new OpenParenthesis());
        else if (*itr == ')')
          result.enqueue(new CloseParenthesis());
        else if (*itr == '+')
          result.enqueue(new Union());
        else if (*itr == '-')
          result.enqueue(new Subtraction());
        else if (*itr == '*')
          state = Kleene;
        else if (*itr == '|')
          result.enqueue(new Disjunction());
        else if (*itr == '~')
          result.enqueue(new EmptyString());
        else
          result.enqueue(new Character(*itr));
        break;
      case Escape:
        state = Main;
        if (*itr == 'n')
          result.enqueue(new Character('\n'));
        else if (*itr == 't')
          result.enqueue(new Character('\t'));
        else if (*itr == 'r')
          result.enqueue(new Character('\r'));
        else
          result.enqueue(new Character(*itr));
        break;
      case Group:
        if (isalpha(*itr))
          buffer += *itr;
        else if (*itr == ']') {
          state = Main;
          result.enqueue(new CharacterClass(buffer));
          buffer.clear();
        } else 
          throw invalid_argument("Unexpected char in [] block.");
        break;
    case Kleene:
      /* Absorb all stars.  All other characters are put back
       * and a Kleene star is inserted.
       */
      if (*itr != '*') {
        result.enqueue(new KleeneStar());
        state = Main;
        --itr;
      }
    }
  }

  /* If we hit EOF on a Kleene star, append one to the sequence. */
  if (state == Kleene)
    result.enqueue(new KleeneStar());

  /* Check the state in EOF and ensure that bad things didn't happen. */
  if (state == Escape || state == Group)
    throw invalid_argument("Unexpected end-of-string.");

  return result;
}
