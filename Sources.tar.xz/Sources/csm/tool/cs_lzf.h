#ifndef __cs_lsf_h
#define __cs_lsf_h

#include "cs_array.h"

namespace tool
{
  unsigned int
  lzf_compress ( const void *const in_data, unsigned int in_len,
                 void *out_data, unsigned int out_len );

  unsigned int
  lzf_decompress ( const void *const in_data, unsigned int in_len,
                   void *out_data, unsigned int out_len );

  namespace lzf
  {
    void compress ( const void *const in_data, unsigned int in_len,
                    array<byte>& out);
    bool decompress ( const void *const in_data, unsigned int in_len,
                      array<byte>& out);

  }

};

#endif
