#include "tool.h"

namespace tool
{
  string base64_encode ( const byte* data, int data_length );
  bool   base64_decode ( const char *data, int data_length, array<byte>& out );
};
