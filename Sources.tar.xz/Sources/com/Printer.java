import java.util.List;
import java.util.Iterator;

public class Printer implements Statement.Visitor, Expression.Visitor {
	
	private StringBuffer source = new StringBuffer(10000);
	private Statement module;
	private boolean inctor;
	private int margin;

	public Printer(Statement module) {
		this.module = module;
		this.inctor = false;
		this.margin = 0;
	}

	public void print() {
		print(module);
		System.out.println(source);
	}

	private void printStats(List<Statement> stats) {
		for (Statement s: stats) {
			align();
			print(s);
			println();
		}
	}

	private void printArgs(List<Expression> args) {
		Iterator<Expression> i = args.iterator();
		while (i.hasNext()) {
			print(i.next());
			if (i.hasNext()) print(", ");
		}
	}

	private void printNames(List<String> names) {
		Iterator<String> i = names.iterator();
		while (i.hasNext()) {
			print(i.next());
			if (i.hasNext()) print(", ");
		}
	}

	private void printBody(Statement expr) {
		if (expr instanceof Statement.Block)
			print(expr);
		else {
			println();
			indent();
			align();
			print(expr);
			undent();
		}
	}

	private void print(Expression expr) {
		expr.accept(this);
	}
	
	private void print(Statement stat) {
		stat.accept(this);
	}
	
	private void print(String s) {
		source.append(s);
	}
	
	private void println() {
		source.append('\n');
	}
	
	private void indent() { margin += 4; }
	private void undent() { margin -= 4; }

	private void align() {
		for (int r = 0; r < margin; ++r)
			source.append(' ');
	}

	public void visit(Statement.Module stat) {
		printStats(stat.imports);
		printStats(stat.vars);
		printStats(stat.functions);
		printStats(stat.classes);
	}

	public void visit(Statement.Import stat) {
		print("import ");
		print(stat.name);
	}

	public void visit(Statement.Classdef stat) {
		print("class ");
		print(stat.name);
		print(" {");
		println();
		indent();
		printStats(stat.vars);
		if (stat.ctor != null) {
			align();
			inctor = true;
			print(stat.ctor);
			inctor = false;
		}
		printStats(stat.functions);
		undent();
		align();
		print("}");
	}

	public void visit(Statement.Function stat) {
		if (!inctor) {
			println();
			align();
			print("function ");
		}
		print(stat.name);
		print("(");
		printNames(stat.args);
		print(")");
		print(stat.body);
	}

	public void visit(Statement.Var stat) {
		print("var ");
		print(stat.name);
		if (stat.expr != null) {
			print(" = ");
			print(stat.expr);
		}
	}

	public void visit(Statement.Block stat) {
		print(" {");
		println();
		indent();
		printStats(stat.body);
		undent();
		align();
		print("}");
	}

	public void visit(Statement.If stat) {
		print("if (");
		print(stat.cond);
		print(")");
		printBody(stat.ifbody);
		if (stat.elsebody != null) {
			println();
			align();
			print("else ");
			printBody(stat.elsebody);
		}
	}

	public void visit(Statement.Repeat stat) {
		print("repeat:");
		println();
		indent();
		printStats(stat.body);
		undent();
		align();
		print("until(");
		print(stat.cond);
		print(")");
	}

	public void visit(Statement.While stat) {
		print("while (");
		print(stat.cond);
		print(")");
		printBody(stat.body);
	}

	public void visit(Statement.For stat) {
		print("for (");
		print(stat.init);
		print(";");
		print(stat.cond);
		print("; ");
		print(stat.iter);
		print(")");
		printBody(stat.body);
	}

	public void visit(Statement.Foreach stat) {
		print("foreach (var ");
		print(stat.lhs);
		print(":");
		print(stat.rhs);
		print(")");
		printBody(stat.body);
	}

	public void visit(Statement.Forever stat) {
		print("forever ");
		printBody(stat.body);
	}

	public void visit(Statement.Break stat) {
		print("break");
	}

	public void visit(Statement.Continue stat) {
		print("continue");
	}

	public void visit(Statement.Return stat) {
		if (stat.expr == null)
			print("return");
		else {
			print("return ");
			print(stat.expr);
		}
	}

	public void visit(Statement.Assert stat) {
		print("assert ");
		print(stat.expr);
	}

	public void visit(Statement.Log stat) {
		print("log(");
		printArgs(stat.exprs);
		print(")");
	}

	public void visit(Statement.Expr stat) {
		print(stat.expr);
	}

	public void visit(Expression.Negation expr) {
		print("-");
		print(expr.expr);
	}

	public void visit(Expression.Increment expr) {
		print("++");
		print(expr.expr);
	}

	public void visit(Expression.Decrement expr) {
		print("--");
		print(expr.expr);
	}
	
	public void visit(Expression.Addition expr) {
		print(expr.lhs);
		print(" + ");
		print(expr.rhs);
	}

	public void visit(Expression.Subtraction expr) {
		print(expr.lhs);
		print(" - ");
		print(expr.rhs);
	}

	public void visit(Expression.Multiply expr) {
		print(expr.lhs);
		print(" * ");
		print(expr.rhs);
	}

	public void visit(Expression.Division expr) {
		print(expr.lhs);
		print(" / ");
		print(expr.rhs);
	}

	public void visit(Expression.Modulus expr) {
		print(expr.lhs);
		print(" % ");
		print(expr.rhs);
	}

	public void visit(Expression.ShiftLeft expr) {
		print(expr.lhs);
		print(" << ");
		print(expr.rhs);
	}

	public void visit(Expression.ShiftRight expr) {
		print(expr.lhs);
		print(" >> ");
		print(expr.rhs);
	}

	public void visit(Expression.BooleanOR expr) {
		print(expr.lhs);
		print(" | ");
		print(expr.rhs);
	}

	public void visit(Expression.BooleanXOR expr) {
		print(expr.lhs);
		print(" ^ ");
		print(expr.rhs);
	}

	public void visit(Expression.BooleanAND expr) {
		print(expr.lhs);
		print(" & ");
		print(expr.rhs);
	}

	public void visit(Expression.BooleanNOT expr) {
		print("~");
		print(expr.expr);
	}

	public void visit(Expression.Equal expr) {
		print(expr.lhs);
		print(" == ");
		print(expr.rhs);
	}

	public void visit(Expression.NotEqual expr) {
		print(expr.lhs);
		print(" != ");
		print(expr.rhs);	
	}

	public void visit(Expression.Less expr) {
		print(expr.lhs);
		print(" < ");
		print(expr.rhs);
	}

	public void visit(Expression.LessEqual expr) {
		print(expr.lhs);
		print(" <= ");
		print(expr.rhs);	
	}

	public void visit(Expression.Greater expr) {
		print(expr.lhs);
		print(" > ");
		print(expr.rhs);	
	}

	public void visit(Expression.GreaterEqual expr) {
		print(expr.lhs);
		print(" >= ");
		print(expr.rhs);
	}

	public void visit(Expression.LogicalOR expr) {
		print(expr.lhs);
		print(" or ");
		print(expr.rhs);
	}

	public void visit(Expression.LogicalAND expr) {
		print(expr.lhs);
		print(" and ");
		print(expr.rhs);
	}

	public void visit(Expression.LogicalNOT expr) {
		print("!");
		print(expr.expr);
	}

	public void visit(Expression.NewArray expr) {
		print("new var[");
		print(expr.size);
		print("]");
	}

	public void visit(Expression.Dot expr) {
		print(expr.lhs);
		print(".");
		print(expr.rhs);
	}

	public void visit(Expression.New expr) {
		print("new ");
		print(expr.ctor);
		print("(");
		printArgs(expr.args);
		print(")");
	}

	public void visit(Expression.Call expr) {
		print(expr.caller);
		print("(");
		printArgs(expr.args);
		print(")");
	}

	public void visit(Expression.Subscript expr) {
		print(expr.lhs);
		print("[");
		print(expr.rhs);
		print("]");
	}

	public void visit(Expression.Assignment expr) {
		print(expr.lhs);
		print(" = ");
		print(expr.rhs);
	}

	public void visit(Expression.Identifier expr) {
		print(expr.ident);
	}

	public void visit(Expression.Null expr) {
		print("null");
	}

	public void visit(Expression.True expr) {
		print("true");
	}

	public void visit(Expression.False expr) {
		print("false");
	}

	public void visit(Expression.Literal expr) {
		print(expr.value.data.toString());
	}
}
