public class Main {
	public static void main(String[] args) throws Exception {
		Option option = new Option(args);
		while (true) {
			System.out.print("Expression: ");

			LexStream lex_stream = new LexStream();
			Scanner scanner = new Scanner(option, lex_stream);
			scanner.scan();

			if (option.dump)
				lex_stream.dump();

			Parser parser = new Parser(lex_stream);
			Ast root = parser.parse();
			if (root != null)
				 System.out.println("\t" + root.toString(lex_stream) + " = " + root.Value());
			else break;
		}
		return;
	}
}