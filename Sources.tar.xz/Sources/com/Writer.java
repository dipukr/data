import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;

public class Writer {

	private ByteBuffer buffer = ByteBuffer.allocate(1000000);
	private String filename;
	private int vmsize;
	private int magic;

	public Writer(String filename) {
		this.filename = filename;
		this.magic = 0xABACADAE;
		this.vmsize = 0;
		this.buffer.order(ByteOrder.LITTLE_ENDIAN);
	}

	public void write() {
		generate();
	}

	private void writeHeader() throws Exception {
		FileChannel fc = new FileInputStream("E:\\Code\\project\\dvm\\ds.exe").getChannel();
		fc.read(buffer);
		fc.close();
		vmsize = buffer.position();
	}

	private void writeFooter() {
		write(vmsize);
		write(magic);
	}

	private void generate() {
		try (FileOutputStream out = new FileOutputStream(filename+".exe")) {
			buffer.flip();
			out.getChannel().write(buffer);
			out.close();
		} catch (Exception e) {System.err.print(e);}
	}

	private void writeCode(int[] code, int size) {
		write(size);
		for (int i = 0; i < size; i++)
			write(code[i]);
	}

	private void writeModules(List<Module> modules) {
		int modulec = modules.size();
		write(modulec);
		for (Module mdl: modules)
			write(mdl);
	}

	private void writeConstants(List<Value> constants) {
		int constantc = constants.size();
		write(constantc);
		for (Value value: constants)
			write(value);
	}

	private void writeSymbols(Map<String, Integer> symtab) {
		int symbolc = symtab.size();
		write(symbolc);
		for (Map.Entry<String, Integer> entry: symtab.entrySet()) {
			String key = entry.getKey();
			int value = entry.getValue();
			write(key);
			write(value);
		}
	}

	private void write(short s)  {buffer.putShort(s); }
	private void write(int i)    {buffer.putInt(i);   }
	private void write(long l)   {buffer.putLong(l);  }
	private void write(double f) {buffer.putDouble(f);}

	private void write(String s) {
		int len = s.length();
		buffer.putInt(len);
		buffer.put(s.getBytes());
	}

	private void write(Function func) {
		write(func.id);
		write(func.argc);
		write(func.localc);
		write(func.address);
	}

	private void write(Class cls) {
		write(cls.id);
		write(cls.datac);
		int memberc = cls.members.size();
		write(memberc);
		for (Member member: cls.members)
			write(member);
	}

	private void write(Module mod) {
		write(mod.id);
		int memberc = mod.members.size();
		write(memberc);
		for (Member member: m.members)
			write(member);
	}

	private void write(Member m) {
		write(m.id);
		write(m.kind);
		write(m.value);
	}

	private void write(Value v) {
		write(v.type);
		switch (v.type) {
		case Value.INT: write((long) v.data); break;
		case Value.FLT: write((double) v.data); break;
		case Value.STR: write((String) v.data); break;
		case Value.IDX: write((int) v.data); break;
		case Value.FUN: write((Function) v.data); break;
		case Value.CLS: write((Class) v.data); break;
		default: assert false;
		}
	}
}