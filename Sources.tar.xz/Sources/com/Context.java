public class Context {

	public static final int FUNCTION = 1;
	public static final int CLASS  = 2;
	public static final int MODULE = 3;

	public Context parent;
	public int kind;
	public int addr;
	public int localc;

	public Context() {
		this(null, MODULE);
	}

	public Context(Context parent, int kind) {
		this.parent = parent;
		this.kind = kind;
		this.addr = 0;
		this.localc = 0;
	}

	public int functionKind() {
		switch (kind) {
		case MODULE: return Symbol.MODULE_FUNCTION;
		case CLASS: return Symbol.OBJECT_FUNCTION;
		}
		assert false;
		return Symbol.INVALID;
	}

	public int varKind() {
		switch (kind) {
		case MODULE: return Symbol.MODULE_VAR;
		case CLASS:  return Symbol.OBJECT_VAR;
		case FUNCTION: return Symbol.LOCAL_VAR;
		}
		assert false;
		return Symbol.INVALID;
	}
}