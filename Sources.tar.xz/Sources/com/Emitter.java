import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;

public class Emitter implements Statement.Visitor, Expression.Visitor {

	public static Map<String, Integer> symtab = new HashMap<String, Integer>();
	public static List<Value> constants = new ArrayList<Value>();
	public static List<Module> modules = new ArrayList<Module>();
	public static int[] code = new int[1000000];
	public static int mainindex = 0;
	public static int ip = 0;

	private int[] bstack = new int[100];
	private int[] cstack = new int[100];
	private Module currmodule = null;
	private Class currclass = null;
	private boolean lval = false;
	private Statement module;
	private int bsp = -1;
	private int csp = -1;

	static {
		addSymbol("std");
		emit(Opcode.nop);
	}

	public Emitter(Statement module) {
		this.module = module;
	}

	public int emit() {
		emit(module);
		modules.add(currmodule);
		return modules.size();
	}

	private void emitStats(List<Statement> stats) {
		for (Statement stat: stats)
			emit(stat);
	}

	private void emitExprs(List<Expression> exprs) {
		for (Expression expr: exprs)
			emit(expr);
	}

	private void emit(Statement stat)  { stat.accept(this); }
	private void emit(Expression expr) { expr.accept(this); }

	private static void emit(int opc) { code[ip++] = opc; }
	private static int  emit(int opc, int opr) {
		code[ip++] = opc;
		code[ip] = opr;
		return ip++;
	}
	
	private static void resolve(int dest, int opr) {
		code[dest] = opr;
	}

	public static int moduleIndex(String s) {
		if (s.equals("std")) return 0;
		return moduleIndex(addSymbol(s));
	}

	public static int moduleIndex(int id) {
		for (int i = 0; i < modules.size(); i++)
			if (modules.get(i).id == id)
				return (i+1);
		return -1;
	}

	private static int addSymbol(String sym) {
		Integer i = symtab.get(sym);
		if (i != null) return i;
		int index = symtab.size();
		symtab.put(sym, index);
		return index;
	}

	private static int addLiteral(Value v) {
		for (int i = 0; i < constants.size(); i++)
			if (constants.get(i).eq(v))
				return i;
		int index = constants.size();
		constants.add(v);
		return index;
	}

	private void pushContinue(int label) {cstack[++csp] = label;}
	private void popContinue() {csp--;}
	
	private int pushBreak(int label) {
		int old = bsp++;
		bstack[bsp] = label;
		return old;
	}

	private int popBreak(int old) {
		int result = bstack[bsp];
		bsp = old;
		return result;
	}

	private void addVar(int id, int addr) {
		Member m = new Member();
		m.id = id;
		m.kind = Member.VAR;
		m.value = new Value(addr);
		if (currclass != null) currclass.add(m);
		else currmodule.add(m);
	}

	private void addFunction(Function func) {
		Member m = new Member();
		m.id = func.id;
		m.kind = Member.FUNCTION;
		m.value = new Value(func);
		if (currclass != null) currclass.add(m);
		else currmodule.add(m);
	}

	private void addClass(Class cls) {
		Member m = new Member();
		m.id = cls.id;
		m.kind = Member.CLASS;
		m.value = new Value(cls);
		currmodule.add(m);	
	}

	private void combine(Statement.Function ctor, List<Statement> vars) {
		Function func = new Function();
		func.id = addSymbol(ctor.name);
		func.argc = ctor.args.size()+1;
		func.localc = ctor.sym.localc;
		func.address = ip;
		emitStats(vars);
		emit(ctor.body);
		addFunction(func);	
	}

	private void rvalue(Expression expr) {
		boolean save = lval;
		lval = false;
		expr.accept(this);
		lval = save;
	}

	private void lvalue(Expression expr) {
		boolean save = lval;
		lval = true;
		expr.accept(this);
		lval = save;
	}

	public void visit(Statement.Module stat) {
		currmodule = new Module();
		currmodule.id = addSymbol(stat.name);
		emitStats(stat.imports);
		emitStats(stat.vars);
		emitStats(stat.functions);
		emitStats(stat.classes);
	}

	public void visit(Statement.Import stat) {}

	public void visit(Statement.Classdef stat) {
		currclass = new Class();
		currclass.id = addSymbol(stat.name);
		currclass.datac = stat.vars.size();
		combine((Statement.Function) stat.ctor, stat.vars);
		emitStats(stat.functions);
		addClass(currclass);
		currclass = null;
	}

	public void visit(Statement.Function stat) {
		Function func = new Function();
		func.id = addSymbol(stat.name);
		func.argc = stat.args.size()+1;
		func.localc = stat.sym.localc;
		func.address = ip;
		emit(stat.body);
		addFunction(func);
	}

	public void visit(Statement.Var stat) {
		if (stat.expr == null) emit(Opcode.loadn);
		else rvalue(stat.expr);
		switch (stat.sym.kind) {
		case Symbol.LOCAL_VAR: 
			emit(Opcode.store, stat.sym.addr);
			emit(Opcode.pop);
			break;
		case Symbol.OBJECT_VAR:
			emit(Opcode.storef, stat.sym.addr);
			emit(Opcode.pop);
			break;
		case Symbol.MODULE_VAR:
			emit(Opcode.storeg, stat.sym.addr);
			emit(Opcode.pop);
			break;
		default: assert false;
		}
	}

	public void visit(Statement.Block stat) {
		emitStats(stat.body);
	}

	public void visit(Statement.If stat) {
		emit(stat.cond);
		int next = emit(Opcode.jif, 0);
		emit(stat.ifbody);
		if (stat.elsebody != null) {
			int end = emit(Opcode.jump, 0);
			resolve(next, ip);
			emit(stat.elsebody);
			next = end;
		}
		resolve(next, ip);
	}

	public void visit(Statement.Repeat stat) {
		int next = ip;
		emitStats(stat.body);
		emit(stat.cond);
		emit(Opcode.jit, next);
	}

	public void visit(Statement.While stat) {
		int next = ip;
		emit(stat.cond);
		int end = emit(Opcode.jif, 0);
		emit(stat.body);
		emit(Opcode.jump, next);
		resolve(end, ip);		
	}

	public void visit(Statement.For stat) {
		
	}

	public void visit(Statement.Foreach stat) {
		Log.error("foreach not implemented yet");
	}

	public void visit(Statement.Forever stat) {
		int next = ip;
		pushContinue(next);
		emit(stat.body);
		popContinue();
		emit(Opcode.jump, next);
	}

	public void visit(Statement.Break stat) {
		bstack[bsp] = emit(Opcode.jump, bstack[bsp]);
	}

	public void visit(Statement.Continue stat) {
		emit(Opcode.jump, cstack[csp]);	
	}

	public void visit(Statement.Return stat) {
		if (stat.expr == null) emit(Opcode.loadn);
		else rvalue(stat.expr);
		emit(Opcode.ret);
	}

	public void visit(Statement.Assert stat) {
		rvalue(stat.expr);
		emit(Opcode.asrt, stat.pos);
	}

	public void visit(Statement.Log stat) {
		int argc = stat.exprs.size();
		emitExprs(stat.exprs);
		emit(Opcode.cout, argc);
	}

	public void visit(Statement.Expr stat) {
		rvalue(stat.expr);
		emit(Opcode.pop);
	}

	public void visit(Expression.Negation expr) {
		assert lval == false;
		rvalue(expr.expr);
		emit(Opcode.neg);
	}

	public void visit(Expression.Increment expr) {
		assert lval == false;
		rvalue(expr.expr);
		emit(Opcode.inc);
		lvalue(expr.expr);
	}

	public void visit(Expression.Decrement expr) {
		assert lval == false;
		rvalue(expr.expr);
		emit(Opcode.dec);
		lvalue(expr.expr);
	}

	public void visit(Expression.Addition expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.add);
	}

	public void visit(Expression.Subtraction expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.sub);
	}

	public void visit(Expression.Multiply expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.mul);
	}

	public void visit(Expression.Division expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.div);
	}

	public void visit(Expression.Modulus expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.mod);
	}

	public void visit(Expression.ShiftLeft expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.shl);
	}

	public void visit(Expression.ShiftRight expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.shr);
	}

	public void visit(Expression.BooleanOR expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.bor);
	}

	public void visit(Expression.BooleanXOR expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.bxor);
	}

	public void visit(Expression.BooleanAND expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.band);
	}

	public void visit(Expression.BooleanNOT expr) {
		assert lval == false;
		rvalue(expr.expr);
		emit(Opcode.bnot);
	}

	public void visit(Expression.LogicalOR expr) {
		assert lval == false;
		rvalue(expr.lhs);
		int end = emit(Opcode.jit, 0);
		emit(Opcode.pop);
		rvalue(expr.rhs);
		resolve(end, ip);
	}

	public void visit(Expression.LogicalAND expr) {
		assert lval == false;
		rvalue(expr.lhs);
		int end = emit(Opcode.jif, 0);
		emit(Opcode.pop);
		rvalue(expr.rhs);
		resolve(end, ip);
	}

	public void visit(Expression.LogicalNOT expr) {
		assert lval == false;
		rvalue(expr.expr);
		emit(Opcode.lnot);
	}

	public void visit(Expression.Equal expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.ceq);
	}

	public void visit(Expression.NotEqual expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.cne);
	}

	public void visit(Expression.Less expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.clt);
	}

	public void visit(Expression.LessEqual expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.cle);
	}

	public void visit(Expression.Greater expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.cgt);
	}

	public void visit(Expression.GreaterEqual expr) {
		assert lval == false;
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		emit(Opcode.cge);
	}

	public void visit(Expression.NewArray expr) {
		rvalue(expr.size);
		emit(Opcode.newa);
	}

	public void visit(Expression.Dot expr) {
		rvalue(expr.lhs);
		int id = addSymbol(expr.rhs);
		if (lval) emit(Opcode.storem, id);
		else emit(Opcode.loadm, id);
	}

	public void visit(Expression.Call expr) {
		
	}

	public void visit(Expression.Subscript expr) {
		rvalue(expr.lhs);
		rvalue(expr.rhs);
		if (lval) emit(Opcode.storea);
		else emit(Opcode.loada);
	}

	public void visit(Expression.Assignment expr) {
		assert lval == false;
		rvalue(expr.rhs);
		lvalue(expr.lhs);
	}

	public void visit(Expression.Identifier expr) {
		if (lval) {
			switch (expr.sym.kind) {
			case Symbol.LOCAL_VAR:  emit(Opcode.store, -expr.sym.addr); break;
			case Symbol.OBJECT_VAR: emit(Opcode.storef, expr.sym.addr); break;
			case Symbol.MODULE_VAR: emit(Opcode.storeg, expr.sym.addr); break;
			default: assert false;
			}
		} else {
			switch (expr.sym.kind) {
			case Symbol.LOCAL_VAR:  emit(Opcode.load, -expr.sym.addr); break;
			case Symbol.OBJECT_VAR: emit(Opcode.loadf, expr.sym.addr); break;
			case Symbol.MODULE_VAR: emit(Opcode.loadg, expr.sym.addr); break;
			default: assert false;
			}
		}
	}

	public void visit(Expression.Null expr) {
		assert lval == false;
		emit(Opcode.loadn);
	}

	public void visit(Expression.True expr) {
		assert lval == false;
		emit(Opcode.load1);
	}

	public void visit(Expression.False expr) {
		assert lval == false;
		emit(Opcode.load0);
	}

	public void visit(Expression.Literal expr) {
		assert lval == false;
		if (expr.value.type == Value.INT) {
			long l = (long) expr.value.data;
			if (l == 0L) emit(Opcode.loadz);
			return;
		}
		emit(Opcode.loadc, addLiteral(expr.value));
	}
}