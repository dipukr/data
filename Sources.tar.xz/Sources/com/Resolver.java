import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;

public class Resolver implements Statement.Visitor, Expression.Visitor {
	
	private Statement module;
	private int looplevel;

	public Resolver(Statement module) {
		this.module = module;
		this.looplevel = 0;
	}

	public void resolve() {
		resolve(module);
	}

	private void resolveStats(List<Statement> stats) {
		for (Statement stat: stats)
			resolve(stat);
	}

	private void resolveExprs(List<Expression> exprs) {
		for (Expression expr: exprs)
			resolve(expr);
	}

	private void resolve(Statement stat) {
		stat.accept(this);
	}

	private void resolve(Expression expr) {
		expr.accept(this);
	}

	private boolean lvalue(Expression expr) {
		if (expr instanceof Expression.Identifier ||
			expr instanceof Expression.Dot ||
			expr instanceof Expression.Subscript) return true;
		return false;
	}

	public void visit(Statement.Module stat) {
		resolveStats(stat.imports);
		resolveStats(stat.vars);
		resolveStats(stat.functions);
		resolveStats(stat.classes);
	}

	public void visit(Statement.Import stat) {}

	public void visit(Statement.Classdef stat) {
		resolve(stat.ctor);
		resolveStats(stat.vars);
		resolveStats(stat.functions);
	}

	public void visit(Statement.Function stat) {
		resolve(stat.body);
	}

	public void visit(Statement.Block stat) {
		resolveStats(stat.body);
	}

	public void visit(Statement.Var stat) {
		if (stat.expr != null)
			resolve(stat.expr);
	}

	public void visit(Statement.If stat) {
		resolve(stat.cond);
		resolve(stat.ifbody);
		if (stat.elsebody != null) resolve(stat.elsebody);
	}

	public void visit(Statement.Repeat stat) {
		if (looplevel++ == 100) Log.error("too much nesting of loop", stat.pos);
		resolveStats(stat.body);
		resolve(stat.cond);
		looplevel--;
	}

	public void visit(Statement.While stat) {
		if (looplevel++ == 100) Log.error("too much nesting of loop", stat.pos);
		resolve(stat.cond);
		resolve(stat.body);
		looplevel--;
	}

	public void visit(Statement.For stat) {
		if (looplevel++ == 100) Log.error("too much nesting of loop", stat.pos);
		resolve(stat.init);
		resolve(stat.cond);
		resolve(stat.iter);
		resolve(stat.body);
		looplevel--;
	}

	public void visit(Statement.Foreach stat) {
		if (looplevel++ == 100) Log.error("too much nesting of loop", stat.pos);
		looplevel--;
	}

	public void visit(Statement.Forever stat) {
		if (looplevel++ == 100) Log.error("too much nesting of loop", stat.pos);
		resolve(stat.body);
		looplevel--;
	}

	public void visit(Statement.Break stat) {
		if (looplevel == 0) Log.error("break outside loop statement", stat.pos);
	}
	
	public void visit(Statement.Continue stat) {
		if (looplevel == 0) Log.error("break outside loop statement", stat.pos);
	}
	
	public void visit(Statement.Return stat) {
		if (stat.expr != null) resolve(stat.expr);
	}
	
	public void visit(Statement.Assert stat) {
		resolve(stat.expr);
	}
	
	public void visit(Statement.Log stat) {
		resolveExprs(stat.exprs);
	}
	
	public void visit(Statement.Expr stat) {
		resolve(stat.expr);
	}

	public void visit(Expression.Negation expr) {
		resolve(expr.expr);
	}

	public void visit(Expression.Increment expr) {
		resolve(expr.expr);
	}

	public void visit(Expression.Decrement expr) {
		resolve(expr.expr);
	}

	public void visit(Expression.Addition expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(AstNode.While ast) {
		Node left = ast.getLeft();
		Node right = ast.getRight();
		resolve(left);
		resolve(right);
	}

	public void visit(Node.Addition ast) {
		Node left = ast.left();
		Node right = ast.right();
		resolve(left);
		resolve(right);
	}

	public void visit(Node.Addition ast) {
		resolve(ast.left);
		resolve(ast.right);
	}
	
	public void visit(Expression.Subtraction expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.Multiply expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.Division expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.Modulus expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.ShiftLeft expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.ShiftRight expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.BooleanOR expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}
	
	public void visit(Expression.BooleanXOR expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.BooleanAND expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.BooleanNOT expr) {
		resolve(expr.expr);
	}

	public void visit(Expression.Equal expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.NotEqual expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.Less expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.LessEqual expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.Greater expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.GreaterEqual expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.LogicalOR expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.LogicalAND expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.LogicalNOT expr) {
		resolve(expr.expr);
	}

	public void visit(Expression.NewArray expr) {
		resolve(expr.size);
	}

	public void visit(Expression.Dot expr) {
		if (lvalue(expr.lhs) == false)
			Log.error("lvalue expected in left of dot expression", expr.pos);
		resolve(expr.lhs);
	}

	public void visit(Expression.New expr) {
		resolve(expr.ctor);
		resolveExprs(expr.args);
	}
	
	public void visit(Expression.Call expr) {
		resolve(expr.caller);
		resolveExprs(expr.args);
	}
	
	public void visit(Expression.Subscript expr) {
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.Assignment expr) {
		if (lvalue(expr.lhs) == false)
			Log.error("lvalue expected in left of assignment", expr.pos);
		resolve(expr.lhs);
		resolve(expr.rhs);
	}

	public void visit(Expression.Identifier expr) {
		expr.sym = expr.scope.resolve(expr.ident);
		if (expr.sym == null)
			Log.error("undeclared symbol "+expr.ident, expr.pos);
		System.out.println(expr.sym);
	}
	
	public void visit(Expression.Null expr) {}
	public void visit(Expression.True expr) {}
	public void visit(Expression.False expr) {}
	public void visit(Expression.Literal expr) {}
}