import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;

public class Declarator implements Statement.Visitor, Expression.Visitor {
	
	private Context context = new Context();
	private SymbolTable symtab;
	private Statement module;
	private Scope scope;

	public Declarator(Statement module) {
		this.module = module;
	}

	public void declare(SymbolTable symtab) {
		this.symtab = symtab;
		this.scope = symtab.global;
		declarestd();
		declare(module);
	}

	private void declareStats(List<Statement> stats) {
		for (Statement stat: stats)
			declare(stat);
	}

	private void declareExprs(List<Expression> exprs) {
		for (Expression expr: exprs)
			declare(expr);
	}

	private void declare(Statement stat) {
		stat.accept(this);
	}

	private void declare(Expression expr) {
		expr.accept(this);
	}

	public void visit(Statement.Module stat) {
		declareStats(stat.imports);
		declareStats(stat.vars);
		declareStats(stat.functions);
		declareStats(stat.classes);
	}

	private void declarestd() {
		Symbol sym = new Symbol("std");
		sym.kind = Symbol.MODULE_DEFINITION;
		sym.addr = 0;
		scope.define(sym);
	}

	public void visit(Statement.Import stat) {
		Symbol sym = new Symbol(stat.name);
		sym.kind = Symbol.MODULE_DEFINITION;
		sym.addr = Emitter.moduleIndex(stat.name);
		if (sym.addr == -1) {
			try {
				sym.addr = Compiler.compile(stat.name);
				System.out.println("sym.addr:"+sym.addr);
				Statement.Module mdl = (Statement.Module) module;
				Compiler.filename = mdl.name;
			} catch (Exception e) {}
		}
		if (!scope.define(sym)) Log.error("duplicates of import "+stat.name, stat.pos);
	}

	public void visit(Statement.Classdef stat) {
		ClassSymbol sym = new ClassSymbol(scope, stat.name);
		sym.kind = Symbol.CLASS_DEFINITION;
		sym.addr = context.addr++;
		if (!scope.define(sym)) Log.error("duplicates of class "+stat.name, stat.pos);
		stat.sym = sym;
		scope = sym;
		context = new Context(context, Context.CLASS);
		declareStats(stat.vars);
		declare(stat.ctor);
		declareStats(stat.functions);
		context = context.parent;
		scope = scope.parentScope();
	}

	private void declareArgs(List<String> args, boolean _this, int pos) {
		if (_this) {
			VarSymbol vs = new VarSymbol("this");
			vs.kind = context.varKind();
			vs.addr = context.addr++;
			scope.define(vs);
			context.localc++;
		}
		for (String arg: args) {
			VarSymbol vs = new VarSymbol(arg);
			vs.kind = context.varKind();
			vs.addr = context.addr++;
			if (!scope.define(vs)) Log.error("duplicates of param "+arg, pos);
			context.localc++;
		}
	}

	public void visit(Statement.Function stat) {
		FunctionSymbol sym = new FunctionSymbol(scope, stat.name);
		sym.kind = context.functionKind();
		sym.addr = context.addr++;
		if (!scope.define(sym)) Log.error("duplicates of method "+stat.name, stat.pos);
		stat.sym = sym;
		scope = sym;
		context = new Context(context, Context.FUNCTION);
		declareArgs(stat.args, sym.kind == Symbol.OBJECT_FUNCTION, stat.pos);
		declare(stat.body);
		sym.localc = context.localc;
		context = context.parent;
		scope = scope.parentScope();
	}

	public void visit(Statement.Var stat) {
		VarSymbol sym = new VarSymbol(stat.name);
		sym.kind = context.varKind();
		sym.addr = context.addr++;
		stat.sym = sym;
		if (!scope.define(sym)) Log.error("duplicates of var "+stat.name, stat.pos);
		if (context.kind == Context.FUNCTION) context.localc++;
		if (stat.expr != null) declare(stat.expr);
	}

	public void visit(Statement.Block stat) {
		scope = new LocalScope(scope);
		declareStats(stat.body);
		scope = scope.parentScope();
	}

	public void visit(Statement.If stat) {
		declare(stat.cond);
		declare(stat.ifbody);
		if (stat.elsebody != null) declare(stat.elsebody);
	}

	public void visit(Statement.Repeat stat) {
		declareStats(stat.body);
		declare(stat.cond);
	}

	public void visit(Statement.While stat) {
		declare(stat.cond);
		declare(stat.body);
	}

	public void visit(Statement.For stat) {
		declare(stat.init);
		declare(stat.cond);
		declare(stat.iter);
		declare(stat.body);
	}

	public void visit(Statement.Foreach stat) {
		Log.error("foreach not implemented", stat.pos);
	}

	public void visit(Statement.Forever stat) {
		declare(stat.body);
	}

	public void visit(Statement.Break stat) {}
	public void visit(Statement.Continue stat) {}
	
	public void visit(Statement.Return stat) {
		if (stat.expr != null)
			declare(stat.expr);
	}
	
	public void visit(Statement.Assert stat) {
		declare(stat.expr);
	}
	
	public void visit(Statement.Log stat) {
		declareExprs(stat.exprs);
	}
	
	public void visit(Statement.Expr stat) {
		declare(stat.expr);
	}

	public void visit(Expression.Negation expr) {
		declare(expr.expr);
	}

	public void visit(Expression.Increment expr) {
		declare(expr.expr);
	}

	public void visit(Expression.Decrement expr) {
		declare(expr.expr);
	}

	public void visit(Expression.Addition expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}
	
	public void visit(Expression.Subtraction expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.Multiply expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.Division expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.Modulus expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.ShiftLeft expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.ShiftRight expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.BooleanOR expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}
	
	public void visit(Expression.BooleanXOR expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.BooleanAND expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.BooleanNOT expr) {
		declare(expr.expr);
	}

	public void visit(Expression.Equal expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.NotEqual expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.Less expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.LessEqual expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.Greater expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.GreaterEqual expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.LogicalOR expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.LogicalAND expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.LogicalNOT expr) {
		declare(expr.expr);
	}

	public void visit(Expression.NewArray expr) {
		declare(expr.size);
	}

	public void visit(Expression.Dot expr) {
		declare(expr.lhs);
	}

	public void visit(Expression.New expr) {
		declare(expr.ctor);
		declareExprs(expr.args);
	}
	
	public void visit(Expression.Call expr) {
		declare(expr.caller);
		declareExprs(expr.args);
	}
	
	public void visit(Expression.Subscript expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.Assignment expr) {
		declare(expr.lhs);
		declare(expr.rhs);
	}

	public void visit(Expression.Identifier expr) {
		expr.scope = this.scope;
	}
	
	public void visit(Expression.Null expr) {}
	public void visit(Expression.True expr) {}
	public void visit(Expression.False expr) {}
	public void visit(Expression.Literal expr) {}
}