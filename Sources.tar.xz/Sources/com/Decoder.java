import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.PrintWriter;

public class Decoder {

	private PrintWriter out;
	private String[] symbols;

	public Decoder(String filename) {
		try {
			out = new PrintWriter(filename);
		} catch (Exception e) {}
	}

	public Decoder decode() {
		out.close();
		return this;
	}

	public Decoder decodeSymtab(Map<String, Integer> symtab) {
		symbols = new String[symtab.size()];
		for (Map.Entry<String, Integer> elem: symtab.entrySet()) {
			String key = elem.getKey();
			int value = elem.getValue();
			symbols[value] = key;
		}
		return this;
	}

	public Decoder decodeCode(int[] code, int codec) {
		int i = 0;
		int o = 0;
		while (i < codec) {
			out.printf("%03d: ", o++);
			switch (code[i++]) {
			case Opcode.nop:   out.printf("nop"); break;
			case Opcode.pos:   out.printf("pos \t%d", code[i++]); o++; break;
			case Opcode.push:  out.printf("push"); break;
			case Opcode.pop:   out.printf("pop"); break;
			case Opcode.dup:   out.printf("dup"); break;
			case Opcode.dup2:  out.printf("dup2"); break;
			case Opcode.copy:  out.printf("copy"); break;
			case Opcode.save:  out.printf("save"); break;
			case Opcode.loadn: out.printf("loadn"); break;
			case Opcode.loadz: out.printf("loadz"); break;
			case Opcode.load1: out.printf("load1"); break;
			case Opcode.load0: out.printf("load0"); break;
			case Opcode.loadc: out.printf("loadc\t%d", code[i++]); o++; break;
			case Opcode.load:  out.printf("load\t%d",  Math.abs(code[i++])); o++; break;
			case Opcode.loadf: out.printf("loadf\t%d", code[i++]); o++; break;
			case Opcode.loadg: out.printf("loadg\t%d", code[i++]); o++; break;
			case Opcode.loada: out.printf("loada"); break;
			case Opcode.loadm: out.printf("loadm\t%d", code[i++]); o++; break;
			case Opcode.ldmdl: out.printf("ldmdl\t%d", code[i++]); o++; break;
			case Opcode.store: out.printf("store\t%d", Math.abs(code[i++])); o++; break;
			case Opcode.storef: out.printf("storef\t%d", code[i++]); o++; break;
			case Opcode.storeg: out.printf("storeg\t%d", code[i++]); o++; break;
			case Opcode.storea: out.printf("storea"); break;
			case Opcode.storem: out.printf("storem\t%d", code[i++]); o++; break;
			case Opcode.newa: out.printf("newa"); break;
			case Opcode.newi: out.printf("newi"); break;
			case Opcode.jit:  out.printf("jit \t%d", code[i++]); o++; break;
			case Opcode.jif:  out.printf("jif \t%d", code[i++]); o++; break;
			case Opcode.jump: out.printf("jump\t%d", code[i++]); o++; break;
			case Opcode.call: out.printf("call\t%d", code[i++]); o++; break;
			case Opcode.ret:  out.printf("ret"); break;
			case Opcode.neg:  out.printf("neg"); break;
			case Opcode.inc:  out.printf("inc"); break;
			case Opcode.dec:  out.printf("dec"); break;
			case Opcode.add:  out.printf("add"); break;
			case Opcode.sub:  out.printf("sub"); break;
			case Opcode.mul:  out.printf("mul"); break;
			case Opcode.div:  out.printf("div"); break;
			case Opcode.mod:  out.printf("mod"); break;
			case Opcode.shl:  out.printf("shl"); break;
			case Opcode.shr:  out.printf("shr"); break;
			case Opcode.bor:  out.printf("bor"); break;
			case Opcode.bxor: out.printf("bxor"); break;
			case Opcode.band: out.printf("band"); break;
			case Opcode.bnot: out.printf("bnot"); break;
			case Opcode.lnot: out.printf("lnot"); break;
			case Opcode.ceq:  out.printf("ceq"); break;
			case Opcode.cne:  out.printf("cne"); break;
			case Opcode.clt:  out.printf("clt"); break;
			case Opcode.cle:  out.printf("cle"); break;
			case Opcode.cgt:  out.printf("cgt"); break;
			case Opcode.cge:  out.printf("cge"); break;
			case Opcode.cout: out.printf("cout\t%d", code[i++]); o++; break;
			case Opcode.asrt: out.printf("asrt\t%d", code[i++]); o++; break;
			case Opcode.halt: out.printf("halt"); break;
			}
			out.printf("\n");
		}
		return this;
	}

	public Decoder decodeModules(List<Module> modules) {
		out.println();
		for (Module mdl: modules)
			decode(mdl);
		return this;
	}

	private void decode(Module mdl) {
		out.print(symbols[mdl.id]);
		out.print("[");
		for (Member m: mdl.members)
			decode(m);
		out.print("]");
		out.println();
	}

	private void decode(Class cls) {
		out.print("{");
		for (Member m: cls.members)
			decode(m);
		out.print("}");
	}

	private void decode(Function f) {
		out.print(f.argc);
		out.print(", ");
		out.print(f.localc);
		out.print(", ");
		out.print(f.address);
	}

	private void decode(int i) {
		out.print(i);
	}

	private void decode(Member m) {
		out.print("(");
		out.print(symbols[m.id]);
		out.print(":");
		switch (m.kind) {
		case Member.VAR: decode((int) m.value.data); break;
		case Member.FUNCTION: decode((Function) m.value.data); break;
		case Member.CLASS: decode((Class) m.value.data); break;
		default: assert false;
		}
		out.print(")");
	}
}