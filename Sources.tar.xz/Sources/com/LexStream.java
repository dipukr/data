import java.util.Vector;
import java.io.InputStream;


// LexStream holds a stream of tokens generated from an input and 
// provides methods to retrieve information from the stream.

public class LexStream
{
	private Vector<Token> tokens = new Vector<Token>();
	private int index;

	public int Next(int i) {return (++i < tokens.size() ? i : tokens.size() - 1);}
	public int Previous(int i) {return (i <= 0 ? 0 : i - 1);}
	public int Peek() {return Next(index);}

	public void Reset(int i) {index = Previous(i);}
	public void Reset() {index = 0;}

	public int Gettoken() {return index = Next(index);}
	public int Gettoken(int end_token) {return index = (index < end_token ? Next(index) : tokens.size() - 1);}
	public int Badtoken() {return 0;}

	public int Kind(int i) {return tokens.elementAt(i).kind;}
	public String Name(int i) {return tokens.elementAt(i).name;}

	public void dump() {
		for (int i = 1; i < tokens.size(); i++) {
			System.out.print(" (");
			switch (tokens.elementAt(i).kind) {
				case TK_PLUS:	  System.out.print("PLUS"); break;
				case TK_MINUS:	 System.out.print("MINUS"); break;
				case TK_STAR:	  System.out.print("STAR"); break;
				case TK_SLASH:	 System.out.print("SLASH"); break;
				case TK_LPAREN:	System.out.print("LPAREN"); break;
				case TK_RPAREN:	System.out.print("RPAREN"); break;
				case TK_NUMBER:	System.out.print("NUMBER"); break;
				case TK_ERROR:	 System.out.print("ERROR"); break;
				case TK_EOF:	   System.out.print("EOF"); break;
				default: System.out.print(((Token) tokens.elementAt(i)).kind);
			}
			System.out.print(") : \"");
			System.out.print(((Token) tokens.elementAt(i)).name);
			System.out.println("\"");
		}
	}
}
